<?php
////  Menu principal
$trad["SSO_nom_module"] = "Sso";
$trad["SSO_nom_module_header"] = "Authentification externe";
$trad["SSO_description_module"] = "Authentification externe";

////  Index.php
$trad["SSO_titreMenuAdmin"] = "Gestion de l'authentification externe pour : ";
$trad["SSO_infoBulleMenu"] = "Identifiant de connexion pour ";
$trad["sso_importer"] = "Import d'identifiants SSO (CSV)";
$trad["sso_import"] = "Importer des identifiants SSO dans le module";
$trad["generer_cle"] = "Gestion des Clés de cryptage";

////  Sso_edit.php
$trad["SSO_titre1"] = "Gestion de la connexion dans le module ";
$trad["SSO_titre2"] = " pour :";
$trad["SSO_configuration"] = "Configuration de l'Identifiant et du mot de passe faite.";
$trad["SSO_user"] = "Nom d'utilisateur : ";
$trad["SSO_password"] = "Mot de passe : ";
$trad["SSO_specifier_user"] = "Vous devez entrer un nom d'utilisateur !";
$trad["SSO_specifier_pass"] = "Vous devez entrer un mot de passe !";
$trad["SSO_user_ok"] = "Configuration OK !";
$trad["SSO_valider"] = "Enregistrer";

$trad["SSO_modifier"] = "Modifier la configuration SSO";
$trad["SSO_suppr_identifiant"] = "Effacer la configuration SSO";

?>
