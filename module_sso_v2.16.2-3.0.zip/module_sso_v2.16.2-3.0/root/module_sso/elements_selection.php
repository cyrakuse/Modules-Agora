<script type="text/javascript">

function effacer_tous()
{
	var answer = confirm('Confirmer la suppression de la configuration SSO ?');
	if (answer) 
	{window.document.form_sso.submit();}
}

////	NB ELEMENTS SELECTIONNES
////	type_element => si on ne souhaite qu'un certain type d'element
function nb_elements_select(alerte, type_element)
{
	var nb_elements_select = 0;
	tab_elements = document.getElementsByName("elements[]");//!IE le considère comme un objet, et non comme un simple tableau de valeurs
	for(var cle=0; cle< tab_elements.length; cle++)
	{
		if(tab_elements[cle].checked==true  &&  (type_element==undefined || tab_elements[cle].value.substring(0,type_element.length)==type_element))
			nb_elements_select++;
	}
	if(nb_elements_select==0 && alerte==true)	alert("<?php echo $trad["aucun_element_selectionne"]; ?>");
	return nb_elements_select;
}


////	SÉLECTION / DÉSELECTION D'UN ÉLEMENT  (onClick sur l'élement ("bascule") / via selection_tous_elements() )
////	select => true / false / "bascule"
function selection_element(cpt_div_element, select)
{
	if(isNaN(cpt_div_element))	cpt_div_element = cpt_div_element.replace('checkbox_element_','').replace('div_elem_','');
	checkbox_element = element("checkbox_element_"+cpt_div_element);
	if(select==true ||  (select==undefined && checkbox_element.checked==false))			{ checkbox_element.checked = true;   element("div_elem_"+cpt_div_element).className = "div_elem_select"; }
	else if(select==false ||  (select==undefined && checkbox_element.checked==true))	{ checkbox_element.checked = false;  element("div_elem_"+cpt_div_element).className = "div_elem_deselect"; }
	// Déroule / enroule le menu d'édition des éléments ?
	if(existe("menu_elements_edit")){
		if(nb_elements_select()>0 && element("menu_elements_edit").style.display=="none")	afficher_dynamic('menu_elements_edit',true);
		if(nb_elements_select()==0 && element("menu_elements_edit").style.display!="none")	afficher_dynamic('menu_elements_edit',false);
	}
	// Affiche le bon libellé principal
	libelle_principal = (nb_elements_select()>0)  ?  get_value("text_inverser_selection")  :  get_value("text_tout_selectionner");
	element("text_selection_menu_elements").innerHTML = libelle_principal;
}


////	SELECTION / DESELECTION DE TOUS LES ELEMENTS
////	select		 => true / false / "bascule"
////	type_element => si on ne souhaite qu'un certain type d'element (genre "fichier-")
function selection_tous_elements(select, type_element)
{
	////	Init
	nb_selections = 0;
	if(select==undefined)  select = "bascule";
	tab_elements = document.getElementsByName("elements[]");
	////	On lance la sélection/déselection
	for(var i=0; i< tab_elements.length; i++)
	{
		if(type_element==undefined || tab_elements[i].value.substring(0,type_element.length)==type_element)
		{
			cpt_div_element = i + 1;
			if(select==true || (select=="bascule" && element("checkbox_element_"+cpt_div_element).checked==false))	{ select2 = true;  nb_selections ++; }
			else																									{ select2 = false; }
			selection_element(cpt_div_element, select2);
		}
	}
	afficher_block = (nb_selections>0) ? true : false;
	afficher_dynamic("menu_elements_edit",afficher_block);
}
</script>

<?php
////	SELECTIONNER TOUS LES ELEMENTS  /  INVERSER LA SELECTION
echo "<div class='menu_gauche_line lien' onClick=\"selection_tous_elements('bascule');\">";
	echo "<div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/check.png\" /></div>";
	echo "<div class='menu_gauche_txt'><span id='text_selection_menu_elements'>".$trad["tout_selectionner"]."</span><input type='hidden' name='text_inverser_selection' value=\"".$trad["inverser_selection"]."\" /><input type='hidden' name='text_tout_selectionner' value=\"".$trad["tout_selectionner"]."\" /></div>";
echo "</div>";

////	ACTION SUR LES ELEMENTS SELECTIONNES
echo "<div id='menu_elements_edit' style='padding-left:20px;display:none;'>";
	// UTILISATEUR : DESAFFECTER (admin espace) / SUPPRIMER (admin général)
			echo "<div class='menu_gauche_line lien' onClick='return effacer_tous();'><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/supprimer.png\" /></div><div class='menu_gauche_txt'>".$trad["SSO_suppr_identifiant"]."</div></div>";
echo "<hr /></div>";
?>