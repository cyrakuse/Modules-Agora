<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",false);
require "commun.inc.php";
require_once PATH_INC."header.inc.php";
require "../commun/sso/crypt_decrypt.php";
if ($_SESSION['user']['admin_general'] == 1)
{
?>

<script type="text/javascript">
////	Redimensionne
resize_iframe_popup(590,400);
</script>

<?php
$modules = db_tableau ("SELECT * FROM gt_module_sso");
		
foreach ($modules as $module_tmp)
{
?>
<script type="text/javascript">
////    On contr�le les champs pour le brouillon
	function controle_formulaire_<?php echo $module_tmp["nom"]; ?>()
	{
	// Il doit y avoir un titre
	if (get_value("output_<?php echo $module_tmp["nom"]; ?>").length==0)
	{alert("Cliquez sur g\351n\351rer ou entrez une Cl\351 valide !"); return false; }
	}

//// Generer Cle
var keylist="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789"
var temp=''

function generatepass_<?php echo $module_tmp["nom"]; ?>(plength){
temp=''
for (i=0;i<plength;i++)
temp+=keylist.charAt(Math.floor(Math.random()*keylist.length))
return temp
}

function populateform_<?php echo $module_tmp["nom"]; ?>(enterlength){
document.getElementsByName("output_<?php echo $module_tmp["nom"];?>")["0"].value=generatepass_<?php echo $module_tmp["nom"]; ?>(enterlength)
}
</script>
<?php

if(isset($_POST["module"]))
{
	if ($_POST["module"]=="".$module_tmp["nom"]."")
	{	
		$NewCle = $_POST["output_".$module_tmp["nom"].""];
		$Cle ='';
		$Cle_old ='';
		$oldpass ='';
		rename("../".$module_tmp["module_dossier_fichier"]."/token/cle.php", "../".$module_tmp["module_dossier_fichier"]."/token/cle_old.php");	
		include "../".$module_tmp["module_dossier_fichier"]."/token/cle_old.php";
		
		// On �crit la cle dans cle.php
		$fichier = fopen("../module_".$module_tmp["nom"]."/token/cle.php", 'w+');
		fputs($fichier, '<?php $Cle'.$module_tmp["nom"].' = "'.$NewCle.'"; ?>'); 
		fclose($fichier);
		
		if ($module_tmp["nom"] == "cdt")
		{
			$Cle_old = $Clecdt;
			include "../".$module_tmp["module_dossier_fichier"]."/token/cle.php";
			$Cle = $Clecdt;
		}
		if ($module_tmp["nom"] == "grr")
		{
			$Cle_old = $Clegrr;
			include "../".$module_tmp["module_dossier_fichier"]."/token/cle.php";
			$Cle = $Clegrr;
		}
		if ($module_tmp["nom"] == "courriel")
		{
			$Cle_old = $Clecourriel;
			include "../".$module_tmp["module_dossier_fichier"]."/token/cle.php";
			$Cle = $Clecourriel;
		}
	
		// MAJ SQL
		$users_sso = db_tableau ("SELECT * FROM gt_sso");
		$nb = 0;
		foreach ($users_sso as $user_tmp)
		{
			$oldpass = decrypte($user_tmp["pass_".$module_tmp["nom"].""],$Cle_old);
			$newpass = Crypte($oldpass,$Cle);
			db_query("UPDATE `gt_sso` SET `pass_".$module_tmp["nom"]."`='".$newpass."' WHERE id_sso='".$user_tmp["id_sso"]."' "); 
			$nb++;
		}
		unlink("../".$module_tmp["module_dossier_fichier"]."/token/cle_old.php");
		?>
		<script type="text/javascript">
		alert("Nouvelle Cl\351 du module <?php echo $module_tmp["nom"]; ?> : <?php echo $NewCle; ?>.\nMise \340 jour de <?php echo $nb; ?> mot(s) de passe.");
		</script>
		<?php
		reload_close();
	}
}
else 
{
echo "<div class=\"content\" style=\"margin-top:20px;text-align:right\">";
echo "<form action=\"generer_cle.php?module=".$module_tmp["nom"]."\" onsubmit = \"return controle_formulaire_".$module_tmp["nom"]."();\" method=\"post\" enctype=\"multipart/form-data\">";
echo "<div style=\"width:90%;margin-left:30px;color:red;text-align:left;font-weight:bold;\">";
echo "<img src=\"../templates/module_".$module_tmp["nom"]."/menu.png\" style=\"margin-right:40px;\">Gestion de la Cl&eacute; de cryptage du module ".$module_tmp["nom"]."";
echo "</div>";
echo "<input type=\"text\" size=\"24\" name=\"output_".$module_tmp["nom"]."\">";
echo "<input type=\"button\" value=\"G&eacute;n&eacute;rer\" onClick=\"populateform_".$module_tmp["nom"]."(this.form.thelength_".$module_tmp["nom"].".value)\"><br>";
echo "<b>Dimension de la Cl&eacute; ? : </b>";
echo "<input type=\"text\" name=\"thelength_".$module_tmp["nom"]."\" size=\"3\" value=\"18\">";
echo "<div style=\"text-align:right;margin-top:10px;margin-right:10px;\"><input type=\"submit\" value=\"Mise &agrave; jour Cl&eacute; et SQL\" name=\"sql_".$module_tmp["nom"]."\" /></div>";
echo "</div>";
echo "<input type=\"hidden\" value=\"".$module_tmp["nom"]."\" name=\"module\" />";
echo "</form>";
echo "</div>";
}
}
require_once PATH_INC."footer.inc.php";
}
else
{
redir("index.php");
}
?>