<?php
////	INITIALISATION
////
$version = " V2.16.3-3.0";
$nom_module = "SSO";
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
require_once PATH_INC."header.inc.php";

//// Vérification admin
if ($_SESSION['user']['admin_general'] == 1)
{
  //// Test la présence du SSO
  $test = 0;
  $test_module = db_tableau("SELECT * FROM gt_module");
  foreach ($test_module as $module)
  {
	if ($module["nom"] == "sso")
	{$test = 1;}
  }

	if ($test == 0)
	{
	?>
	<script type="text/javascript">
	/* Installation du module */
  	var answer1 = confirm("Installation du module <?php echo $nom_module.$version; ?>.\nYov");
  	if (answer1)
  	{
  	<?php
	mysql_query("
	CREATE TABLE IF NOT EXISTS `gt_sso` (
  `id_sso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int(10) unsigned DEFAULT NULL,
   PRIMARY KEY (`id_sso`))
   ");
	mysql_query("CREATE TABLE IF NOT EXISTS `gt_module_sso` (`nom` text, `module_dossier_fichier` text )");
	mysql_query("INSERT INTO `gt_module` (`nom` ,	`module_path`)	VALUES ('sso', 'module_sso')");
	?>
	alert("Module <?php echo $nom_module.$version; ?> installé.\n\nRenommer ou supprimer le fichier Install.php !\nAttendre la redirection pour configurer le module.");
  	window.location.replace('../module_espaces/index.php');
  	}
	else 
	{window.location.replace('index.php');}
	</script>
	<?php 
	}
	else
	{
		// SUPPRESSION CRYPT_DECRYPT DE COMMUN (MAINTENANT DANS COMMUN/SSO)
		if(file_exists("../commun/crypt_decrypt.php"))
		{
			unlink("../commun/crypt_decrypt.php");	
		}
	?>
	<script type="text/javascript">
  	/* Mise à jour depuis la version précédente */
	alert("Modification pour le module <?php echo $nom_module.$version; ?> faites.\n\nYov");
	window.location.replace('index.php');
  	</script>
	<?php
	}
}
else 
{redir('index.php');}
?>