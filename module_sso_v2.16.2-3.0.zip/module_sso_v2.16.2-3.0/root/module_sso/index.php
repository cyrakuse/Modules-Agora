<?php
////	INIT
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
elements_width_height_type_affichage("medium","60px","bloc");
$liste_modules_sso = '';


if ($_SESSION['user']['admin_general'] == 1)
{
	////	SUPPRESSION D'ENREGISTREMENT(S) SSO
	//// PLUSIEURS
	if(isset($_GET['elements']))
	{
		foreach ($_GET['elements'] as $user_sso_tmp)
		{
			preg_match_all('#[0-9]+#',$user_sso_tmp,$extract);
			$id_utilisateur_tmp = $extract[0][0];
			db_query ("DELETE FROM gt_sso WHERE id_utilisateur ='".$id_utilisateur_tmp."'");
		}
		////	Redirection
		redir('index.php?affichage_users=espace');
	}

	////	UN
	if(isset($_GET['action']))
	{
		if(($_GET['action']) == 'supprimer_un')
			{
				db_query ("DELETE FROM gt_sso WHERE id_utilisateur ='".$_GET['id_utilisateur']."'");
			}
	
		////	Redirection
		redir('index.php?affichage_users='.$_GET['affichage_users'].'');
	}
	
if (!isset($_GET['affichage_users']))
{ redir('index.php?affichage_users=espace'); }

////  AFFICHAGE ADMINISTRATEUR	
	
//// AFFICHAGE UTILISATEURS GROUPE / TOUS
	$affichage_users = $_GET['affichage_users'];
	
	$test_module_utilisateurs = db_valeur("SELECT count(*) FROM gt_jointure_espace_module WHERE id_espace = '".$_SESSION['espace']['id_espace']."' and nom_module = 'utilisateurs'");
	if (!$test_module_utilisateurs)
	{
		require "../module_utilisateurs/commun.inc.php";				
	}
	$users_total = db_tableau("SELECT * FROM gt_utilisateur WHERE 1 ".sql_utilisateurs_espace()." ".alphabet_sql("nom")." ".tri_sql($objet["utilisateur"]["tri"]));

?>

<table id="contenu_principal_centre" style="width:99%;margin:0 auto 0 15px;">
	
	<?php
	echo "<div class=\"content\" style=\"margin:auto auto 15px auto;width:96%\">";
	echo "<img src=\"../templates/module_sso/menu.png\" style=\"height:30px;margin-right:10px;\">";
	echo "<b>".$trad["SSO_titreMenuAdmin"]."</b>";
	$select_users_site = $style_users_site = "";
	if($affichage_users=="site")	
	{ $select_users_site = "selected";  $style_users_site = "style='font-weight:bold;".STYLE_SELECT_RED."'";   }
	echo "<select id='select_affichage_users' onChange=\"redir('index.php?affichage_users='+this.value);\" class='input_select' ".$style_users_site.">";
	echo "<option value=\"espace\">".$trad["UTILISATEURS_utilisateurs_espace"]."</option>";
	echo "<option value=\"site\" ".infobulle($trad["UTILISATEURS_utilisateurs_site_infos"])." ".$select_users_site.">".$trad["UTILISATEURS_utilisateurs_site"]."</option>";
	echo "</select>";
	echo "</div>";
	?>	
	<tr>
	<td id="menu_gauche_block_td">
		<div id="menu_gauche_block_flottant">
			<div class="menu_gauche_block content">
				<?php
				echo "<div class='menu_gauche_ligne lien' onclick=\"edit_iframe_popup('generer_cle.php');\" ".infobulle($trad["generer_cle"])."><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/connexion.png\" /></div><div class='menu_gauche_txt'>".$trad["generer_cle"]."</div></div>";
				echo "<hr>";
				////	IMPORTER DES CONTACTS
				echo "<div class='menu_gauche_ligne lien' onclick=\"edit_iframe_popup('sso_import.php');\" ".infobulle($trad["sso_import"])."><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/import.png\" /></div><div class='menu_gauche_txt'>".$trad["sso_importer"]."</div></div>";
				echo "<hr>";
				////	MENU ELEMENTS
				$cfg_menu_elements = array("objet"=>$objet["utilisateur"], "confirmer_suppr_bis"=>true);
				require "elements_selection.php";
				////	MENU ALPHABET / D'AFFICHAGE / DE TRI
				echo menu_alphabet("gt_utilisateur", "nom", sql_utilisateurs_espace(), php_self());
				//echo menu_type_affichage();
				echo menu_tri($objet["utilisateur"]["tri"],"tri_utilisateur");
				echo "<div class='menu_gauche_ligne'><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/info.png\" /></div><div class='menu_gauche_txt'>".count($users_total)." ".(count($users_total)>1?$trad["UTILISATEURS_utilisateurs"]:$trad["UTILISATEURS_utilisateur"])."</div></div>";
				?>
			</div>
		</div>
	</td>
	<td>
	<form name="form_sso" action="">

	<?php
		////	AFFICHAGE DES UTILISATEURS
		////
		foreach(tableau_elements_page($users_total) as $user_tmp)
		{
			////	INIT
			$droit_modif_utilisateur = droit_modif_utilisateur($user_tmp["id_utilisateur"]);
			$id_menu_contextuel = "menu_context_user_".$user_tmp["id_utilisateur"];
			
			////	NOM-PRENOM / DETAILS (adresse, tel, etc)
			$nom_prenom_user = "".$user_tmp["nom"]." ".$user_tmp["prenom"]." (".$user_tmp["identifiant"].")";
			
			////	DIV CONTENEUR
			$id_div_user = div_element($objet["utilisateur"], $user_tmp["id_utilisateur"]);
			$lien_popup = "class=\"lien\" onmousemove=\"pas_propager_click(this);\" onclick=\"edit_iframe_popup('sso_edit?id_utilisateur=".$user_tmp["id_utilisateur"]."');selection_element('".$id_div_user."');\"";
			
				// MENU CONTEXTUEL
				echo "<div class='noprint' style='float:left;margin:0px;'>";
					echo "<div class='menu_context' id='".$id_menu_contextuel."'>";
						
						//	MODIFIER  +  SUPPRIME DEFINITIVEMENT
						$menu_edit = "";
						$menu_edit .= "<div class='menu_context_ligne lien' onclick=\"edit_iframe_popup('sso_edit.php?id_utilisateur=".$user_tmp["id_utilisateur"]."');\" onMouseMove='pas_propager_click(this);'><div class='menu_context_img'><img src=\"".PATH_TPL."divers/crayon.png\" /></div><div class='menu_context_txt'>".$trad["SSO_modifier"]."</div></div>";
						$menu_edit .= "<div class='menu_context_ligne lien' onclick=\"confirmer('".addslashes($trad["SSO_suppr_identifiant"])."','index.php?affichage_users=".$_GET["affichage_users"]."&action=supprimer_un&id_utilisateur=".$user_tmp["id_utilisateur"]."');\" onMouseMove='pas_propager_click(this);'><div class='menu_context_img'><img src=\"".PATH_TPL."divers/supprimer.png\" /></div><div class='menu_context_txt'>".$trad["SSO_suppr_identifiant"]."</div></div>";
						
						if($menu_edit!="")	echo $menu_edit;
					echo "</div>";
					
					// ICONE "PLUS" & AFFICHAGE DU MENU CONTEXTUEL
					echo "<img src=\"".PATH_TPL."divers/options.png\" style='height:26px;' id='icone_".$id_menu_contextuel."' />";
					echo "<script type='text/javascript'> menu_contextuel('".$id_menu_contextuel."','".$id_div_user."'); </script>";
				echo "</div>";

				// SIMPLE CLICK SUR LE BLOCK -> SELECTION DU BLOCK  /  DOUBLE CLICK SUR LE BLOCK -> MODIFIER
				$dblclickBlock = ($droit_modif_utilisateur==1)  ?  "edit_iframe_popup('sso_edit.php?id_utilisateur=".$user_tmp["id_utilisateur"]."');"  :  "";
				echo "<script type='text/javascript'>  click_dblclick(\"".$id_div_user."\", \"selection_element('".$id_div_user."');\", \"".$dblclickBlock."\");  </script>";

				//	STATUT DE L'UTILISATEUR FLOTTANT (affichage block)
				$img_statut_user = (preg_match("/admin/i",$statut_user))  ?  "&nbsp; <img src=\"".PATH_TPL."module_utilisateurs/acces_".$statut_user.".png\" style='cursor:help;height:20px;' ".infobulle($trad["UTILISATEURS_".$statut_user])." />"  :  "";
				if($_REQUEST["type_affichage"]=="bloc" && $img_statut_user!="")   echo "<div style='float:right;margin:3px;'>".$img_statut_user."</div>";

				////	AFFICHAGE BLOCK / LISTE
				echo "<div class='div_elem_contenu'>";
					echo "<table class='div_elem_table'><tr>";
					if($_REQUEST["type_affichage"]=="bloc")
					{
						echo "<td class='menu_gauche_img lien' ".$lien_popup."><img style=\"width:25px;\" src=\"../templates/module_sso/utilisateur.png\"></td>";
						echo "<td style='vertical-align:middle;text-align:left;'>";
						echo "<div style='font-size:12px;' ".$lien_popup.">".$nom_prenom_user."</div>";
						echo "<br />";
						echo "<div>";
						////  TEST MODULE SSO ET AFFICHAGE
						$liste_modules_sso = db_tableau("SELECT * FROM gt_module_sso");
						foreach($liste_modules_sso as $module_sso_tmp)	
						{
							echo "<img style=\"width:20px;margin:0 2px 0 10px\" src=\"../templates/module_".$module_sso_tmp["nom"]."/menu.png\">";
							$user_sso='';
							$user_sso = db_valeur("SELECT user_".$module_sso_tmp['nom']." FROM gt_sso WHERE id_utilisateur = '".$user_tmp['id_utilisateur']."'");
							if ($user_sso == '')
							{echo "<b style=\"color:red;\">?</b>";}
							else
							{echo "<b style=\"color:blue;\">OK</b>";}
						}
					}
					echo "</tr></table>";
				echo "</div>";
			////	FIN DIV USER
			echo "</div>";
		}
		
		echo "<form>";
		////	PAS D'UTILISATEUR
		if(count($users_total)==0)	echo "<div class='div_elem_aucun'>".$trad["UTILISATEURS_aucun_utilisateur"]."</div>";

		////	PAGER
		echo menu_pager(count($users_total));				
}
else
{
$user = db_ligne ("SELECT * FROM `gt_utilisateur` WHERE `id_utilisateur` = '".$_SESSION['user']['id_utilisateur']."'");
	echo "<body onload=\"edit_iframe_popup('sso_edit.php?id_utilisateur=".$user["id_utilisateur"]."');\">";
   echo "<div class=\"contenu_principal_centre\" style=\"padding-top:10px;margin:auto;\">";
	echo "<div class=\"content\" style=\"margin:0 auto 15px 30px;width:90%\">";
	echo "<img src=\"../templates/module_sso/menu.png\" style=\"height:30px;margin-right:10px;\">";
	echo "<b>".$trad["SSO_titreMenuAdmin"]."</b>";
	echo "<br />";
	echo "</div>";
	echo "<div style=\"margin: 0 auto 0 30px;width:96%\">";
	echo "<div style=\"width:270px;height:40px;padding-top:15px;cursor:pointer;\" onclick=\"edit_iframe_popup('sso_edit.php?id_utilisateur=".$user["id_utilisateur"]."');\" ".infobulle($trad["SSO_infoBulleMenu"].$user["nom"]." ".$user_tmp["prenom"])." class=\"div_elem_deselect\"><img style=\"width:25px;margin: 0 5px 0 5px;\" src=\"../templates/module_sso/utilisateur.png\">".$user["nom"]." ".$user["prenom"]." (".$user["identifiant"].")</div>";
	echo "</div>";
	echo "</div>";
	echo "</body>";
}

require PATH_INC."footer.inc.php"; 
?>