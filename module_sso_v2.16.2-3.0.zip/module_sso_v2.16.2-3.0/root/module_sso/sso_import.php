<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",false);
require "commun.inc.php";
require_once PATH_INC."header.inc.php";
require "../commun/sso/crypt_decrypt.php";
$modules = db_tableau ("SELECT * FROM gt_module_sso");
$nb_update = 0;
$nb_insert = 0;

//// Vérification admin
if ($_SESSION['user']['admin_general'] == 1)
{
?>

<script type="text/javascript">
////	Redimensionne
resize_iframe_popup(550,250);

////    On contrôle les champs
function controle_formulaire()
{
	if (get_value("groupe")=="")			{ alert("Entrer un nom de groupe");			return false; }
	if (get_value("file")=="")			   { alert("Choisir un fichier csv");			return false; }
}
</script>

<?php 
if (!isset($_FILES['file']))
{
?>
<div class="content" style="margin-top:20px;">
<br />
<div style='position:fixed;top:0px;left:0px;z-index:100000;width:100%;color:#000;font-weight:bold;font-size:13px;text-align:center;padding:7px;background-image:url(../templates/divers/popup_fond_titre.jpg);background-position:bottom left;'>
<p>Import d'identifiants et de mots de passe SSO (CSV)</b><br /><a href="sso.csv">(Voir l'exemple)</a></p>
</div>
<br />
<form style="text-align:right;" onsubmit="return controle_formulaire();" action="sso_import.php" method="post" enctype="multipart/form-data" name="form"> 
<p><input type="file" name="file" /></p>
<hr />
<p>Choisir le premier champs du fichier CSV ?
<SELECT name="champs">
<OPTION value="identifiant">Identifiant</OPTION>
<OPTION value="nom">Nom</OPTION>
</SELECT>
</p>
<hr />
<p>Choisir le(s) module(s) SSO pour l'import des identifiants SSO :
<SELECT name="module">
<OPTION value="tous">Tous</OPTION>
<?php
foreach ($modules as $module_tmp)
{echo "<OPTION value=\"".$module_tmp["nom"]."\">".$module_tmp["nom"]."</OPTION>";}
?>
</SELECT>
</p>
<hr />
<input class="button" type="submit" name="submit" value="Valider"> 
</form>
</div>

<?php
}

//lire un csv et ajouter le groupe et les utilisateurs 

if (isset($_FILES['file'])) 
{
$nb = 0;
$file = $_FILES['file']['tmp_name']; 
$handle = fopen($file,'r');

while ($data = fgetcsv($handle, 1000, ";")) 
{
	if ($_POST["module"])
	{
	
		if ($_POST["module"] != "tous")
		{
			$modules = db_tableau ("SELECT * FROM gt_module_sso WHERE nom = '".$_POST["module"]."'");
		}
		
		foreach ($modules as $module_tmp)
		{
			//// CLE DE CRYPTAGE
			require "../".$module_tmp["module_dossier_fichier"]."/token/cle.php";
			$Cle = '';
			
			if ($module_tmp["nom"] == "cdt")
			{
			$Cle = $Clecdt;
			}
			if ($module_tmp["nom"] == "grr")
			{
			$Cle = $Clegrr;
			}
			if ($module_tmp["nom"] == "courriel")
			{
			$Cle = $Clecourriel;
			}		
			
			//// INSERTION OU UPDATE SQL
			$id_utilisateur = db_valeur ("SELECT id_utilisateur FROM gt_utilisateur WHERE ".$_POST["champs"]." = '".$data[0]."' ");
			if ($id_utilisateur)
			{
				$crypt_pass = Crypte($data[2],$Cle);
				$id_utilisateur_sso = db_valeur ("SELECT id_utilisateur FROM gt_sso WHERE id_utilisateur = ".$id_utilisateur."");
				if ($id_utilisateur_sso)
				{
					db_query("UPDATE gt_sso SET `user_".$module_tmp["nom"]."` = '".$data[1]."' , `pass_".$module_tmp["nom"]."` = '".$crypt_pass ."' WHERE id_utilisateur = '".$id_utilisateur_sso."'");
					$nb_update ++;
				}
				else
				{
					db_query("INSERT INTO gt_sso SET `id_utilisateur`='".$id_utilisateur."', `user_".$module_tmp["nom"]."`='".$data[1]."', `pass_".$module_tmp["nom"]."`='".$crypt_pass ."'");
					$nb_insert ++;
				}
			}
			else { ?>
			<script type="text/javascript">
			alert("L'utilisateur <?php echo $data[0]; ?> n'existe pas dans agora !");
			</script>
			<?php }
		}
	}
}

fclose ($handle);

If (($nb_update == 0) && ($nb_insert == 0))
{ ?>
<script type="text/javascript">
alert("Erreur dans le fichier CSV");
</script>
<?php
} else { ?>
<script type="text/javascript">
alert("Ajout de <?php echo $nb_insert; ?> identifiant(s).\nMise a jour de <?php echo $nb_update; ?> identifiant(s).");
</script>
<?php
}
reload_close();
}
}
?>