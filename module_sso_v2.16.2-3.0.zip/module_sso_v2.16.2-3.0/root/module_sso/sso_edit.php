<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",false);
require "commun.inc.php";
require_once PATH_INC."header.inc.php";
require "../commun/sso/crypt_decrypt.php";

if(isset($_GET["id_utilisateur"]))
{
	$id_Utilisateur_edit = $_GET["id_utilisateur"];
}
?>

<script type="text/javascript">
////	Redimensionne
resize_iframe_popup(590,400);
</script>

<?php
$liste_modules_sso = db_tableau("SELECT * FROM gt_module_sso" );
foreach($liste_modules_sso as $module_sso)
{
	$module_sso_test = db_valeur("SELECT count(*) FROM gt_jointure_espace_module WHERE id_espace = ".$_SESSION["espace"]["id_espace"]." and nom_module = '".$module_sso["nom"]."'");
	if ($module_sso_test)
	{
		////  Cryptage Decryptage
		require "../".$module_sso["module_dossier_fichier"]."/token/cle.php";

		$user_sso_tmp = '';
		$pass_sso_tmp = '';
		$Cle_tmp ='';

		if ($module_sso["nom"] == "cdt")
		{
			$Cle_tmp = $Clecdt;
			$TRAD_module = "CDT";
		}
		if ($module_sso["nom"] == "grr")
		{
			$Cle_tmp = $Clegrr;
			$TRAD_module = "GRR";
		}
		if ($module_sso["nom"] == "courriel")
		{
			$Cle_tmp = $Clecourriel;
			$TRAD_module = "COURRIEL";
		}
		
			if ($module_sso["nom"] == "gepi")
		{
			$Cle_tmp = $Clegepi;
			$TRAD_module = "GEPI";
		}

		//// MAJ OU INSERTION DES DONNEES DANS LA BASE SQL

		if(isset($_POST["id_utilisateur"]) && isset($_POST["module"]))
		{
			if ($_POST["module"]=="".$module_sso["nom"]."")
			{
				$id_Utilisateur_edit = $_POST["id_utilisateur"];
			
				////	MODIF / AJOUT : IDENTIFIANTS CDT
				
				$corp_sql = " user_".$module_sso["nom"]."='".$_POST["user_".$module_sso["nom"].""]."', pass_".$module_sso["nom"]."='".Crypte($_POST["pass_".$module_sso["nom"].""],$Cle_tmp)."'";
			
				if($_POST["id_sso"] > 0)		
				{
					 db_query("UPDATE gt_sso SET ".$corp_sql." WHERE id_sso='".$_POST["id_sso"]."'");
				}
				else	
				{
					 db_query("INSERT INTO gt_sso SET id_utilisateur='".$_POST["id_utilisateur"]."', ".$corp_sql."");
				}
			
				reload_close();
			}
		}

		?>
		<script type="text/javascript">
		////    On contr�le les champs
		function controle_formulaire_<?php echo $module_sso["nom"] ;?> () 
		{ 
			if (get_value("user_<?php echo $module_sso["nom"]; ?>")=="")			{ alert("<?php echo $trad["SSO_specifier_user"]; ?>");			return false; }
			if (get_value("pass_<?php echo $module_sso["nom"]; ?>")=="")		{ alert("<?php echo $trad["SSO_specifier_pass"]; ?>");		return false; }
			alert ("<?php echo $trad["SSO_user_ok"]; ?>");
		}
		</script>

		<?php	
		////  AFFICHAGE DES DONNES DE L'UTILISATEUR ET FORM
		////
		// DONNEES
		$Utilisateur = db_ligne("SELECT * FROM `gt_utilisateur` WHERE `id_utilisateur` = '".$id_Utilisateur_edit."'");
				
		if ($Utilisateur)
		{
		echo "
		<div class=\"content\" style=\"margin-top:20px;text-align:right\"> 	
		<p style=\"text-align:center;color:red;\">".$trad["SSO_titre1"]."".$trad["".$TRAD_module."_nom_module"]."".$trad["SSO_titre2"]."</p>
		<p style=\"text-align:center;font-size:1.1em;\"><b>".$Utilisateur["prenom"]." ".$Utilisateur["nom"]." (".$Utilisateur["identifiant"].")</b></p>";

		// FORMULAIRE LOGIN MDP
		$corpsql = "FROM `gt_sso` WHERE `id_utilisateur` = '".$id_Utilisateur_edit."'";
		$user_sso_tmp = db_valeur("SELECT `user_".$module_sso["nom"]."` ".$corpsql."");
		$pass_sso_tmp = db_valeur("SELECT `pass_".$module_sso["nom"]."` ".$corpsql."");
		$id_sso= db_valeur("SELECT `id_sso` ".$corpsql."");

		if (($user_sso_tmp) && (!isset($_POST["modifier_".$module_sso["nom"].""])))
		{
		echo "<form action=\"sso_edit.php?id_utilisateur=".$id_Utilisateur_edit."\" method=\"post\" enctype=\"multipart/form-data\">";
		echo "<br />";
		echo "<div style=\"width:90%;margin-left:30px;color:red;text-align:left;font-weight:bold;\">";
		echo "<img src=\"../templates/module_".$module_sso["nom"]."/menu.png\" style=\"margin-right:40px;\">";
		echo "".$trad["SSO_configuration"]."";
		echo "</div>";
		echo "<div style=\"text-align:right;margin-top:10px;margin-right:10px;\"><input type=\"submit\" value=\"Modifier\" name=\"modifier_".$module_sso["nom"]."\" /></div>";
		echo "</div>";
		echo "</form>";
		}

		else
		{
		echo "<br />";
		echo "<form action=\"".php_self()."\" method=\"post\" enctype=\"multipart/form-data\" onsubmit=\"return controle_formulaire_".$module_sso["nom"]."();\" style=\"padding:15px;font-weight:bold;\">";
		echo "<img src=\"../templates/module_".$module_sso["nom"]."/menu.png\" style=\"margin-right:50px;\">";
		echo $trad["SSO_user"];
		echo "<input type=\"text\" value=\"".$user_sso_tmp."\" name=\"user_".$module_sso["nom"]."\" style=\"width:300px;\" /><br /><br />";
		echo $trad["SSO_password"];
		echo "<input type=\"password\" name=\"pass_".$module_sso["nom"]."\" style=\"width:300px;\" autocomplete=\"off\" /><br /><br />";	
		echo "<input type=\"hidden\" value=\"".$id_sso."\" name=\"id_sso\" />";
		echo "<input type=\"hidden\" value=\"".$id_Utilisateur_edit."\" name=\"id_utilisateur\" />";
		echo "<input type=\"hidden\" value=\"".$module_sso["nom"]."\" name=\"module\" />";
		echo "<div style=\"text-align:right;margin-top:10px;\">";
		echo "<input type=\"submit\" value=\"".$trad["SSO_valider"]."\" name=\"submit\" />";
		echo "</div>";
		echo "</form>";
		echo "</div>";
		}
		}		
	}
}

require_once PATH_INC."footer.inc.php";
?>