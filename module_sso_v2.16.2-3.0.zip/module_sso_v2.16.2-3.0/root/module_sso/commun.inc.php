<?php
////	INITIALISATION
////
@define("MODULE_NOM","sso");
@define("MODULE_PATH","module_sso");
require_once "../includes/global.inc.php";
?>
