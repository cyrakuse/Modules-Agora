<?php
///  Menu principal
$trad["CDT_nom_module"] = "Cahier de texte";
$trad["CDT_nom_module_header"] = "Cahier de texte";
$trad["CDT_description_module"] = "Cahier de texte";

///  Int�gration SSO
$trad["CDT_user"]="Nom d'utilisateur";
$trad["CDT_password"]="Mot de passe";
$trad["CDT_specifier_user"] = "Entrer un nom d'utilisateur !";
$trad["CDT_specifier_pass"] = "Entrer un mot de passe !";
$trad["CDT_user_ok"] = "Enregistrement fait !";
$trad["CDT_titrePopUpAdmin"] = "Identifiants de connexion dans le cahier de texte pour :";
$trad["CDT_valider"] = "Enregistrer";

?>
