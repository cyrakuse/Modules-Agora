<?php
/*
CHEMIN RELATIF DU CAHIER DE TEXTE (SANS HTTP) :   
CDT EST A LA RACINE D'AGORA
"../cdt/" 
*/

$url = "../cdt/";

//// FICHIERS POUR LOGIN ET LOGOUT
$login = "authentification/auth.php";
$logout = "deconnexion.php";
?>
