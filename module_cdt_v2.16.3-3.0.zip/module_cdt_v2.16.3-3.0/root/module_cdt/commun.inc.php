<?php
////	INITIALISATION
////
@define("MODULE_NOM","cdt");
@define("MODULE_PATH","module_cdt");
require_once "../includes/global.inc.php";
//add_logs("connexion");
?>
