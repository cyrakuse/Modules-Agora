<?php
///  Menu principal
$trad["HESK_nom_module"] = "Hesk";
$trad["HESK_nom_module_header"] = "Hesk";
$trad["HESK_description_module"] = "Help Desk";

///  Menu lateral
$trad["HESK_acces_utilisateur"]="Accès Utilisateur";
$trad["HESK_acces_technicien"]="Accès Technicien";

?>
