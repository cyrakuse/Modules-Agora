<?php
////  Initialisation
////
include_once "../includes/global.inc.php";
$Clegrr = "ClepourlemoduleHesk";
?>