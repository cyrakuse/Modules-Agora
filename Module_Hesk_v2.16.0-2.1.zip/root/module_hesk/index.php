<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",true);
include "commun.inc.php";
include PATH_INC."header_menu.inc.php";

////  Sélection informations user SQL 
////
$idssoQuery = db_query('SELECT `user_hesk`, `pass_hesk` FROM `gt_sso` WHERE `id_utilisateur` = "'.$_SESSION['user']['id_utilisateur'].'"');
while($dataIdssoQuery = mysql_fetch_assoc($idssoQuery))
	{
		$_SESSION['user_hesk'] = $dataIdssoQuery['user_hesk'];
		$_SESSION['pass_hesk'] = $dataIdssoQuery['pass_hesk'];
	} 
echo '
<script type="text/javascript">
	function resizeFrame(f) {
		hauteur = window.innerHeight - 150;//ok firefox (other ???)
		f.style.height =  hauteur + "px";
	} 
</script> 
';		
//// Insertion dans l'iframe des identifiants pour HESK et submit automatique
////
?>

<script type="text/javascript">
	function connexion_hesk() 
	{
		<?php
		$idssoQuery = db_query('SELECT `user_hesk`, `pass_hesk` FROM `gt_sso` WHERE `id_utilisateur` = "'.$_SESSION['user']['id_utilisateur'].'"');
		while($dataIdssoQuery = mysql_fetch_assoc($idssoQuery))
		{
		$user_hesk = $dataIdssoQuery['user_hesk'];
		$pass_hesk = $dataIdssoQuery['pass_hesk'];
		}
		include "cle.php";
		include "../commun/crypt_decrypt.php";
		?>
		document.getElementById("agoraFrame").contentWindow.document.form1.user.value = "<?php echo $user_hesk;?>";
		document.getElementById("agoraFrame").contentWindow.document.form1.pass.value = "<?php echo Decrypte($pass_hesk,$Clehesk);?>";
		document.getElementById("agoraFrame").contentWindow.document.form1.submit();
		}
</script> 


<table id="contenu_principal_table"><tr>
	<td id="menu_gauche_block_td">
	<div id="menu_gauche_block_flottant">
		<div class="menu_gauche_block content">
			<table width="100%">

<?php
			
			echo "<tr class=\"lien\" onclick=\"index.php\"><td class=\"left_menu_block_ico\"><img src=\"".PATH_TPL."divers/acces_utilisation.png\" /></td><td class=\"left_menu_block_txt\"><a href=\"index.php\">".$trad["HESK_acces_utilisateur"]."</a></td></tr>";
			echo "<tr class=\"lien\" ><td class=\"left_menu_block_ico\"><img src=\"".PATH_TPL."divers/acces_administration.png\" /></td><td class=\"left_menu_block_txt\"><a href=\"index.php?type=admin\">".$trad["HESK_acces_technicien"]."</a></td></tr>";
			
			//echo "<tr><td colspan='2'><hr /></td></tr>";			
?>
</table>
		</div>
	</div>
	</td>
	<td>
<?php
echo "<table id=\"bloc_principal\" width=\"100%\" height=\"100%\" cellspacing=\"10px\" cellspacing=\"10px\"><tr>";
	////	Hesk
	////
	echo "<td>";// Bloc Principal (Iframe Hesk)
?>
<div id="agoraDiv" style="width:100%;padding-top:23px;margin-top:-20px;" class="div_element_deselect">

<?php
if ($_GET["type"]=="admin")
{
?>
<iframe src="./hesk/admin/" id="agoraFrame" name="agoraFrame" onload="connexion_hesk();" width="100%" style="height:100%;width:100%;border:0px;margin-top:-20px;"></iframe>
<?php
}
else
{
?>
<iframe src="./hesk/" id="agoraFrame" name="agoraFrame" width="100%" style="height:100%;width:100%;border:0px;margin-top:-20px;"></iframe>
<?php
}

?>
</div>
<?php 
	echo "</td>";
echo "</tr></table>";
echo '
<script type="text/javascript">
	resizeFrame(document.getElementById("agoraFrame")); 
</script> 
';
?>
</td>
</tr></table>
<?php
include_once PATH_INC."footer.inc.php"; 
?>