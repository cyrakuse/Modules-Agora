<?php
////	INITIALISATION
////
@define("MODULE_NOM","hesk");
@define("MODULE_DOSSIER","module_hesk");
include_once "../includes/global.inc.php";
?>
