<?php
////  Protection de l'acc�s au fichier
include_once "../includes/global.inc.php";
////  Cryptage Decryptage
include "cle.php";

if(isset($_POST["id_utilisateur"]) && isset($_POST["module"]))
{
	if ($_POST["module"]=="hesk")
	{
		$id_Utilisateur_edit = $_POST["id_utilisateur"];
	
		////	MODIF / AJOUT : IDENTIFIANTS Hesk
		$corp_sql = " user_hesk=".db_insert(@$_POST["user_hesk"]).", pass_hesk=".db_insert(Crypte(@$_POST["pass_hesk"],$Clehesk))."";
	
		if($_POST["id_sso"] > 0)		{ mysql_query("UPDATE gt_sso SET ".$corp_sql." WHERE id_sso=".db_insert($_POST["id_sso"])); }
		else							{ mysql_query("INSERT INTO gt_sso SET id_utilisateur='".$_POST["id_utilisateur"]."', ".$corp_sql);}
	
		reload_close();
	}
}
?>
<script type="text/javascript">
////    On contr�le les champs
function controle_formulaire_hesk()
{
	if (get_value("user_hesk")=="")			{ alert("<?php echo $trad["HESK_specifier_user"]; ?>");			return false; }
	if (get_value("pass_hesk")=="")		{ alert("<?php echo $trad["HESK_specifier_pass"]; ?>");		return false; }
	alert ("<?php echo $trad["HESK_user_ok"]; ?>");
}
</script>

<?php		
		$idUtilisateurQuery = mysql_query('SELECT `nom`, `prenom`, `identifiant` FROM `gt_utilisateur` WHERE `id_utilisateur` = "'.$id_Utilisateur_edit.'"');
		while($dataIdUtilisateurQuery = mysql_fetch_assoc($idUtilisateurQuery))
			{
				$nomUtilisateur=$dataIdUtilisateurQuery['nom'];			
				$prenomUtilisateur=$dataIdUtilisateurQuery['prenom'];
				$identifiantUtilisateur=$dataIdUtilisateurQuery['identifiant'];
			}

if ($nomUtilisateur)
{
echo '
<div class="content" style="margin-top:20px;text-align:right"> 	
<p style="text-align:center;color:red;">'.$trad["HESK_titrePopUpAdmin"].'</p>
<p style="text-align:center;font-size:1.1em;"><b>'.$prenomUtilisateur.' '.$nomUtilisateur.' ('.$identifiantUtilisateur.')</b></p>';


$idssoQuery = mysql_query('SELECT `user_hesk`, `pass_hesk`, `id_sso` FROM `gt_sso` WHERE `id_utilisateur` = "'.$id_Utilisateur_edit.'"');
while($dataIdssoQuery = mysql_fetch_assoc($idssoQuery))
{
	$user_hesk=$dataIdssoQuery['user_hesk'];
	$pass_hesk=Decrypte($dataIdssoQuery['pass_hesk'],$Clehesk);
	$id_sso=$dataIdssoQuery['id_sso'];
}
echo "<br />";
echo '<form action="'.php_self().'" method="post" enctype="multipart/form-data" onsubmit="return controle_formulaire_hesk();" style="padding:15px;font-weight:bold;">';
echo '<img src="../templates/module_hesk/menu.png" style="margin-right:60px;">';
echo $trad["HESK_user"].' : <input type="text" value="'.$user_hesk.'" name="user_hesk" style="width:300px;" /><br /><br />';
echo $trad["HESK_password"].' : <input type="password" value="'.$pass_hesk.'" name="pass_hesk" style="width:300px;" /><br /><br />';	
echo '<input type="hidden" value="'.$id_sso.'" name="id_sso" />';
echo '<input type="hidden" value="'.$id_Utilisateur_edit.'" name="id_utilisateur" />';
echo '<input type="hidden" value="hesk" name="module" />';
echo '<div style="text-align:right;margin-top:20px;"><input type="submit" value="'.$trad["HESK_valider"].'" name="submit" /></div>';
echo '</form>';
echo '</div>';
}
?>