<?php
////	INITIALISATION
////
@define("MODULE_NOM","sondage");
@define("MODULE_PATH","module_sondage");
include_once "../includes/global.inc.php";
$config["module_espace_options"]["sondage"] = array("ajout_sondage_admin");
$config["tri_sondage"] = modif_tri_defaut_personnes(array("titre@@asc","titre@@desc","date_crea@@asc","date_crea@@desc"));
$objet["sondage_dossier"]	= array("type_objet"=>"sondage_dossier", "cle_id_objet"=>"id_dossier", "type_contenu"=>"sondage", "cle_id_contenu"=>"id_sondage", "table_objet"=>"gt_sondage_dossier");
$objet["sondage"]			= array("type_objet"=>"sondage", "cle_id_objet"=>"id_sondage", "type_conteneur"=>"sondage_dossier", "cle_id_conteneur"=>"id_dossier", "table_objet"=>"gt_sondage");
patch_dossier_racine($objet["sondage_dossier"]);


////	DROIT AJOUT ACTUALITE
////
function droit_ajout_sondage()
{
	if($_SESSION["user"]["id_utilisateur"]>0  and  (option_module("ajout_sondage_admin")!=true or $_SESSION["espace"]["droit_acces"]==2))  return true;
}


////	SUPPRESSION D'UN SONDAGE
////
function suppr_sondage($id_sondage)
{
	global $objet;

	
	// On supprime l'objet en question
	if(droit_acces($objet["sondage"],$id_sondage) >= 2)
	{
		suppr_objet($objet["sondage"],$id_sondage);
	}
}


////	SUPPRESSION D'UN DOSSIER
////
function suppr_sondage_dossier($id_dossier)
{
	global $objet;
	if(droit_acces($objet["sondage_dossier"],$id_dossier)==3 and $id_dossier > 1)
	{
		// on créé la liste des dossiers & on supprime chaque dossier
		$liste_dossiers_suppr = arborescence($objet["sondage_dossier"],$id_dossier,"tous");
		foreach($liste_dossiers_suppr as $infos_dossier)
		{
			// On supprime chaque sondage du dossier puis le dossier en question
			$liste_sondages = db_tableau("SELECT * FROM gt_sondage WHERE id_dossier='".$infos_dossier["id_dossier"]."' ");
			foreach($liste_sondages as $infos_sondage)	{ suppr_sondage($infos_sondage["id_sondage"]); }
			suppr_objet($objet["sondage_dossier"], $infos_dossier["id_dossier"]);
		}
	}
}


////	DEPLACEMENT D'UN SONDAGE
////
function deplacer_sondage($id_sondage, $id_dossier_destination)
{
	global $objet;
	////	Accès en écriture au sondage et au dossier de destination
	if(droit_acces($objet["sondage"],$id_sondage)>=2  and  droit_acces($objet["sondage_dossier"],$id_dossier_destination)>=2)
	{
	////	Si on deplace à la racine, on donne les droits d'accès de l'ancien dossier
		racine_copie_droits_acces($objet["sondage"], $id_sondage, $objet["sondage_dossier"], $id_dossier_destination);
	////	On déplace le sondage
		db_query("UPDATE gt_sondage SET id_dossier=".db_format($id_dossier_destination)." WHERE id_sondage=".db_format($id_sondage).";");
	}
}


////	DEPLACEMENT D'UN DOSSIER
////
function deplacer_sondage_dossier($id_dossier, $id_dossier_destination)
{
	global $objet;
	////	Accès total au dossier en question  &  accès en écriture au dossier destination  &  controle du déplacement du dossier
	if(droit_acces($objet["sondage_dossier"],$id_dossier)==3  and  droit_acces($objet["sondage_dossier"],$id_dossier_destination)>=2  and  controle_deplacement_dossier($objet["sondage_dossier"],$id_dossier,$id_dossier_destination)==1) {
		db_query("UPDATE gt_sondage_dossier SET id_dossier_parent=".db_format($id_dossier_destination)." WHERE id_dossier=".db_format($id_dossier));
	}
}


////	CLOTURER UN SONDAGE
////
function cloturer_sondage($id_sondage)
{
	global $objet;
	////	Accès en écriture au sondage
	if(droit_acces($objet["sondage"],$id_sondage)>=2)
	{
	////	On cloture le sondage
		db_query("UPDATE gt_sondage SET cloturer=1 WHERE id_sondage=".db_format($id_sondage).";");
	}
}


// transforme une date fr (jj/mm/aaaa) en date us (aaaa-mm-jj)
function versDateUS2($madate)
{
	if ($madate!="")
	{
		$annee    = substr($madate, 6, 4);
		$mois    = substr($madate, 3, 2);
		$jour        = substr($madate, 0, 2);
		$nouv_date=$annee."-".$mois."-".$jour;
		return $nouv_date;
	}
	else
	{
		return "";
	}
}

// transforme une date us (aaaa-mm-jj) en date fr (jj/mm/aaaa)
function versDateFR2($madate)
{
	if ($madate!="")
	{
		$annee    = substr($madate, 0, 4);
		$mois    = substr($madate, 5, 2);
		$jour        = substr($madate, 8, 2);
		$nouv_date=$jour."/".$mois."/".$annee;
		return $nouv_date;
	}
	else
	{
		return "";
	}
}



?>
