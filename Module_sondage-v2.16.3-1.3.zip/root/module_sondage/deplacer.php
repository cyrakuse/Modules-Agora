<?php
////	INITIALISATION
require "commun.inc.php";

////	ON DEPLACE PLUSIEURS ELEMENTS
foreach(request_elements($_POST["elements"],$objet["sondage"]) as $id_sondage)			{ deplacer_sondage($id_sondage, $_POST["id_dossier"]); }
foreach(request_elements($_POST["elements"],$objet["sondage_dossier"]) as $id_dossier)	{ deplacer_sondage_dossier($id_dossier, $_POST["id_dossier"]); }

////	DECONNEXION À LA BDD & FERMETURE DU POPUP
reload_close();
?>

