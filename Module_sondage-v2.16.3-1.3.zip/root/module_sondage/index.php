<?php
////	INITIALISATION
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
$cpt_element = 0;
init_id_dossier();
$droit_acces_dossier = droit_acces_controler($objet["sondage_dossier"],$_GET["id_dossier"],"lecture");
elements_width_height_type_affichage("medium","100px","bloc");
?>


<table id="contenu_principal_table"><tr>
	<td id="menu_gauche_block_td">
		<div id="menu_gauche_block_flottant">
		<?php
		////	MENU D'ARBORESCENCE
		echo "<div class=\"menu_gauche_block content\">";
		$cfg_menu_arbo = array("objet"=>$objet["sondage_dossier"], "id_objet"=>$_GET["id_dossier"], "ajouter_dossier"=>"oui", "droit_acces_dossier"=>$droit_acces_dossier);
		include_once PATH_INC."menu_arborescence.inc.php";
		echo "</div>";
		?>
		<div class="menu_gauche_block content">
			<table width="100%">
			<?php
			
			////	AJOUTER sondage
			if($droit_acces_dossier>=1.5)
			{
				echo "<div class='menu_gauche_ligne lien' onclick=\"edit_iframe_popup('sondage_edit.php?id_dossier=".$_GET["id_dossier"]."');\"><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/ajouter.png\" /></div><div class='menu_gauche_txt'>".$trad["SONDAGE_ajouter_sondage"]."</div></div>";
			}
			
			////	MENU ELEMENTS
			$cfg_menu_elements = array("objet"=>$objet["sondage"], "objet_dossier"=>$objet["sondage_dossier"], "id_objet_dossier"=>$_GET["id_dossier"], "droit_acces_dossier"=>$droit_acces_dossier);
			include PATH_INC."elements_menu_selection.inc.php";
			
			////	MENU D'AFFICHAGE  &  DE TRI  &  CONTENU DU DOSSIER
			//echo menu_type_affichage();
			//elements_width_height("medium","100px");
			echo menu_tri($config["tri_sondage"]);
			echo contenu_dossier($objet["sondage_dossier"],$_GET["id_dossier"]);
			?>
			</table>
		</div>
	</div>
	</td>
	<td>
		<?php
		////	MENU CHEMIN + OBJETS_DOSSIERS
		////
		@$_REQUEST["type_affichage"]="liste";
		echo menu_chemin($objet["sondage_dossier"], $_GET["id_dossier"]);
		$cfg_dossiers = array("objet"=>$objet["sondage_dossier"], "id_objet"=>$_GET["id_dossier"]);
		include_once PATH_INC."dossiers.inc.php";

		////	LISTE DES SONDAGES
		////
		$liste_sondages = db_tableau("SELECT * FROM gt_sondage WHERE id_dossier='".$_GET["id_dossier"]."' ".sql_affichage($objet["sondage"],$_GET["id_dossier"])." ".tri_sql($config["tri_sondage"])." ");
		
		foreach($liste_sondages as $sondage_tmp)
		{	

				////	INIT + LIEN POPUP
				$cpt_element++;
				$lien_vote = "onclick=\"popup('voter.php?id_sondage=".$sondage_tmp["id_sondage"]."','aff_sondage".$sondage_tmp["id_sondage"]."');\" ";
				$lien_resultat = "onclick=\"popup('resultat.php?id_sondage=".$sondage_tmp["id_sondage"]."','aff_sondage".$sondage_tmp["id_sondage"]."');\" ";
				$lien_cloturer = "onclick=\"redir('cloturer.php?id_sondage=".$sondage_tmp["id_sondage"]."&id_dossier_retour=".$_GET["id_dossier"]."');\" ";
				$src_photo  = PATH_TPL."module_sondage/menu.png";
				////	MODIF / SUPPR / INFOS / CREATION USER (admin général)
				$sondage_tmp["droit_acces"] = ($_GET["id_dossier"]>1) ? $droit_acces_dossier : droit_acces($objet["sondage"],$sondage_tmp);
				
				if(droit_ajout_sondage()==true)	{
					//$cfg_menu_elem["modif"] = "sondage_edit.php?id_sondage=".$sondage_tmp["id_sondage"];
					$cfg_menu_elem["deplacer"] = PATH_DIVERS."deplacer.php?module_dossier=".MODULE_DOSSIER."&type_objet_dossier=sondage_dossier&id_dossier_parent=".$_GET["id_dossier"]."&elements=sondage-".$sondage_tmp["id_sondage"];
					$cfg_menu_elem["suppr"] = "elements_suppr.php?id_sondage=".$sondage_tmp["id_sondage"]."&id_dossier_retour=".$_GET["id_dossier"];
				}
			

			
				
				$votes=db_ligne("select count(id_sondage) as nbre from gt_sondage_resultat where id_sondage=".$sondage_tmp["id_sondage"]." and id_utilisateur=".$_SESSION["user"]["id_utilisateur"]);
				$posteur=db_ligne("select id_utilisateur from gt_sondage where id_sondage=".$sondage_tmp["id_sondage"]);	
				$cfg_menu_elem["id_div_element"] = div_element($objet["sondage"], $sondage_tmp["id_sondage"]);
				//echo div_element($objet["sondage"], $sondage_tmp["id_sondage"]);
					echo "<div class=\"div_element_options\">";	include PATH_INC."element_menu_contextuel.inc.php"; echo "</div>";
					echo "<div class=\"div_element_contenu\" >";
						echo "<table class=\"div_element_table\"><tr>";
							////	VÉRIFIE SI LE SONDAGE EST CLOTURÉ OU NON
							if(($sondage_tmp["cloturer"])==0)
							{
								echo "<td class=\"div_element_image lien\" style=\"width:70px;text-align:center;\" ><img src=\"".$src_photo."\" style=\"max-width:80px;max-height:80px;\" /></td>";
							}
							else
							{
								echo "<td class=\"div_element_image lien\" style=\"width:80px;text-align:center;\" ><img src=\"".PATH_TPL."module_sondage/cloturer.png"."\" style=\"max-width:70px;max-height:35px;\" /></td>";
							}
							echo "<td class=\"div_elem_td\" width=\"80%\"><span class=\"lien\" >".$sondage_tmp["titre"]."</span></td>";

							echo "<td class=\"div_elem_td\" width=\"20%\">";
							////	VÉRIFIE SI LE SONDAGE EST CLOTURÉ OU NON
							if(($sondage_tmp["cloturer"])==1)
							{
								echo "<span class=\"lien\" ".$lien_resultat." >".$trad["SONDAGE_resultat"]."</span></br>";
							}
							else
							{
								////	VÉRIFICATION DE L'UTILISATEUR (VISITEUR OU UTILISATEUR)
								if(($_SESSION["user"]["id_utilisateur"]>0) && ($votes["nbre"]==0))
								{
									////	VÉRIFICATION POUR SAVOIR SI L'UTILISATEUR ET L'AUTEUR DU SONDAGE, SI OUI, LUI DONNE LE DROIT DE LE CLOTURER
									if(($posteur["id_utilisateur"]==$_SESSION["user"]["id_utilisateur"]) || ($_SESSION["user"]["admin_general"]==1))
									{
										echo "<span class=\"lien\" ".$lien_vote.">".$trad["SONDAGE_voter"]."</span></br><span class=\"lien\" ".$lien_resultat.">".$trad["SONDAGE_resultat"]."</span></br><span class=\"lien\" ".$lien_cloturer.">".$trad["SONDAGE_cloturer"]."</span></br>";
									}
									else
									{
										echo "<span class=\"lien\" ".$lien_vote.">".$trad["SONDAGE_voter"]."</span></br><span class=\"lien\" ".$lien_resultat.">".$trad["SONDAGE_resultat"]."</span></br>";
									}
								}
								else
								{
									if($posteur["id_utilisateur"]==$_SESSION["user"]["id_utilisateur"])
									{
										echo "<span class=\"lien\" ".$lien_resultat." >".$trad["SONDAGE_resultat"]."</span></br><span class=\"lien\" ".$lien_cloturer.">".$trad["SONDAGE_cloturer"]."</span>";
									}
									else
									{
										echo "<span class=\"lien\" ".$lien_resultat." >".$trad["SONDAGE_resultat"]."</span>";
									}
								}	
							}
							echo "</td>";
							// echo "<td class=\"div_element_td\" style=\"text-align:right;\">";
								
								
							//	AUTEUR / DATE
							// $auteur_tmp = user_infos($sondage_tmp["id_utilisateur"]);
							// if (preg_match("/aujourd'hui/i", temps($sondage_tmp["date_crea"]))) 
							// {
								// echo "<div style=\"margin-top:7px;margin-right:15px;\">".$trad["SONDAGE_date_creation_2"].temps($sondage_tmp["date_crea"]).", <br />".$trad["SONDAGE_par"].auteur($auteur_tmp,$sondage_tmp["invite"])."</div>";
							// }
							// else
							// {
								// echo "<div style=\"margin-top:7px;margin-right:15px;\">".$trad["SONDAGE_date_creation"].temps($sondage_tmp["date_crea"]).", <br />".$trad["SONDAGE_par"].auteur($auteur_tmp,$sondage_tmp["invite"])."</div>";
							// }
							// echo "</td>";
						echo "</tr></table>";
					echo "</div>";
				echo "</div>";
				echo "<br />";
			
		}
		////	AUCUN SONDAGE
		if(@$cpt_div_element<1)  echo "<div class='div_elem_aucun'>".$trad["SONDAGE_aucun_sondage"]."</div>";
		?>
	</td>
</tr></table>


<?php include_once PATH_INC."footer.inc.php"; ?>
