<?php
////	INITIALISATION
////
require "commun.inc.php";
require PATH_INC."header.inc.php";
if(isset($_GET["id_sondage"]))
{
	$id_sondage=$_GET["id_sondage"];
}
else
{
	$id_sondage=null;
}
$sondage_tmp = objet_infos($objet["sondage"], $id_sondage);
$droit_acces = droit_acces($objet["sondage"], $sondage_tmp, "lecture");


?>


<script type="text/javascript">resize_iframe_popup(470,450);</script>
<style type="text/css">
body		{ background-image:url(<?php echo PATH_TPL; ?>module_sondage/fond_popup.png); }
.tab_user	{ width:100%; border-spacing:3px; font-weight:normal; }
.lib_user	{ width:200px; font-weight:bold; }
</style>

<?php

if (isset($_POST["valide"]))
{
	$utilisateur=$_POST["user"];
	$votes=db_ligne("select count(*) as nbre from gt_sondage_resultat where id_utilisateur=".$utilisateur." and id_sondage=".$_POST["sondage"]);
	if ($votes["nbre"]==0)
	{
		$sondage=$_POST["sondage"];
		$reponse=$_POST["reponse"];
		db_query("insert into gt_sondage_resultat(id_utilisateur,id_champ,id_sondage) values (".$utilisateur.", ".$reponse.", ".$sondage.")");
		alert($trad["SONDAGE_vote_ok"]);
		reload_close();
	}
	else
	{
		alert($trad["SONDAGE_deja_vote"]);
		reload_close();
	}
}


?>
<table style="width:100%;height:300px;border-spacing:8px;"><tr>
	
	<td style="text-align:left;vertical-align:middle;">
		<table class="tab_user">
<?php
		////	INFOS SUR L'OFFRE
		////
		echo "<div style=\"font-size:14px;margin-bottom:10px;font-weight:bold;\">".$sondage_tmp["titre"]."</div>";
		echo "<div style=\"font-size:12px;margin-bottom:10px;\">".$sondage_tmp["description"]."</div>";
		echo "<div class=\"lib_user\">";
		echo "<form action=\"".php_self()."\" method=\"post\" enctype=\"multipart/form-data\" style=\"padding:10px\" >";
		$reponses=db_tableau("select * from gt_sondage_champs where id_sondage=".$_GET["id_sondage"]);
		foreach($reponses as $reponse)
		{
			echo "<input type='radio' name='reponse' value='".$reponse["id_champ"]."'>".$reponse["description"]."<br />";
		}
		echo "<input type='hidden' name='user' value='".$_SESSION["user"]["id_utilisateur"]."'>";
		echo "<input type='hidden' name='sondage' value='".$_GET["id_sondage"]."'>";
		echo "<input type='hidden' name='valide' value='1'>";
		echo "<br /><br /><br />";
		echo "<div style=\"position: absolute; bottom: 15px;\">";
		echo "<input type='submit' value='".$trad["SONDAGE_valider"]."'>";
		echo "</div>";
		
?>
		</table>
	</td>
</tr></table>


<?php
////	Fichiers joints + footer
affiche_fichiers_joints($objet["sondage"], $_GET["id_sondage"], "popup");
include_once PATH_INC."footer.inc.php";
?>
