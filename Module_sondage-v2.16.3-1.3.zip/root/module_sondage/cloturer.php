<?php
////	INITIALISATION
include "commun.inc.php";

////	ON CLOTURE UN SONDAGE
if(isset($_GET["id_sondage"]))	{ cloturer_sondage($_GET["id_sondage"]); }

////	REDIRECTION
redir("index.php?id_dossier=".$_GET["id_dossier_retour"]);
?>
