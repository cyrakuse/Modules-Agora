<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",false);
include "commun.inc.php";
include_once PATH_INC."header.inc.php";
$sondage_tmp = objet_infos($objet["sondage"], $_GET["id_sondage"]);
$droit_acces = droit_acces($objet["sondage"], $sondage_tmp, "lecture");


?>

<script type="text/javascript" src="http://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load('visualization', '1', {packages: ['corechart']});
    </script>
    
<script type="text/javascript">resize_iframe_popup(600,650);</script>
<style type="text/css">
.tab_user	{ width:100%; border-spacing:3px; font-weight:normal; }
.lib_user	{ width:200px; font-weight:bold; }
</style>

<br /><br />

<table style="width:100%;height:300px;border-spacing:8px;"><tr>
	
	<td style="text-align:center;vertical-align:middle;">
		<table class="tab_user">
		<?php
		$rep=db_tableau("select * from gt_sondage_champs where id_sondage=".$_GET["id_sondage"]);
		$reponses=array();
		foreach($rep as $marep)
		{
			$sql=db_ligne("select count(*) as nbre from gt_sondage_resultat where id_champ=".$marep["id_champ"]);
			$reponses[]=array("description"=>$marep["description"],"quantite"=>$sql["nbre"]);
		}
		
		
		
		echo "<div style=\"font-size:14px;margin-bottom:10px;font-weight:bold;\">".$sondage_tmp["titre"]."</div>";
		echo "<div style=\"font-size:12px;margin-bottom:10px;\">".$sondage_tmp["description"]." </div>";
		echo "<br /><br />";
		$i=0;
		foreach ($reponses as $reponse)
		{
			echo "<tr><td class=\"lib_user\" style=\"text-align:left;vertical-align:middle;\"><img src=\"".PATH_TPL."divers/fleche_droite.png\" /> ".$reponse["description"]." </td><td class=\"lib_user\">".$reponse["quantite"]." votes</td></tr>";
			$i++;
	
		}
		echo "</table>";
		?>
		<script type="text/javascript">
      function drawVisualization() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Reponse');
        data.addColumn('number', 'Votes');
        data.addRows([
		<?php
		foreach ($reponses as $reponse)
		{
			$i++;
			echo "[\"".$reponse["description"]."\", ".$reponse["quantite"]."],";
		}
			?>
		]);
        new google.visualization.PieChart(document.getElementById('visualization')).
            draw(data, {title:""});
      }
      

      google.setOnLoadCallback(drawVisualization);
    </script>
	<div id="visualization" style="width: 500px; height: 350px;"></div>
		
	
	</td>
</tr></table>

</center>
<?php
////	Fichiers joints + footer
affiche_fichiers_joints($objet["sondage"], $_GET["id_sondage"], "popup");
include_once PATH_INC."footer.inc.php";

?>
