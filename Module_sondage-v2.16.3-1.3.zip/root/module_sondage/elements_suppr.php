<?php
////	INITIALISATION
include "commun.inc.php";


////	SUPPRESSION DE DOSSIER / sondage / ELEMENTS
if(isset($_GET["id_dossier"]))		{ suppr_sondage_dossier($_GET["id_dossier"]); }
elseif(isset($_GET["id_sondage"]))	{ suppr_sondage($_GET["id_sondage"]); }
elseif(isset($_GET["elements"]))
{
	$liste_elements = explode("@@",$_GET["elements"]);
	foreach(request_elements($liste_elements,$objet["sondage"]) as $id_sondage)				{ suppr_sondage($id_sondage); }
	foreach(request_elements($liste_elements,$objet["sondage_dossier"]) as $id_dossier)		{ suppr_sondage_dossier($id_dossier); }
}
db_query("delete from gt_sondage_resultat where id_sondage=".$_GET["id_sondage"]);
db_query("delete from gt_sondage_champs where id_sondage=".$_GET["id_sondage"]);
////	Redirection
redir("index.php?id_dossier=".$_GET["id_dossier_retour"]);
?>
