<?php
////	INITIALISATION
require "commun.inc.php";
require_once PATH_INC."header.inc.php";
if(@$_REQUEST["id_sondage"]>0)	{ $sondage_tmp = objet_infos($objet["sondage"],$_REQUEST["id_sondage"]);   droit_acces($objet["sondage"],$sondage_tmp,"ecriture"); }
else							{ $sondage_tmp["id_dossier"] = $_REQUEST["id_dossier"]; }









////	VALIDATION DU FORMULAIRE
////
if(isset($_POST["id_sondage"]))
{
	////	MODIF / AJOUT
	$corps_sql = " titre=".db_format($_POST["titre"]).", description=".db_format($_POST["description"]).", raccourci=".db_format(@$_POST["raccourci"],"bool")." ";
	

	if($_POST["id_sondage"] > 0)
	{ 
		db_query("UPDATE gt_sondage SET ".$corps_sql." WHERE id_sondage=".db_format($_POST["id_sondage"])." ");
		for ($i=1;$i<=$_POST["nb_reponse"];$i++)
		{
			$temp="reponse_".$i;
			db_query("update gt_sondage_reponse set nom_champ='Réponse ".$i."', description=".db_format($_POST[$temp])." where id_sondage=".db_format($num_sondage)."");
		}
	}
	else							
	{ 
		db_query("INSERT INTO gt_sondage SET id_dossier=".db_format($_POST["id_dossier"]).", id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."', invite=".db_format(@$_POST["invite"]).", date_crea='".db_insert_date()."', ".$corps_sql." ");   $_POST["id_sondage"] = db_last_id(); 
		$num_sondage=db_last_id();
		for ($i=1;$i<=$_POST["nb_reponse"];$i++)
		{
			$temp="reponse_".$i;
			$sql="insert into gt_sondage_champs set id_sondage='".$num_sondage."', nom_champ='Reponse_".$i."', description=\"".$_POST[$temp]."\"";
			db_query($sql);
			
			
		}
	}

	////	AFFECTATION DES DROITS D'ACCÈS
	affecter_droits_acces($objet["sondage"],$_POST["id_sondage"]);

	
	

	////	ENVOI DE NOTIFICATION PAR MAIL
	if(isset($_POST["notification"])) {
		$liste_id_destinataires = users_affectes($objet["sondage"], $_POST["id_sondage"]);
		$objet_mail = $trad["SONDAGE_mail_nouveau_sondage_cree"]." ".$_SESSION["user"]["nom"]." ".$_SESSION["user"]["prenom"];
		$contenu_mail = "Titre du sondage : ".$_POST["titre"]."<br />Description du sondage : ".$_POST["description"];
		envoi_mail($liste_id_destinataires, $objet_mail, magicquotes_strip($contenu_mail));
	}

	////	FERMETURE DU POPUP
	reload_close();
}




?>


<script type="text/javascript">
////	Redimensionne
resize_iframe_popup(770,750);


function create_champ(i) {

var i2 = i + 1;

document.getElementById('leschamps_'+i).innerHTML = '<table style="width:100%;" cellpadding="3px" cellspacing="0px"><tr><td class="form_libelle" style="width:40%;">Réponse '+i2+'</td><td><input type="text" name="reponse_'+i2+'" value="" style="width:100%;" /></td></tr></table>';
document.getElementById('leschamps_'+i).innerHTML += (i <= 10) ? '<tr><td class=\"form_libelle\" style=\"width:40%;\"><span id="leschamps_'+i2+'"><a href="javascript:create_champ('+i2+')">Ajouter une reponse</a></span></td><td></td></tr>' : '';
document.getElementById('nb_reponse').value=i2;

}

</script>


<?php
////	FORMULAIRE PRINCIPAL
////
echo "<form action=\"".php_self()."\" method=\"post\" enctype=\"multipart/form-data\" style=\"padding:10px\" >";

	////	INFOS PRINCIPALES
	////
	echo "<fieldset style=\"margin-top:10px\">";
	echo "<table style=\"width:100%;\" cellpadding=\"3px\" cellspacing=\"0px\">";
	
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">".$trad["SONDAGE_titre"]."</td>";
		echo "<td><input type=\"text\" name=\"titre\" value=\"".@$sondage_tmp["titre"]."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	
	
	echo "</table>";
	echo "<table style=\"width:100%;\" cellpadding=\"3px\" cellspacing=\"0px\">";
		echo "<tr><td>&nbsp;</td></tr>";
		echo "<tr><td class=\"form_libelle\">".$trad["SONDAGE_description"]."</td></tr>";
		echo"<tr><td>";
		echo "<textarea name=\"description\" id=\"description\" style=\"width:100%;height:150px;\">".@$sondage_tmp["description"]."</textarea>";
		echo "</td></tr>";
		echo "<tr><td>&nbsp;</td></tr>";
		echo "</td></tr>";
	echo "</table>";
	
	echo "<table style=\"width:100%;\" cellpadding=\"3px\" cellspacing=\"0px\">";
	
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">Réponse 1</td>";
		echo "<td><input type=\"text\" name=\"reponse_1\" value=\"".@$sondage_tmp["reponse_1"]."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">Réponse 2</td>";
		echo "<td><input type=\"text\" name=\"reponse_2\" value=\"".@$sondage_tmp["reponse_2"]."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	echo "</table>";
	echo "<span id=\"leschamps_2\" class=\"form_libelle\"><a href=\"javascript:create_champ(2)\">Ajouter un champs</a></span>";
	//echo "<input type=\"text\" id=\"nb_reponse\" name=\"nb_reponse\" value=\"2\" />";
	echo "</fieldset>";

	
	////	DROITS D'ACCES ET OPTIONS
	////
	$cfg_menu_edit = array("objet"=>$objet["sondage"], "id_objet"=>@$sondage_tmp["id_sondage"], "fichiers_joint"=>"non","raccourci"=>"non");
	if($sondage_tmp["id_dossier"]==1)	$cfg_menu_edit["type_acces"] = "independant";
	include_once PATH_INC."element_menu_edit.inc.php";
	?>

	<div style="text-align:right;margin-top:20px;">
		<input type="hidden" name="id_sondage" value="<?php echo @$sondage_tmp["id_sondage"]; ?>" />
		<input type="hidden" name="id_dossier" value="<?php echo $sondage_tmp["id_dossier"]; ?>" />
		<input type="hidden" id="nb_reponse" name="nb_reponse" value="2" />
		
		<input type="submit" value="<?php echo $trad["SONDAGE_valider"]; ?>" />
	</div>
</form>


<?php include_once PATH_INC."footer.inc.php"; ?>