<?php
////	SONDAGES
$cfg_plugin["champs_recherche"] = array("titre","description");
$liste_sondages = db_tableau("SELECT DISTINCT * FROM gt_sondage WHERE ".sql_affichage_objets_arbo($objet["sondage"])." ".sql_selection_plugins($cfg_plugin)."  ORDER BY date_crea desc ");
foreach($liste_sondages as $sondage_tmp)
{
	$opener = ($cfg_plugin["mode"]=="recherche") ? ".opener" : "";
	$resultat_tmp = array("type"=>"elem", "module_dossier"=>$cfg_plugin["module_dossier"]);
	$resultat_tmp["lien_js_icone"] = "window".$opener.".location.replace('".ROOT_PATH.$cfg_plugin["module_dossier"]."/index.php?id_dossier=".$sondage_tmp["id_dossier"]."');";
	$resultat_tmp["lien_js_libelle"] = "popup('".ROOT_PATH.$cfg_plugin["module_dossier"]."/resultat.php?id_sondage=".$sondage_tmp["id_sondage"]."','sondage".$sondage_tmp["id_sondage"]."');";
	$resultat_tmp["libelle"] = "<span ".infobulle(chemin($objet["sondage_dossier"],$sondage_tmp["id_dossier"],"url_virtuelle")."<br />".$trad["divers"]["auteur"]." ".auteur($sondage_tmp["id_utilisateur"],$sondage_tmp["invite"])).">".$sondage_tmp["titre"]." "."</span>";
	$cfg_plugin["resultats"][] = $resultat_tmp;
}
////	DOSSIERS
$cfg_plugin["champs_recherche"] = array("nom","description");
$liste_dossiers	= db_tableau("SELECT * FROM gt_sondage_dossier WHERE 1 ".sql_affichage($objet["sondage_dossier"])." ".sql_selection_plugins($cfg_plugin)."  ORDER BY date_crea desc ");
foreach($liste_dossiers as $dossier_tmp)
{
	$resultat_tmp = array("type"=>"dossier", "module_dossier"=>$cfg_plugin["module_dossier"]);
	$resultat_tmp["lien_js_icone"] = "window.location.replace('".ROOT_PATH.$cfg_plugin["module_dossier"]."/index.php?id_dossier=".$dossier_tmp["id_dossier"]."');";
	$resultat_tmp["lien_js_libelle"] = $resultat_tmp["lien_js_icone"];
	$resultat_tmp["libelle"] = $dossier_tmp["nom"];
	$cfg_plugin["resultats"][] = $resultat_tmp;
}
?>
