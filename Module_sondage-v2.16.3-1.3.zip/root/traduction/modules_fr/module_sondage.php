<?php
////	Menu principal
$trad["SONDAGE_nom_module"] = "Sondages";
$trad["SONDAGE_nom_module_header"] = "Sondages";
$trad["SONDAGE_description_module"] = "Sondages";
$trad["SONDAGE_description_module"] = "Sondages";
$trad["SONDAGE_ajout_sondage_admin"] = "Seul l'administrateur peut ajouter des sondages";
$trad["SONDAGE_cacher_resultat"] = "On ne peut voir les résultats qu'après avoir voté";

////	Index.php
$trad["SONDAGE_ajouter_sondage"] = "Ajouter un sondage";
$trad["SONDAGE_aucun_sondage"] = "Aucun sondage pour le moment";
$trad["SONDAGE_droit_sondage"] = "Editer les droits d'accès";
$trad["SONDAGE_date_creation"] = "Créé le ";
$trad["SONDAGE_date_creation_2"] = "Créé ";
$trad["SONDAGE_par"] = " Par ";
$trad["SONDAGE_voter"] = " Voter ";
$trad["SONDAGE_resultat"] = " Résultats ";
$trad["SONDAGE_cloturer"] = " Cloturer ";

////	voter.php
$trad["SONDAGE_deja_vote"] = "Vous avez déjà voté";
$trad["SONDAGE_vote_ok"] = "Votre vote a bien été pris en compte";

////	sondage_edit.php
$trad["SONDAGE_titre"] = "Titre";
$trad["SONDAGE_description"] = "Description";
$trad["SONDAGE_mail_nouveau_sondage_cree"] = "Un nouveau sondage a été créé par";


// Tri d'affichage. Tous les éléments (dossier, tâche, lien, etc...) ont par défaut une date, un auteur & une description
//$trad["divers"]["tri"]["question"] = "question";

////    Ajouter un sondage
$trad["SONDAGE_valider"] = "Valider";



?>
