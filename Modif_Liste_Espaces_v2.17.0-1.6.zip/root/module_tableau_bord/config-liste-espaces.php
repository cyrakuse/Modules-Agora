<?php
//// Param�trage de la position de la liste des espaces

// position au dessus des autres menus
//$position="haut";

// position en dessous des autres menus
$position="bas";
?>