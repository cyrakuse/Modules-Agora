<?php
////	INITIALISATION
include "commun.inc.php";


////	SUPPRESSION DE DOSSIER / faq / ELEMENTS
if(isset($_GET["id_dossier"]))		{ suppr_faq_dossier($_GET["id_dossier"]); }
elseif(isset($_GET["id_faq"]))	{ suppr_faq($_GET["id_faq"]); }
elseif(isset($_GET["elements"]))
{
	$liste_elements = explode("@@",$_GET["elements"]);
	foreach(request_elements($liste_elements,$objet["faq"]) as $id_faq)				{ suppr_faq($id_faq); }
	foreach(request_elements($liste_elements,$objet["faq_dossier"]) as $id_dossier)		{ suppr_faq_dossier($id_dossier); }
}

////	Redirection
redir("index.php?id_dossier=".$_GET["id_dossier_retour"]);
?>
