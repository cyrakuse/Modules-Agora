<?php
////	faqS
$cfg_plugin["champs_recherche"] = array("question","description");
$liste_faqs = db_tableau("SELECT DISTINCT * FROM gt_faq WHERE ".sql_affichage_objets_arbo($objet["faq"])." ".sql_selection_plugins($cfg_plugin)."  ORDER BY date_crea desc ");
foreach($liste_faqs as $faq_tmp)
{
	$opener = ($cfg_plugin["mode"]=="recherche") ? ".opener" : "";
	$resultat_tmp = array("type"=>"elem", "module_dossier"=>$cfg_plugin["module_dossier"]);
	$resultat_tmp["lien_js_icone"] = "window".$opener.".location.replace('".ROOT_PATH.$cfg_plugin["module_dossier"]."/index.php?id_dossier=".$faq_tmp["id_dossier"]."');";
	$resultat_tmp["lien_js_libelle"] = "popup('".ROOT_PATH.$cfg_plugin["module_dossier"]."/faq.php?id_faq=".$faq_tmp["id_faq"]."','faq".$faq_tmp["id_faq"]."');";
	$resultat_tmp["libelle"] = "<span ".infobulle(chemin($objet["faq_dossier"],$faq_tmp["id_dossier"],"url_virtuelle")."<br />".$trad["divers"]["auteur"]." ".auteur($faq_tmp["id_utilisateur"],$faq_tmp["invite"])).">".$faq_tmp["question"]." "."</span>";
	$cfg_plugin["resultats"][] = $resultat_tmp;
}
////	DOSSIERS
$cfg_plugin["champs_recherche"] = array("nom","description");
$liste_dossiers	= db_tableau("SELECT * FROM gt_faq_dossier WHERE 1 ".sql_affichage($objet["faq_dossier"])." ".sql_selection_plugins($cfg_plugin)."  ORDER BY date_crea desc ");
foreach($liste_dossiers as $dossier_tmp)
{
	$resultat_tmp = array("type"=>"dossier", "module_dossier"=>$cfg_plugin["module_dossier"]);
	$resultat_tmp["lien_js_icone"] = "window.location.replace('".ROOT_PATH.$cfg_plugin["module_dossier"]."/index.php?id_dossier=".$dossier_tmp["id_dossier"]."');";
	$resultat_tmp["lien_js_libelle"] = $resultat_tmp["lien_js_icone"];
	$resultat_tmp["libelle"] = $dossier_tmp["nom"];
	$cfg_plugin["resultats"][] = $resultat_tmp;
}
?>
