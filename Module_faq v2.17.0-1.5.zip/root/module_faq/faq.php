<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",false);
include "commun.inc.php";
include_once PATH_INC."header.inc.php";
$faq_tmp = objet_infos($objet["faq"], $_GET["id_faq"]);
$droit_acces = droit_acces($objet["faq"], $faq_tmp, "lecture");


////	MODIFIER ?
if($droit_acces>=2)		echo "<span class=\"lien_select\" style=\"float:right;margin:10px;\" onClick=\"redir('faq_edit.php?id_faq=".$_GET["id_faq"]."');\">".$trad["modifier"]." <img src=\"".PATH_TPL."divers/crayon.png\" /></span>";
?>


<script type="text/javascript">resizePopup(550,400);</script>
<style type="text/css">
body		{ background-image:url(<?php echo path_templates; ?>module_faq/fond_popup.png); }
.tab_user	{ width:100%; border-spacing:3px; font-weight:bold; }
.lib_user	{ width:150px; font-weight:normal; }
</style>


<table style="width:100%;height:300px;border-spacing:8px;"><tr>
	
	<td style="text-align:left;vertical-align:middle;">
		<table class="tab_user">
<?php
		////	INFOS SUR L'UTILISATEUR
		////
		echo "<div style=\"font-size:14px;margin-bottom:10px;font-weight:bold;\">".$trad["FAQ_question"]." : ".$faq_tmp["question"]."</div>";
		echo "<br /><br />";
		echo "<div style=\"font-size:14px;margin-bottom:10px;font-weight:bold;\">".$trad["FAQ_reponse"]." : </div>";
		echo "<div style=\"padding:20px;padding-top:10px\">".$faq_tmp["description"]."</div>";
		
?>
		</table>
	</td>
</tr></table>


<?php
////	Fichiers joints + footer
affiche_fichiers_joints($objet["faq"], $_GET["id_faq"], "popup");
include_once PATH_INC."footer.inc.php";
?>
