<?php
////	INITIALISATION
////
define("is_main_page",false);
include "commun.inc.php";
include_once path_inc."header.inc.php";
//if($_SESSION["espace"]["acces"]<2)	exit;
//if(isset($_GET["id_espace"]))	{ $espace_tmp = info_espace($_GET["id_espace"]); }
//else							{ $espace_tmp = array("id_espace"=>"0", "nom"=>"", "description"=>""); }


////	VALIDATION DU FORMULAIRE
////
if(isset($_POST["id_espace"]))
{
	
	////	AFFECTATION DES UTILISATEURS
	if($_SESSION["user"]["admin_general"]==1)
	{
		// Réinitialisation
		db_query("DELETE FROM gt_jointure_espace_utilisateur WHERE id_espace='".$_POST["id_espace"]."' ");
		// Tous les utilisateurs
		if(isset($_POST["tous_box_1"]))		{ db_query("INSERT INTO gt_jointure_espace_utilisateur SET id_espace='".$_POST["id_espace"]."', tous_utilisateurs=1, droit=1, envoi_invitation=".db_insert(@$_POST["tous_box_1b"],"bool")." "); }
		
		// Chaque utilisateur
		if(isset($_POST["user"])) {
			foreach($_POST["user"] as $id_user => $droit)	{ db_query("INSERT INTO gt_jointure_espace_utilisateur SET id_espace='".$_POST["id_espace"]."', id_utilisateur='".$id_user."', droit='".$droit."', envoi_invitation=".db_insert(@$_POST["user_invit"][$id_user],"bool")." "); }
		}
	}

	reload_close();
}
?>


<style type="text/css">
table		{ width:100%; margin-bottom:5px; font-weight:bold; }
.cols1		{ width:70px; text-align:center; }
.cols2		{ width:90px; text-align:center; }
.cols3		{ width:90px; text-align:center; }
</style>


<script type="text/javascript">
////	Redimensionne
resize_iframe_popup(600,700);

////    CONTROLE DE SAISIE DU FORMULAIRE
////
function controle_formulaire()
{
	// Vérif des modules cochés
	var nb_modules = 0;
	tab_modules = document.getElementsByName("liste_modules[]");
	for(i=0; i<tab_modules.length; i++)		{  if(tab_modules[i].checked==true)  nb_modules++; }
	if(nb_modules==0)			{ alert("<?php echo $trad["espaces"]["selectionner_module"]; ?>"); return false; }
	if(get_value("nom")=="")	{ alert("<?php echo $trad["divers"]["specifier_nom"]; ?>");  return false; }
}
</script>


<form action="<?php echo php_self(); ?>" method="post" OnSubmit="return controle_formulaire();" style="padding:10px;font-weight:bold;">
	
	

	<?php
	////	AFFECTATION DES UTILISATEURS
	if($_SESSION["user"]["admin_general"]==1)
	{
		////	ACCES INVITES
		$acces_invite = db_valeur("SELECT count(*) FROM gt_jointure_espace_utilisateur WHERE id_espace='".$espace_tmp["id_espace"]."' AND invites=1 AND droit=1 ");
		////	ACCES À TOUS LES UTILISATEURS
		$acces_tous       = db_valeur("SELECT count(*) FROM gt_jointure_espace_utilisateur WHERE id_espace='".$espace_tmp["id_espace"]."' AND tous_utilisateurs=1 AND droit=1 ");
		$acces_tous_invit = db_valeur("SELECT count(*) FROM gt_jointure_espace_utilisateur WHERE id_espace='".$espace_tmp["id_espace"]."' AND tous_utilisateurs=1 AND envoi_invitation=1 ");
	?>

		<fieldset style="margin-top:40px">
			<div class="legend"><?php echo $trad["faq"]["gestion_acces"]; ?></div>
			<table>
				<tr>
					<td>&nbsp;</td>
					<td class="cols1" title="<?php echo $trad["espaces"]["utilisation_info"]; ?>" ><img src="<?php echo path_templates; ?>divers/acces_administration.png" /><br /><?php echo $trad["faq"]["ecriture"]; ?></td>
					
				</tr>
				<tr class="tr_survol">
					<td class="<?php echo ($acces_tous>0)?"menu_txt_lecture":"lien"; ?>" id="tous_txt" onClick="affect_users_espaces(this,'tous');"><i><?php echo majuscule($trad["espaces"]["tous_utilisateurs"]); ?></i> &nbsp; <img src="<?php echo path_templates; ?>divers/utilisateurs_small.png" /></td>
					<td class="cols1"><input type="checkbox" name="tous_box_1" value="1" onClick="affect_users_espaces(this,'tous');" title="<?php echo $trad["espaces"]["utilisation_info"]; ?>"  <?php if($acces_tous>0) echo "checked"; ?> /></td>
				</tr>
				
				
				<?php
				////	LISTE DES UTILISATEURS DU SITE
				$liste_users = db_tableau("SELECT * FROM gt_utilisateur ORDER BY ".$_SESSION["agora"]["tri_personnes"]);
				foreach($liste_users as $compteur => $infos_users)
				{
					$class_txt = "lien";
					$checked1 = $checked1b = $checked2 = "";
					$sql_tmp = "SELECT count(*) FROM gt_jointure_espace_utilisateur WHERE id_espace='".$espace_tmp["id_espace"]."' AND id_utilisateur='".$infos_users["id_utilisateur"]."' ";
					if(db_valeur($sql_tmp." AND droit=1")>0)				{ $checked1  = "checked";	$class_txt = "menu_txt_lecture"; }
					if(db_valeur($sql_tmp." AND envoi_invitation=1")>0)		{ $checked1b = "checked"; }
					if(db_valeur($sql_tmp." AND droit=2")>0)				{ $checked2  = "checked";	$class_txt = "menu_txt_ecriture"; }
					echo "<tr class=\"tr_survol\">";
						echo "<td class=\"".$class_txt."\" id=\"user".$compteur."_txt\" onClick=\"affect_users_espaces(this,'user".$compteur."');\" onMouseDown=\"return false;\" onselectstart=\"return false;\">".$infos_users["nom"]." ".$infos_users["prenom"]."</td>";
						echo "<td class=\"cols1\"><input  type=\"checkbox\" name=\"user[".$infos_users["id_utilisateur"]."]\"  value=\"1\" id=\"user".$compteur."_box_1\" onClick=\"affect_users_espaces(this,'user".$compteur."');\" title=\"".$trad["espaces"]["utilisation_info"]."\" ".$checked1." /></td>";
					echo "</tr>";
				}
				?>
				
			</table>
		</fieldset>
	<?php } ?>
	
	<div style="margin-top:20px;text-align:right;">
		<input type="hidden" name="id_espace" value="<?php echo $espace_tmp["id_espace"]; ?>" />
		<input type="submit" value="<?php echo $trad["divers"]["valider"]; ?>" />
	</div>

</form>


<?php include_once path_inc."footer.inc.php"; ?>
