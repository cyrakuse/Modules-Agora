<?php
////	INITIALISATION
require "commun.inc.php";

////	ON DEPLACE PLUSIEURS ELEMENTS
foreach(request_elements($_POST["elements"],$objet["faq"]) as $id_faq)			{ deplacer_faq($id_faq, $_POST["id_dossier"]); }
foreach(request_elements($_POST["elements"],$objet["faq_dossier"]) as $id_dossier)	{ deplacer_faq_dossier($id_dossier, $_POST["id_dossier"]); }

////	DECONNEXION À LA BDD & FERMETURE DU POPUP
reload_close();
?>
