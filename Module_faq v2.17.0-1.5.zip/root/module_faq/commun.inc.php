<?php
////	INITIALISATION
////
@define("MODULE_NOM","faq");
@define("MODULE_PATH","module_faq");
require_once "../includes/global.inc.php";
$config["module_espace_options"]["faq"] = array("ajout_faq_admin");
$config["tri_faq"] = modif_tri_defaut_personnes(array("question@@asc","question@@desc","date_crea@@asc","date_crea@@desc"));
$objet["faq_dossier"]	= array("type_objet"=>"faq_dossier", "cle_id_objet"=>"id_dossier", "type_contenu"=>"faq", "cle_id_contenu"=>"id_faq", "table_objet"=>"gt_faq_dossier");
$objet["faq"]			= array("type_objet"=>"faq", "cle_id_objet"=>"id_faq", "type_conteneur"=>"faq_dossier", "cle_id_conteneur"=>"id_dossier", "table_objet"=>"gt_faq");
patch_dossier_racine($objet["faq_dossier"]);


////	DROIT AJOUT ACTUALITE
////
function droit_ajout_faq()
{
	if($_SESSION["user"]["id_utilisateur"]>0  and  (option_module("ajout_faq_admin")!=true or $_SESSION["espace"]["droit_acces"]>=2))  return true;
}


////	SUPPRESSION D'UN faq
////
function suppr_faq($id_faq)
{
	global $objet;
	if(droit_acces($objet["faq"],$id_faq) >= 2){
	// On supprime l'objet en question
	suppr_objet($objet["faq"],$id_faq);
	}
}


////	SUPPRESSION D'UN DOSSIER
////
function suppr_faq_dossier($id_dossier)
{
	global $objet;
	if(droit_acces($objet["faq_dossier"],$id_dossier)==3 and $id_dossier > 1)
	{
		// on créé la liste des dossiers & on supprime chaque dossier
		$liste_dossiers_suppr = arborescence($objet["faq_dossier"],$id_dossier,"tous");
		foreach($liste_dossiers_suppr as $infos_dossier)
		{
			// On supprime chaque faq du dossier puis le dossier en question
			$liste_faqs = db_tableau("SELECT * FROM gt_faq WHERE id_dossier='".$infos_dossier["id_dossier"]."' ");
			foreach($liste_faqs as $infos_faq)	{ suppr_faq($infos_faq["id_faq"]); }
			suppr_objet($objet["faq_dossier"], $infos_dossier["id_dossier"]);
		}
	}
}


////	DEPLACEMENT D'UN faq
////
function deplacer_faq($id_faq, $id_dossier_destination)
{
	global $objet;
	////	Accès en écriture au faq et au dossier de destination
	if(droit_acces($objet["faq"],$id_faq)>=2  and  droit_acces($objet["faq_dossier"],$id_dossier_destination)>=2)
	{
	////	Si on deplace à la racine, on donne les droits d'accès de l'ancien dossier
		racine_copie_droits_acces($objet["faq"], $id_faq, $objet["faq_dossier"], $id_dossier_destination);
		////	On déplace le faq
		db_query("UPDATE gt_faq SET id_dossier=".db_format($id_dossier_destination)." WHERE id_faq=".db_format($id_faq)." ");
	}
	add_logs("modif", $objet["faq"], $id_faq);
}


////	DEPLACEMENT D'UN DOSSIER
////
function deplacer_faq_dossier($id_dossier, $id_dossier_destination)
{
	global $objet;
	////	Accès total au dossier en question  &  accès en écriture au dossier destination  &  controle du déplacement du dossier
	if(droit_acces($objet["faq_dossier"],$id_dossier)==3  and  droit_acces($objet["faq_dossier"],$id_dossier_destination)>=2  and  controle_deplacement_dossier($objet["faq_dossier"],$id_dossier,$id_dossier_destination)==1) {
		db_query("UPDATE gt_faq_dossier SET id_dossier_parent=".db_format($id_dossier_destination)." WHERE id_dossier=".db_format($id_dossier));
		}
		add_logs("modif", $objet["faq_dossier"], $id_dossier);
}
?>
