<?php
////	INITIALISATION
define("IS_MAIN_PAGE",false);
require "commun.inc.php";
require_once PATH_INC."header.inc.php";
init_editeur_tinymce();
if(@$_REQUEST["id_faq"]>0)	{ $faq_tmp = objet_infos($objet["faq"],$_REQUEST["id_faq"]);   droit_acces($objet["faq"],$faq_tmp,"ecriture"); }
else							{ $faq_tmp["id_dossier"] = $_REQUEST["id_dossier"]; }


////	VALIDATION DU FORMULAIRE
////
if(isset($_POST["id_faq"]))
{
	////	MODIF / AJOUT
	$corps_sql = " question=".db_format($_POST["question"]).", description=".db_format($_POST["description"],"editeur").", raccourci=".db_format(@$_POST["raccourci"],"bool")." ";
	if($_POST["id_faq"] > 0)	{ 
		db_query("UPDATE gt_faq SET ".$corps_sql." WHERE id_faq=".$_POST["id_faq"]." "); 
		add_logs("modif", $objet["faq"], $_POST["id_faq"]);
	}
	else							
	{ 
		db_query("INSERT INTO gt_faq SET id_dossier=".db_format($_POST["id_dossier"]).", id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."', invite=".db_format(@$_POST["invite"]).", date_crea=NOW(), ".$corps_sql." ");   $_POST["id_faq"] = db_last_id(); 
		add_logs("ajout", $objet["faq"], $_POST["id_faq"]);
	}

	////	AFFECTATION DES DROITS D'ACCÈS
	affecter_droits_acces($objet["faq"],$_POST["id_faq"]);

	////	AJOUTER FICHIERS JOINTS
	ajouter_fichiers_joint($objet["faq"],$_POST["id_faq"]);

	

	////	ENVOI DE NOTIFICATION PAR MAIL
	if(isset($_POST["notification"])) {
		$liste_id_destinataires = users_affectes($objet["faq"], $_POST["id_faq"]);
		$objet_mail = $trad["FAQ_mail_nouveau_faq_cree"]." ".$_SESSION["user"]["nom"]." ".$_SESSION["user"]["prenom"];
		$contenu_mail = $_POST["nom"]." ".$_POST["prenom"];
		envoi_mail($liste_id_destinataires, $objet_mail, magicquotes_strip($contenu_mail));
	}

	////	FERMETURE DU POPUP
	reload_close();
}

?>


<script type="text/javascript">
////	Redimensionne
resizePopup(770,750);


</script>


<?php
////	FORMULAIRE PRINCIPAL
////
echo "<form action=\"".php_self()."\" method=\"post\" enctype=\"multipart/form-data\" style=\"padding:10px\" >";

	////	INFOS PRINCIPALES
	////
	//echo "<fieldset style=\"margin-top:10px\">";
	echo "<table style=\"width:100%;\" cellpadding=\"3px\" cellspacing=\"0px\">";
		echo "<tr><td class=\"form_libelle\">".$trad["FAQ_question"]."</td></tr>";
		echo"<tr><td>";
		echo "<input type=\"text\" name=\"question\" id=\"question\" value=\"".@$faq_tmp["question"]."\" style=\"width:100%;\"/>";
		echo "</td></tr>";
		echo "<tr><td>&nbsp;</td></tr>";
		echo "<tr><td class=\"form_libelle\">".$trad["FAQ_reponse"]."</td></tr>";
		echo"<tr><td>";
		echo "<textarea name=\"description\" id=\"description\" style=\"width:100%;height:250px;\">".@$faq_tmp["description"]."</textarea>";
		echo "</td></tr>";
	echo "</table>";
	//echo "</fieldset>";

	
	////	DROITS D'ACCES ET OPTIONS
	////
	
	$cfg_menu_edit = array("objet"=>$objet["faq"], "id_objet"=>@$faq_tmp["id_faq"]);
	//if($faq_tmp["id_dossier"]==1)	$cfg_menu_edit["type_acces"] = "independant";
	include_once PATH_INC."element_menu_edit.inc.php";
	?>

	<div style="text-align:right;margin-top:20px;">
		<input type="hidden" name="id_faq" value="<?php echo @$faq_tmp["id_faq"]; ?>" />
		<input type="hidden" name="id_dossier" value="<?php echo $faq_tmp["id_dossier"]; ?>" />
		<input type="submit" value="<?php echo $trad["valider"]; ?>" />
	</div>
</form>


<?php include_once PATH_INC."footer.inc.php"; ?>