<?php
////	INITIALISATION
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
$cpt_element = 0;
init_id_dossier();
$droit_acces_dossier = droit_acces_controler($objet["faq_dossier"],$_GET["id_dossier"],1);
elements_width_height_type_affichage("medium","100px","bloc");

?>


<table id="contenu_principal_table"><tr>
	<td id="menu_gauche_block_td">
	<div id="menu_gauche_block_flottant">
		<div class="menu_gauche_block content">
			<?php
			////	MENU D'ARBORESCENCE
			$cfg_menu_arbo = array("objet"=>$objet["faq_dossier"], "id_objet"=>$_GET["id_dossier"], "ajouter_dossier"=>"oui", "droit_acces_dossier"=>$droit_acces_dossier);
			require_once PATH_INC."menu_arborescence.inc.php";
			?>
		</div>
		<div class="menu_gauche_block content">
			<table width="100%">
			<?php
			
			////	AJOUTER faq
			if($droit_acces_dossier>=1.5)
			{
				echo "<div class='menu_gauche_ligne lien' onclick=\"popupLightbox('faq_edit.php?id_dossier=".$_GET["id_dossier"]."');\"><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/ajouter.png\" /></div><div class='menu_gauche_txt'>".$trad["FAQ_ajouter_faq"]."</div></div>";
			}
			
			////	MENU ELEMENTS
			$cfg_menu_elements = array("objet"=>$objet["faq"], "objet_dossier"=>$objet["faq_dossier"], "id_objet_dossier"=>$_GET["id_dossier"], "droit_acces_dossier"=>$droit_acces_dossier);
			require PATH_INC."elements_menu_selection.inc.php";
			
			////	MENU D'AFFICHAGE  &  DE TRI  &  CONTENU DU DOSSIER
			echo menu_type_affichage();
			echo menu_tri($config["tri_faq"]);
			echo contenu_dossier($objet["faq_dossier"],$_GET["id_dossier"]);
			?>
			</table>
		</div>
	</div>
	</td>
	<td>
		<?php
		////	MENU CHEMIN + OBJETS_DOSSIERS
		////
		echo menu_chemin($objet["faq_dossier"], $_GET["id_dossier"]);
		$cfg_dossiers = array("objet"=>$objet["faq_dossier"], "id_objet"=>$_GET["id_dossier"]);
		require_once PATH_INC."dossiers.inc.php";

		////	LISTE DES faqS
		////
		$liste_faqs = db_tableau("SELECT * FROM gt_faq WHERE id_dossier='".$_GET["id_dossier"]."' ".sql_affichage($objet["faq"],$_GET["id_dossier"])." ".tri_sql($config["tri_faq"])." ");
		
		foreach($liste_faqs as $faq_tmp)
		{
			////	INIT + LIEN POPUP
			$cpt_element++;
			$lien_popup = "onclick=\"popupLightbox('faq.php?id_faq=".$faq_tmp["id_faq"]."','aff_faq".$faq_tmp["id_faq"]."');\" ";
			$src_photo  = PATH_TPL."module_faq/menu.png";
			////	MODIF / SUPPR / INFOS / CREATION USER (admin général)
			$cfg_menu_elem = array("objet"=>$objet["faq"], "objet_infos"=>$faq_tmp, "fichiers_joint"=>"oui");
			$faq_tmp["droit_acces"] = ($_GET["id_dossier"]>1) ? $droit_acces_dossier : droit_acces($objet["faq"],$faq_tmp);
			
			if($faq_tmp["droit_acces"]>=2)	{
				$cfg_menu_elem["modif"] = "faq_edit.php?id_faq=".$faq_tmp["id_faq"];
				$cfg_menu_elem["deplacer"] = PATH_DIVERS."deplacer.php?module_dossier=".MODULE_DOSSIER."&type_objet_dossier=faq_dossier&id_dossier_parent=".$_GET["id_dossier"]."&elements=faq-".$faq_tmp["id_faq"];
				$cfg_menu_elem["suppr"] = "elements_suppr.php?id_faq=".$faq_tmp["id_faq"]."&id_dossier_retour=".$_GET["id_dossier"];
			}
			
			////	AFFICHAGE BLOCK
			////
			if($_REQUEST["type_affichage"]=="bloc")
			{
				$cfg_menu_elem["id_div_element"] = div_element($objet["faq"], $faq_tmp["id_faq"]);
				//echo div_element($objet["faq"], $faq_tmp["id_faq"]);
					////	OPTIONS + DETAILS
					echo "<div class=\"div_element_options\">";  include PATH_INC."element_menu_contextuel.inc.php";  echo "</div>";
					echo "<div class=\"div_element_contenu\">";
						echo "<table class=\"div_element_table\"><tr>";
							echo "<td class=\"div_element_image lien\" ".$lien_popup." ><img src=\"".$src_photo."\" style=\"max-width:80px;max-height:80px;\" /></td>";
							echo "<td style=\"vertical-align:middle\">";
							echo "<div style=\"font-size:12px;\" class=\"lien\" ".$lien_popup.">".$faq_tmp["question"]."</div>";
							echo "</td>";
						echo "</tr></table>";
					echo "</div>";
				echo "</div>";
				
			}
			////	AFFICHAGE LISTE
			////
			else
			{
				$cfg_menu_elem["id_div_element"] = div_element($objet["faq"], $faq_tmp["id_faq"]);
					echo "<div class=\"div_element_options\">";	include PATH_INC."element_menu_contextuel.inc.php"; echo "</div>";
					echo "<div class=\"div_element_contenu\" >";
						echo "<table class=\"div_element_table\"><tr>";
							echo "<td class=\"div_element_td lien\" style=\"width:70px;text-align:center;\" ".$lien_popup." ><img src=\"".$src_photo."\" style=\"max-width:70px;max-height:35px;\" /></td>";
							echo "<td class=\"div_element_td\"><span class=\"lien\" ".$lien_popup.">".$faq_tmp["question"]."</span></td>";
							
						echo "</tr></table>";
					echo "</div>";
				echo "</div>";
				echo "<br />";
			}
		}
		////	AUCUN faq
		if(@$cpt_div_element<1)  echo "<div class='div_elem_aucun'>".$trad["ANNU_ASSO_aucun_annu_asso"]."</div>";
		?>
	</td>
</tr></table>


<?php include_once PATH_INC."footer.inc.php"; ?>
