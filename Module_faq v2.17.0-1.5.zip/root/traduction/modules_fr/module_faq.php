<?php
////	Menu principal
$trad["FAQ_nom_module"] = "Foire aux questions";
$trad["FAQ_nom_module_header"] = "FAQ";
$trad["FAQ_description_module"] = "Foire aux questions";
$trad["FAQ_ajout_faq_admin"] = "Seul l'administrateur peut ajouter des questions";

////	Index.php
$trad["FAQ_ajouter_faq"] = "Ajouter une question";
$trad["FAQ_aucun_faq"] = "Aucune question pour le moment";
$trad["FAQ_creer_user"] = "Creer un utilisateur sur cet espace";
$trad["FAQ_creer_user_infos"] = "Créer un utilisateur sur cet espace à partir de cette association ?";
$trad["FAQ_creer_user_confirm"] = "L'utilisateur a été créé";
$trad["FAQ_faq_importer"] = "Importer des associations";
$trad["FAQ_faq_exporter"] = "Exporter les associations";
$trad["FAQ_droit_faq"] = "Editer les droits d'accès";


////	faq_edit.php
$trad["FAQ_mail_nouveau_faq_cree"] = "Nouvelle question créé par ";


//// champs
$trad["FAQ_question"] = "Question";
$trad["FAQ_reponse"] = "Réponse";

$trad["FAQ_horaire"] = "Horaires de permanence";


// Tri d'affichage. Tous les éléments (dossier, tâche, lien, etc...) ont par défaut une date, un auteur & une description
$trad["tri"]["question"] = "question";

////    module_edit.php
$trad["FAQ_gestion_acces"] = "Utilisateurs pouvant ajouter et modifer des questions";
$trad["FAQ_ecriture"] = "Ecriture";
?>
