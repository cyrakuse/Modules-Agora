<?php
////	Menu principal
$trad["RECHERCHE_ASSO_nom_module"] = "Recherche d'associations";
$trad["RECHERCHE_ASSO_nom_module_header"] = "Recherche";
$trad["RECHERCHE_ASSO_description_module"] = "Recherche d'associations";
$trad["RECHERCHE_ASSO_ajout_recherche_asso_admin"] = "Seul l'administrateur peut ajouter des communes";
$trad["RECHERCHE_ASSO_voir_asso"] = "Voir l'association correspondante";

////	Index.php
$trad["RECHERCHE_ASSO_ajouter_recherche_asso"] = "Ajouter une commune";
$trad["RECHERCHE_ASSO_aucun_recherche_asso"] = "Aucune commune correspondant à la recherche";
$trad["RECHERCHE_ASSO_creer_user"] = "Creer un utilisateur sur cet espace";
$trad["RECHERCHE_ASSO_creer_user_infos"] = "Créer un utilisateur sur cet espace à partir de cette association ?";
$trad["RECHERCHE_ASSO_creer_user_confirm"] = "L'utilisateur a été créé";
$trad["RECHERCHE_ASSO_recherche_asso_importer"] = "Importer des associations";
$trad["RECHERCHE_ASSO_recherche_asso_exporter"] = "Exporter les associations";



////	annu_asso_edit.php
$trad["RECHERCHE_ASSO_mail_nouveau_recherche_asso_cree"] = "Nouvelle association créé par ";


//// champs
$trad["code_asso"] = "Code Asso";
$trad["RECHERCHE_ASSO_horaire"] = "Horaires de permanence";
$trad["RECHERCHE_ASSO_code_postal"] = "Code Postal";
$trad["RECHERCHE_ASSO_commentaire"] = "Horaires de permanence";
$trad["RECHERCHE_ASSO_horaire_public"] = "Horaires d'ouverture au public";
$trad["RECHERCHE_ASSO_horaire_administratif"] = "Horaires administratifs";


// Tri d'affichage. Tous les éléments (dossier, tâche, lien, etc...) ont par défaut une date, un auteur & une description
$trad["tri"]["code_asso"] = "code asso";

//// Autres Assos
$trad["code_siad"]="Code Siad";
$trad["code_portage"]="Code Portage";

?>
