<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",false);
require "commun.inc.php";
require_once PATH_INC."header.inc.php";
$id_recherche_asso=$_GET["id_recherche_asso"];
$liste_commune	 = db_tableau("SELECT * FROM gt_annu_asso WHERE code_asso=".$id_recherche_asso );

$recherche_asso_tmp = objet_infos($objet["recherche_asso"], $liste_commune[0]);
//$droit_acces = droit_acces($objet["recherche_asso"], $recherche_asso_tmp, "lecture");
add_logs("consult", $objet["recherche_asso"], $_GET["id_recherche_asso"]);





?>


<script type="text/javascript">resizePopup(670,550);</script>
<style type="text/css">
.tab_user	{ width:100%; border-spacing:3px; font-weight:bold; }
.lib_user	{ width:150px; font-weight:normal; }
</style>


<table style="width:100%;height:300px;border-spacing:8px;"><tr>
	<td style="max-width:200px;vertical-align:middle;">
		<img src="<?php echo ($recherche_asso_tmp["photo"]=="") ? PATH_TPL."module_recherche_asso/inconnu.png" : path_mod_recherche_asso.$recherche_asso_tmp["photo"]; ?>" alt="photo" />
	</td>
	<td style="text-align:left;vertical-align:middle;">
		<table class="tab_user">
<?php
		////	INFOS SUR L'ASSO
		////
		echo "<div style=\"font-size:14px;margin-bottom:10px;font-weight:bold;\">".$recherche_asso_tmp["code_asso"]." - ".$recherche_asso_tmp["nom"]."</div>";
		if($recherche_asso_tmp["adresse"]!="")				echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."divers/carte.png\" /> ".$trad["adresse"]." </td><td>".$recherche_asso_tmp["adresse"]."</td></tr>";
		if($recherche_asso_tmp["codepostal"]!="")			echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."divers/carte.png\" /> ".$trad["codepostal"]." </td><td>".$recherche_asso_tmp["codepostal"]."</td></tr>";
		if($recherche_asso_tmp["ville"]!="")				echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."divers/carte.png\" /> ".$trad["ville"]." </td><td>".$recherche_asso_tmp["ville"]."</td></tr>";
		if($recherche_asso_tmp["telephone"]!="")			echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."module_utilisateurs/user_telephone.png\" /> ".$trad["telephone"]." </td><td>".$recherche_asso_tmp["telephone"]."</td></tr>";
		if($recherche_asso_tmp["fax"]!="")					echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."module_utilisateurs/user_fax.png\" /> ".$trad["fax"]." </td><td>".$recherche_asso_tmp["fax"]."</td></tr>";
		if($recherche_asso_tmp["mail"]!="")				echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."module_utilisateurs/user_mail.png\" /> ".$trad["mail"]." </td><td><a href=\"mailto:".$recherche_asso_tmp["mail"]."\">".$recherche_asso_tmp["mail"]."</a></td></tr>";
		if($recherche_asso_tmp["commentaire"]!="")			echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."module_utilisateurs/user_commentaire.png\" /> ".$trad["RECHERCHE_ASSO_commentaire"]." </td><td>".$recherche_asso_tmp["commentaire"]."</td></tr>";
		if($recherche_asso_tmp["horaire_public"]!="")			echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."module_utilisateurs/user_commentaire.png\" /> ".$trad["RECHERCHE_ASSO_horaire_public"]." </td><td>".$recherche_asso_tmp["horaire_public"]."</td></tr>";
		////	CARTE MASHUP
		if($recherche_asso_tmp["adresse"]!="" OR $recherche_asso_tmp["codepostal"]!="" OR $recherche_asso_tmp["ville"]!="") {
			$addr_tmp = addslashes($recherche_asso_tmp["adresse"]."+".$recherche_asso_tmp["codepostal"]."+".$recherche_asso_tmp["ville"]);
			echo "<tr><td colspan=\"2\" style=\"cursor:pointer;\" onClick=\"window.open('http://maps.google.fr/maps?f=q&hl=fr&geocode=&time=&date=&ttype=&q=".$addr_tmp."','carte','width=800,height=600');\"><br /><img src=\"".PATH_TPL."divers/carte.png\" /> &nbsp; ".$trad["localiser_carte"]."</td></tr>";
		}
		
		echo "<tr><td colspan=\"2\" style=\"cursor:pointer;\" onClick=\"window.print()\"><br /><img src=\"".PATH_TPL."divers/imprimer.png\" /> &nbsp; ".$trad["RECHERCHE_ASSO_imprimer"]."</td></tr>";
?>
		</table>
	</td>
</tr></table>


<?php
include_once PATH_INC."footer.inc.php";
?>
