<?php
////	INITIALISATION
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
$cpt_element = 0;
init_id_dossier();

$type_recherche=0;
if (isset($_GET["rech"]))
{
	$rech=$_GET["rech"];
	if (isset($_GET["type"]))
	{
		$type_recherche=$_GET["type"];
	}
}
else
{
	$rech="";
}

if ($rech!=null)
{
	if ($type_recherche==1)
	{
		// recherche par code postal
		$liste_commune	 = db_tableau("SELECT * FROM gt_recherche_asso WHERE code_postal=".db_format($rech)." order by ville" );
	}
	else
	{
		// recherche par nom de commune
		$rech = str_replace("'", "", db_format($rech));
		$liste_commune	 = db_tableau("SELECT * FROM gt_recherche_asso WHERE ville LIKE '%".$rech."%' order by ville" );
	}
}
else
{
	// pas de recherche (juste pour �viter une erreur notice)
	$liste_commune=db_tableau("SELECT * FROM gt_recherche_asso WHERE code_postal=0 order by ville" );
}

?>


<table id="contenu_principal_table"><tr>
	<td id="menu_gauche_block_td">
	<div id="menu_gauche_block_flottant">
		<div class="menu_gauche_block content">
      <form width="100%" action="index.php" enctype="multipart/form-data" method="get" style="padding:5px;display:block;" name="resultat_code_postal">
	  <table width="100%">
        <tr><td>Recherche</td></tr>
        <tr><td><input type="text" name="rech" id="rech" value="<?php echo $rech; ?>"></td></tr>
		<tr><td><input type="radio" name="type" value="2" <?php if($type_recherche == 2 or $type_recherche == 0) { echo 'checked'; } ?>/>Nom de commune</td></tr>
        <tr><td><input type="radio" name="type" value="1" <?php if($type_recherche == 1) { echo 'checked'; } ?>/>Code postal</td></tr>
		<tr><td><input type="submit" value="Valider"></td></tr>
      </table>
		</div>
		
		
		
		
		<?php
			////	AJOUTER annu_asso
			if(droit_ajout_recherche_asso()==true)
			{
				echo "<div class=\"content menu_block\">";
					echo "<table width=\"100%\">";
						echo "<div class='menu_gauche_ligne lien' onclick=\"popupLightbox('recherche_asso_edit.php');\"><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/ajouter.png\" /></div><div class='menu_gauche_txt'>".$trad["RECHERCHE_ASSO_ajouter_recherche_asso"]."</div></div>";
					echo "</table>";
				echo "</div>";
			}
			
		
		?>
	</div>
	</td>
	<td>
		<?php
		foreach($liste_commune as $commune_tmp)
		{
				$nom_commune=$commune_tmp["ville"];
				$id_commune=$commune_tmp["id_recherche_asso"];
				$code_asso=$commune_tmp["code_asso"];
				$portage=$commune_tmp["portage_repas"];
				$siad=$commune_tmp["siad"];
				
				
				////	AFFICHAGE DES COMMUNES CORRESPONDANTES AU CODE POSTAL
				global $cpt_element, $width_element, $height_element;
				@$_REQUEST["type_affichage"]="liste";
				$style_liste = 'style_elem_liste'.'style_border_radius2';
				$cfg_menu_elem["id_div_element"] = div_element($objet["recherche_asso"], $commune_tmp["id_recherche_asso"]);
				echo "<div class=\"div_elem_options\">";
					$lien_asso = "onclick=\"popupLightbox('recherche_asso.php?id_recherche_asso=".$code_asso."');\" ";
					$lien_portage = "onclick=\"popupLightbox('recherche_asso.php?id_recherche_asso=".$portage."');\" ";
					$lien_siad = "onclick=\"popupLightbox('recherche_asso.php?id_recherche_asso=".$siad."');\" ";
					echo "</div>";
					echo "<div class=\"div_elem_contenu\">";
						echo "<table class=\"div_elem_table lien\" cellpadding=\"0px\" cellspacing=\"0px\" style='margin-left:20px;' ><tr>";
							echo "<td style=\"vertical-align:middle;\">".$nom_commune."<div style=\"font-weight:normal;margin:5px;\"></div></td>";
							echo "<td class=\"div_elem_td\" width=\"20%\">";
							if ($code_asso>0)
							{
								echo "<span class=\"lien\" ".$lien_asso.">Association Locale</span>";
								echo " <br /> ";
							}
							if ($portage>0)
							{
								echo "<span class=\"lien\" ".$lien_portage.">Portage de repas</span>";
								echo " <br /> ";
							}
							if ($siad>0)
							{
								echo "<span class=\"lien\" ".$lien_siad.">Siad</span>";
							}
							echo "</td>";
							
							echo "<td style=\"width:60px;padding-left:5px;text-align:right;\">";
							if ($_SESSION["user"]["admin_general"] ==1)
							{
							// MODIFIER
							echo "<table><tr class=\"lien\" onclick=\"popupLightbox('recherche_asso_edit.php?id_recherche_asso=".$id_commune."&modif=0');\"><td style=\"width:25px;\"><img src=\"".PATH_TPL."divers/crayon.png\" /></td></tr>";
							// SUPPRIMER
							echo "<tr class=\"lien\" onclick=\"confirmer('Confirmez-vous la suppression de la commune ".$nom_commune."?','elements_suppr.php?id_recherche_asso=".$id_commune."');\"><td style=\"width:25px;\"><img src=\"".PATH_TPL."divers/supprimer.png\" /></td></tr></table>";
							}
							echo "</td>";
						echo "</tr></table>";
					echo "</div>";
				echo"</div>";
				echo "<br>";
		}
		
		if(@$cpt_div_element<1)  echo "<div class='div_elem_aucun'>".$trad["RECHERCHE_ASSO_aucun_recherche_asso"]."</div>";
		?>
	</td>
</tr></table>


<?php include_once PATH_INC."footer.inc.php"; ?>
