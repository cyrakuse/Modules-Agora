<?php
////	INITIALISATION
@define("MODULE_NOM","recherche_asso");
@define("MODULE_PATH","module_recherche_asso");
require_once "../includes/global.inc.php";
$config["module_espace_options"]["recherche_asso"] = array("ajout_recherche_asso_admin");
$objet["recherche_asso_dossier"]	= array("type_objet"=>"recherche_asso_dossier", "cle_id_objet"=>"id_dossier", "type_contenu"=>"recherche_asso", "cle_id_contenu"=>"id_recherche_asso", "table_objet"=>"gt_recherche_asso_dossier");
$objet["recherche_asso"]			= array("type_objet"=>"recherche_asso", "cle_id_objet"=>"id_recherche_asso", "type_conteneur"=>"recherche_asso_dossier", "cle_id_conteneur"=>"id_dossier", "table_objet"=>"gt_recherche_asso");

////	DROIT AJOUT 
////
function droit_ajout_recherche_asso()
{
	if(option_module("ajout_recherche_asso_admin")!=true || $_SESSION["espace"]["droit_acces"]==2)
		return true;
}

?>
