<?php
////	INITIALISATION
include "commun.inc.php";

////	ON DEPLACE PLUSIEURS ELEMENTS
$liste_elements = explode("@@", $_POST["elements"]);
foreach(request_elements($liste_elements,$objet["annu_asso"]) as $id_annu_asso)				{ deplacer_annu_asso($id_annu_asso, $_POST["id_dossier"]); }
foreach(request_elements($liste_elements,$objet["annu_asso_dossier"]) as $id_dossier)		{ deplacer_annu_asso_dossier($id_dossier, $_POST["id_dossier"]); }

////	DECONNEXION À LA BDD & FERMETURE DU POPUP
reload_close();
?>
