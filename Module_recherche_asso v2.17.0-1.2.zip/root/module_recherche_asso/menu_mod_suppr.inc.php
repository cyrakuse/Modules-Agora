<?php 
	$id_commune = $_GET["id_wiki"];
	$nb = db_valeur("SELECT COUNT(*) FROM gt_wiki_abonnement WHERE wiki=".$id_wiki." AND utilisateur=".$_SESSION["user"]["id_utilisateur"]);
	if($nb>0)
	{
		$text = "Se d&eacute;sabonner du wiki";
	}
	else
	{
		$text = "S'abonner au wiki";
	}
?>

<span onMouseOver="afficher_info_edit('12345','<?php echo @$cfg_menu_elem["position_gauche"]; ?>');" onMouseOut="afficher('12345',false);">
	<div class="menu_flottant" style="padding:10px;width:auto;" id="12345" onMouseDown="return false;" onselectstart="return false;">
		<?php 
			// MODIFIER
			echo "<table><tr class=\"lien\" onclick=\"edit_iframe_popup('wiki_edit.php?id_wiki=".$id_wiki."&modif=0');\"><td style=\"width:25px;\"><img src=\"".path_templates."divers/crayon.png\" /></td><td>Modifier le Wiki</td></tr></table>";
			
			// SUPPRIMER
			echo "<table><tr class=\"lien\" onclick=\"confirmer('Confirmez-vous la suppression ?','suppr_wiki.php?id_wiki=".$id_wiki."');\"><td style=\"width:25px;\"><img src=\"".path_templates."divers/supprimer.png\" /></td><td>Supprimer le wiki</td></tr></table>";
	
			echo "<hr/>";

			// ABONNEMENT
			echo "<table><tr class=\"lien\" ".infobulle("Permet de recevoir un mail quand le wiki est modifi&eacute"). "onclick=\"redir('wiki_affiche.php?id_wiki=".$id_wiki."&abonn=1');\"><td style=\"width:25px;\"><img src=\"".path_templates."divers/envoi_notification.png\" /></td><td>".$text."</td></tr></table>";

		?>
	</div>
	<img src="<?php echo path_templates."divers/options_new" ?>.png" />
</span>


