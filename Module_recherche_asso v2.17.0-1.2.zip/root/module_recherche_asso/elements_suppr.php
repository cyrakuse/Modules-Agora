<?php
////	INITIALISATION
include "commun.inc.php";


////	SUPPRESSION DE DOSSIER / recherche_asso / ELEMENTS

if(isset($_GET["id_recherche_asso"]))	
{ 
	$macommune=db_ligne("select * from gt_recherche_asso where id_recherche_asso=".$_GET["id_recherche_asso"]);
	
	db_query("DELETE FROM gt_recherche_asso WHERE id_recherche_asso=".$_GET["id_recherche_asso"]);
	$commentaire="Suppression de la commune : ".$macommune["ville"];
	add_logs("suppr", $objet["recherche_asso"], $_GET["id_recherche_asso"],$commentaire);
}


////	Redirection
redir("index.php");
?>
