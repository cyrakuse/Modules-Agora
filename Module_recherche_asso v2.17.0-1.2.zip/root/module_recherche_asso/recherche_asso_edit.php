<?php
////	INITIALISATION
define("IS_MAIN_PAGE",false);
require "commun.inc.php";
require_once PATH_INC."header.inc.php";

////	VALIDATION DU FORMULAIRE
////
if (isset($_POST["id_recherche_asso"]) && isset($_POST["modifi"]))
{
	if ($_POST["modifi"]==1)
	{
		db_query("update gt_recherche_asso set code_asso=".db_format($_POST["code_asso"]).", ville=".db_format($_POST["ville"]).", code_postal=".db_format($_POST["code_postal"]).", portage_repas=".db_format($_POST["portage_repas"]).", siad=".db_format($_POST["siad"])." where id_recherche_asso=".db_format($_POST["id_recherche_asso"]));
		
		$sql="select * from gt_recherche_asso where id_recherche_asso=".$_POST["id_recherche_asso"];
		$commune_modif=db_ligne($sql);
		$commentaire="modification de la commune : ".$commune_modif["ville"];
		add_logs("modif", $objet["recherche_asso"], $_POST["id_recherche_asso"],$commentaire);
		reload_close();
	}
	elseif ($_POST["modifi"]==2)
	{
		db_query("insert into gt_recherche_asso set id_dossier=1, id_utilisateur=".$_SESSION["user"]["id_utilisateur"].", invite=".db_format(@$_POST["invite"]).", date_crea=NOW(), code_asso=".db_format($_POST["code_asso"]).", ville=".db_format($_POST["ville"]).", code_postal=".db_format($_POST["code_postal"]).", portage_repas=".db_format($_POST["portage_repas"]).", siad=".db_format($_POST["siad"])." ");
		$id=db_last_id();
		$sql="select * from gt_recherche_asso where id_recherche_asso=".$id;
		$commune_modif=db_ligne($sql);
		$commentaire="ajout de la commune : ".$commune_modif["ville"];
		add_logs("ajout", $objet["recherche_asso"], $id, $commentaire);
		reload_close();
	}
}



$commune=null;
if(isset($_GET["modif"]))
{
	$modification=$_GET["modif"];
	if ($modification==0)
	{
		$commune = db_ligne("SELECT * FROM gt_recherche_asso WHERE id_recherche_asso=".$_GET["id_recherche_asso"]);
	}
	
}


?>


<script type="text/javascript">
////	Redimensionne
resizePopup(530,600);

////    On contrôle les champs
function controle_formulaire()
{
	return true;
}
</script>


<?php

////	FORMULAIRE PRINCIPAL
////

echo "<form action=\"".php_self()."\" method=\"post\" enctype=\"multipart/form-data\" style=\"padding:10px\" OnSubmit=\"return controle_formulaire();\">";

	////	INFOS PRINCIPALES
	////
	echo "<fieldset style=\"margin-top:10px\"><table style=\"width:100%;\" cellpadding=\"3px\" cellspacing=\"0px\">";
		$style_txt = "form_libelle";
				
		echo "<tr>";
		echo "<td class=\"".$style_txt."\" style=\"width:40%;\">".$trad["ville"]."</td>";
		echo "<td><input type=\"text\" name=\"ville\" value=\"".$commune["ville"]."\" style=\"width:100%;\" /></td>";
		echo "</tr>";
		
		echo "<tr>";
		echo "<td class=\"".$style_txt."\" style=\"width:40%;\">".$trad["RECHERCHE_ASSO_code_postal"]."</td>";
		echo "<td><input type=\"text\" name=\"code_postal\" value=\"".$commune["code_postal"]."\" style=\"width:100%;\" /></td>";
		echo "</tr>";
		
		echo "<tr>";
		echo "<td class=\"".$style_txt."\" style=\"width:40%;\">".$trad["code_asso"]."</td>";
		echo "<td><input type=\"text\" name=\"code_asso\" value=\"".$commune["code_asso"]."\" style=\"width:100%;\" /></td>";
		echo "</tr>";
		
		echo "<tr>";
		echo "<td class=\"".$style_txt."\" style=\"width:40%;\">".$trad["code_portage"]."</td>";
		echo "<td><input type=\"text\" name=\"portage_repas\" value=\"".$commune["portage_repas"]."\" style=\"width:100%;\" /></td>";
		echo "</tr>";
		
		echo "<tr>";
		echo "<td class=\"".$style_txt."\" style=\"width:40%;\">".$trad["code_siad"]."</td>";
		echo "<td><input type=\"text\" name=\"siad\" value=\"".$commune["siad"]."\" style=\"width:100%;\" /></td>";
		echo "</tr>";
		
	echo "</table></fieldset>";

	if (isset($_GET["id_recherche_asso"]))
	{
	$id_ra=$_GET["id_recherche_asso"];
	}
	else
	{
	$id_ra=null;
	}
	?>

	<div style="text-align:right;margin-top:20px;">
		<input type="hidden" name="id_recherche_asso" value="<?php echo $id_ra; ?>" />
		<input type="hidden" name="id_dossier" value="1" />
	<?php
		if(isset($_GET["modif"]))
		{
			$modification=$_GET["modif"];
			if ($modification==0)
			{
				echo "<input type=\"hidden\" name=\"modifi\" value=\"1\" />";
			}
			
		}
		else
			{
				echo "<input type=\"hidden\" name=\"modifi\" value=\"2\" />";
			}
	?>
		<input type="submit" value="<?php echo $trad["valider"]; ?>" />
	</div>
</form>


<?php include_once PATH_INC."footer.inc.php"; ?>