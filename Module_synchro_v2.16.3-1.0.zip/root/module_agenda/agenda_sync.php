<?php
////	INITIALISATION
////
//require "commun.inc.php";
//$agenda = $AGENDAS_VISIBLES[$_REQUEST["id_agenda"]];
$agenda=$agenda_tmp;
$id_agenda=$agenda_tmp["id_agenda"];






////	DEBUT DU ICAL
////
$sortie  = "BEGIN:VCALENDAR\n";
$sortie .= "PRODID:-//Agora-Project//".$_SESSION["agora"]["nom"]."//EN\n";
$sortie .= "VERSION:2.0\n";
$sortie .= "CALSCALE:GREGORIAN\n";
$sortie .= "METHOD:PUBLISH\n";
////	TIMEZONE
////
$current_timezone = current_timezone();
$heure_time_zone = $tab_timezones[$current_timezone];
$sortie .= "BEGIN:VTIMEZONE\n";
$sortie .= "TZID:".$current_timezone."\n";
$sortie .= "X-LIC-LOCATION:".$current_timezone."\n";
//Daylight
$sortie .= "BEGIN:DAYLIGHT\n";
$sortie .= "TZOFFSETFROM:".heure_ical($heure_time_zone)."\n";
$sortie .= "TZOFFSETTO:".heure_ical($heure_time_zone,1)."\n";
$sortie .= "TZNAME:CEST\n";
$sortie .= "DTSTART:19700329T020000\n";
$sortie .= "RRULE:FREQ=YEARLY;INTERVAL=1;BYDAY=-1SU;BYMONTH=3\n";
$sortie .= "END:DAYLIGHT\n";
//Standard
$sortie .= "BEGIN:STANDARD\n";
$sortie .= "TZOFFSETFROM:".heure_ical($heure_time_zone,1)."\n";
$sortie .= "TZOFFSETTO:".heure_ical($heure_time_zone)."\n";
$sortie .= "TZNAME:CET\n";
$sortie .= "DTSTART:19701025T030000\n";
$sortie .= "RRULE:FREQ=YEARLY;INTERVAL=1;BYDAY=-1SU;BYMONTH=10\n";
$sortie .= "END:STANDARD\n";
$sortie .= "END:VTIMEZONE\n";


////	AJOUT DE CHAQUE EVENEMENT
////
$liste_evt = liste_evenements($id_agenda, (time()-(86400*30)), (time()+(86400*3650))); // T-30jours => T+10ans
foreach($liste_evt as $evt)
{
	////	Description
	$evt["description"] = strip_tags(str_replace("<br />"," ",$evt["description"]));
	$agendas = agendas_evts($evt["id_evenement"],"1");
	if(count($agendas)>1){
		$agendas_txt = "";
		foreach($agendas as $agenda_tmp)  { $agendas_txt .= $AGENDAS_AFFECTATIONS[$agenda_tmp["id_agenda"]]["titre"].", "; }
		$evt["description"] .= " [".substr(text_reduit($agendas_txt),0,-2)."]";
	}
	////	Affichage
	$sortie .= "BEGIN:VEVENT\n";
	$sortie .= "CREATED:".date_ical($evt["date_crea"],false)."\n";
	$sortie .= "LAST-MODIFIED:".date_ical($evt["date_crea"],false)."\n";
	$sortie .= "DTSTAMP:".date_ical(db_insert_date(),false)."\n";
	$sortie .= "UID:".ical_uid_evt($evt)."\n";
	$sortie .= "SUMMARY:".$evt["titre"]."\n";
	$sortie .= "DTSTART;TZID=".date_ical($evt["date_debut"])."\n";  //exple : "19970714T170000Z" pour 14 juillet 1997 � 17h00
	$sortie .= "DTEND;TZID=".date_ical($evt["date_fin"])."\n";
	if($evt["id_categorie"]>0)	$sortie .= "CATEGORIES:".db_valeur("SELECT titre FROM gt_agenda_categorie WHERE id_categorie='".$evt["id_categorie"]."'")."\n";
	if($evt["description"]!="")	$sortie .= "DESCRIPTION:".preg_replace("/\r\n/"," ",html_entity_decode(strip_tags($evt["description"])))."\n";
	// P�riodicit�
	$period_date_fin = ($evt["period_date_fin"])  ?  ";UNTIL=".date_ical($evt["period_date_fin"],false).""  :  "";
	if($evt["periodicite_type"]=="annee")				$sortie .= "RRULE:FREQ=YEARLY;INTERVAL=1".$period_date_fin."\n";
	elseif($evt["periodicite_type"]=="mois")			$sortie .= "RRULE:FREQ=MONTHLY;INTERVAL=1;BYMONTHDAY=".trim(strftime("%e",strtotime($evt["date_debut"]))).$period_date_fin."\n";
	elseif($evt["periodicite_type"]=="jour_mois")		$sortie .= "RRULE:FREQ=MONTHLY;INTERVAL=1;BYMONTHDAY=".implode(",",array_map("abs",explode(",",$evt["periodicite_valeurs"]))).$period_date_fin."\n";
	elseif($evt["periodicite_type"]=="jour_semaine")	$sortie .= "RRULE:FREQ=WEEKLY;INTERVAL=1;BYDAY=".implode(",",array_map("jour_ical",explode(",",$evt["periodicite_valeurs"]))).$period_date_fin."\n";
	$sortie .= "END:VEVENT\n";
}


////	FIN DU ICAL
$sortie .= "END:VCALENDAR\n";


////	ENVOI PAR MAIL / TELECHARGEMENT
////
$nom_fichier = str_replace(" ","_",$agenda["titre"]).".ics";
// cr�� un fichier temporaire
$fichier_tmp = "../webcal/".$nom_fichier;
if(file_exists($fichier_tmp)) {
unlink($fichier_tmp);
}

$fp = fopen($fichier_tmp, "w");
fwrite($fp, $sortie);
fclose($fp);
	//$_FILES[] = array("error"=>0, "type"=>"text/Calendar", "name"=>$nom_fichier, "tmp_name"=>$fichier_tmp);
	// Envoi le fichier par mail + redirection
	//envoi_mail($_SESSION["user"]["mail"], $nom_fichier, $nom_fichier, array("envoi_fichiers"=>true));
//redir("index.php");
//reload_close();

?>