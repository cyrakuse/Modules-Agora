<?php
////	INIT
require_once "../includes/global.inc.php";

////	LISTE DES MESSAGES
////
//// TEST SI LE MODULE EST ACTIF SUR L'ESPACE
$module_messagerie = db_valeur("SELECT count(*) FROM gt_jointure_espace_module WHERE id_espace = ".$_SESSION["espace"]["id_espace"]." and nom_module = 'messagerie'");
if ($module_messagerie)
{
$messages_non_lu = db_tableau ("SELECT * FROM gt_jointure_messagerie_utilisateur WHERE id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."' and supprime_reception=0 and lu=0");						
$nb_messages_non_lu = count($messages_non_lu);
echo $nb_messages_non_lu;
}
?>
