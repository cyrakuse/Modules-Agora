<?php
////	SUPPRIME UN FICHIER JOINT D'UN OBJET
require_once "../includes/global.inc.php";
require_once "commun.inc.php";
$fichier_joint = db_ligne("SELECT * FROM gt_jointure_objet_fichier WHERE id_fichier='".$_GET["id_fichier"]."'");
suppr_fichier_joint($_GET["id_fichier"], $fichier_joint["nom_fichier"]);
echo "oui";
?>
