<?php
//// Initialisation
////
require_once "../includes/global.inc.php";

//// Accès invité masquer affichage messagerie
if (!$_SESSION["user"]["id_utilisateur"])
{}
else 
{
//// Test si le module est actif sur l'espace
$module_messagerie = db_valeur("SELECT count(*) FROM gt_jointure_espace_module WHERE id_espace = ".$_SESSION["espace"]["id_espace"]." and nom_module = 'messagerie'");
if ($module_messagerie)
{
$nb_non_lu=0;
$nb_rappel=0;

//// SQL lu et rappel
////
	
$sqlnonlu1="SELECT * from  gt_jointure_messagerie_utilisateur where";
$sqlnonlu2= " id_utilisateur=".$_SESSION["user"]["id_utilisateur"];
$sqlnonlu3= " and supprime_reception=0 ";
$sqlnonlu4= $sqlnonlu1.$sqlnonlu2.$sqlnonlu3."and lu=0 ";
$sqlrappel= $sqlnonlu4."and rappel=1 ";

//// Nombre Message non lu
$messages_non_lu = db_tableau($sqlnonlu4);
$nb_non_lu = count($messages_non_lu);

////  Nombre rappel et expediteur du rappel
$messages_avec_rappel = db_tableau($sqlrappel);
$nb_rappel= count($messages_avec_rappel);

//// Affichage rappel(s) et message(s)
////
echo "<div class=\"menu_gauche_block content \">";
	if ($nb_rappel)
		{ 
		echo "<div class=\"menu_gauche_block\">";
			echo "<p style='color:red;'>";
			echo "<img src='../templates/module_messagerie/rappel.png'>".$nb_rappel."".$trad["MESSAGERIE_utilisateur(s)"]."";
			foreach ($messages_avec_rappel as $message_avec_rappel_tmp)
				{
				$expediteur_rappel = db_ligne("SELECT * FROM gt_utilisateur WHERE id_utilisateur='".$message_avec_rappel_tmp["id_expediteur"]."' ");
				echo '<p style="text-align:center;"><a href="../module_messagerie/message_reception?lu=ok&id_message='.$message_avec_rappel_tmp['id_message'].'"><b> '.$expediteur_rappel['prenom'].' '.$expediteur_rappel['nom'].'</b></a></p>';
				}
			if ($nb_rappel ==1)
				{echo "<p style='text-align:center;color:red;'>".$trad["MESSAGERIE_vous_rappelle"]."</p>";} 
			else 
				{echo "<p style='text-align:center;color:red;'>".$trad["MESSAGERIE_vous_rappellent"]."</p>";}
			echo "</p>";
		echo "</div>";
		}
			if ($nb_non_lu == 0) 
			{
			echo "<img style='margin-right:5px;' src='../templates/module_messagerie/pas_message.png'>";
			echo "<a href='../module_messagerie/index.php?cible=reception&tri=".$trad["MESSAGERIE_date"]."'>".$trad["MESSAGERIE_aucun_message"]."</a>";
			}
			else
			{
			echo "<img style='width:30px;margin-right:5px;' src='../templates/module_messagerie/non_lu.png'>";
			echo "<a href='../module_messagerie/index.php?cible=reception&tri=".$trad["MESSAGERIE_date"]."'>".$trad["MESSAGERIE_vous_avez"].""."$nb_non_lu"."".$trad["MESSAGERIE_message(s)"]."</a>"; 
			}
			echo "</div>";
		}
}
?>
