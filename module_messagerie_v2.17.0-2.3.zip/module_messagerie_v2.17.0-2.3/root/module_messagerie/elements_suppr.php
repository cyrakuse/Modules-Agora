<?php
////	INIT
require "commun.inc.php";

////	SUPPRESSION DE DOSSIER / ELEMENTS
if(isset($_GET["id_dossier"]))		{ suppr_messagerie_dossier($_GET["id_dossier"]); }
elseif(isset($_GET["id_message"]))		{ suppr_messagerie_message($_GET["id_message"]); }
elseif(isset($_GET["SelectedElems"]))
{
	foreach(SelectedElemsArray("messagerie") as $id_message)	
	{suppr_messagerie_message($id_message);}
	foreach(SelectedElemsArray("messagerie_dossier") as $id_dossier)	
	{suppr_messagerie_dossier($id_dossier);}
}

////	Redirection
redir("index.php?cible=archives&id_dossier=".$_GET["id_dossier_retour"]);
?>
