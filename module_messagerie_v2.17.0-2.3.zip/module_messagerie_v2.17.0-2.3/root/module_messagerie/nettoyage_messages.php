<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
require_once PATH_INC."header.inc.php";

if ($_SESSION['user']['admin_general'] == 1)
{
?>

<script type="text/javascript">
var answer = confirm ("<?php echo $trad["MESSAGERIE_confirmer_nettoyage"]; ?>");
if (answer)
{
<?php
	// Selection des messages supprimes
	$messages_supprimes = db_tableau ("SELECT * FROM gt_messagerie WHERE supprime_envoi=2");
	foreach ($messages_supprimes as $message_a_supprimer )
	{
		// Selection et comptage des messages � supprimer et supression
		$nb_messages = db_valeur ("SELECT COUNT(*) from gt_jointure_messagerie_utilisateur WHERE id_message = '".$message_a_supprimer["id_message"]."'");
		$nb_messages_supprime_reception = db_valeur ("SELECT COUNT(*) from gt_jointure_messagerie_utilisateur WHERE id_message = '".$message_a_supprimer["id_message"]."' AND supprime_reception = 2 ");
				
		if ($nb_messages == $nb_messages_supprime_reception)
		{
			mysql_query ("DELETE from gt_jointure_messagerie_utilisateur WHERE id_message = '".$message_a_supprimer["id_message"]."'");
			mysql_query ("DELETE from gt_messagerie WHERE id_message = '".$message_a_supprimer["id_message"]."'");
			mysql_query ("DELETE from  gt_transfert_id_fichier_messagerie WHERE id_message = '".$message_a_supprimer["id_message"]."'");
			
			$test_fichier = db_tableau ("SELECT * from gt_jointure_objet_fichier WHERE id_objet = '".$message_a_supprimer["id_message"]."' AND type_objet = 'messagerie'");
			foreach ($test_fichier as $test_fichier_tmp)
			{
				$test_transfert = db_valeur ("SELECT COUNT(*) FROM gt_transfert_id_fichier_messagerie WHERE id_fichier_origine = '".$test_fichier_tmp["id_fichier"]."'");
				if ($test_transfert == 0)
				{			
					mysql_query ("DELETE from gt_jointure_objet_fichier WHERE id_objet = '".$message_a_supprimer["id_message"]."' AND type_objet = 'messagerie' ");
					$chemin_fichier = PATH_OBJECT_FILE.$test_fichier_tmp["id_fichier"].extension($test_fichier_tmp["nom_fichier"]);
					rm($chemin_fichier);
				}
			}
		}
		else
		{
			mysql_query ("DELETE from gt_jointure_messagerie_utilisateur WHERE id_message = '".$message_a_supprimer["id_message"]."' and supprime_reception=2 ");
		}
	}
	
	/// Test des fichiers orphelins et suppression
	$fichiers = db_tableau ("SELECT * FROM gt_jointure_objet_fichier");
	foreach ($fichiers as $fichier_tmp)
	{
		$message_fichier = db_valeur ("SELECT COUNT(*) FROM gt_messagerie WHERE id_message = '".$fichier_tmp["id_objet"]."'");
		$transfert_fichier = db_valeur ("SELECT COUNT(*) FROM gt_transfert_id_fichier_messagerie WHERE id_fichier_origine = '".$fichier_tmp["id_fichier"]."'");
		if (($message_fichier == 0) && ($transfert_fichier == 0))
		{
			mysql_query ("DELETE from gt_jointure_objet_fichier WHERE id_fichier = '".$fichier_tmp["id_fichier"]."' AND type_objet = 'messagerie' ");
			$chemin_fichier_tmp = PATH_OBJECT_FILE.$fichier_tmp["id_fichier"].extension($fichier_tmp["nom_fichier"]);
			rm($chemin_fichier_tmp);
		}
	}			
?>
 	alert ("<?php echo $trad["MESSAGERIE_fin_nettoyage"]; ?>");
	window.location.replace('index.php');
}
else
{window.location.replace('index.php');}
</script>
<?php
}
else
{redir('index.php');}
?>
