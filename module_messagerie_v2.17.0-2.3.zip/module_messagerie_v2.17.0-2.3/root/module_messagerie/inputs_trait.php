<?php
////	INITIALISATION
////
require_once "../includes/global.inc.php";

$tri = "date desc";
$tri1 = $trad["MESSAGERIE_date"];
$tri2 = $trad["MESSAGERIE_expediteur"];
$tri3 = $trad["MESSAGERIE_objet_tri"];
$tri4 = $trad["MESSAGERIE_premier_destinataire"];

if (isset($_GET["tri"]))
{
////	Tri des messages
////
	if (($_GET["tri"] == $trad["MESSAGERIE_expediteur"]))
	{
	$tri = "expediteur ASC";
	$tri1 = $trad["MESSAGERIE_expediteur"];
	$tri2 = $trad["MESSAGERIE_objet_tri"];
	$tri3 = $trad["MESSAGERIE_date"];
	}

	if ($_GET["tri"] == $trad["MESSAGERIE_objet_tri"])
	{
	$tri = "titre ASC";
	$tri1 = $trad["MESSAGERIE_objet_tri"];
	$tri2 = $trad["MESSAGERIE_date"];
	$tri3 = $trad["MESSAGERIE_expediteur"];
	}

if ($_GET["tri"] == $trad["MESSAGERIE_premier_destinataire"])
	{
	$tri = "premier_destinataire ASC";
	$tri1 = $trad["MESSAGERIE_premier_destinataire"];
	$tri4 = $trad["MESSAGERIE_objet_tri"];
	$tri3 = $trad["MESSAGERIE_date"];
	}

}

if (isset($_GET["action"]))
{
	////	Bouton Archiver
	////
	if ($_GET["action"]=="".$trad["MESSAGERIE_archiver"]."")
	{$cible = 3;}

	////	Bouton Supprimer
	////
	if ($_GET["action"] == "".$trad["MESSAGERIE_supprimer"]."")
	{	
		if ($_GET["cible"] != "corbeille")
		{$cible = 1;}
		else 
		{$cible = 2;}			
	}	

	////	Bouton Restaurer
	////
	if ($_GET["action"] == "".$trad["MESSAGERIE_restaurer"]."") 
	{$cible = 0;}

	////	Update SQL
	////
	if (isset($_GET["checkbox_message"]))
	{
	foreach($_GET["checkbox_message"] as $checkbox_message)
		{
			$testenvoi = db_valeur("SELECT * FROM gt_messagerie where id_message='".$checkbox_message."' and id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");
			if ($testenvoi)
			{
			  if ($cible != 3)
			  {
			  db_query("UPDATE gt_messagerie set supprime_envoi='".$cible."', id_dossier= '1' where id_message='".$checkbox_message."' and id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");
			  }
			  else
			  {
			  db_query("UPDATE gt_messagerie set supprime_envoi='".$cible."' where id_message='".$checkbox_message."' and id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");
			  }
			}
			else
			{
				if ($cible != 3)
				{
			  	db_query("UPDATE gt_jointure_messagerie_utilisateur set id_dossier= '1', supprime_reception='".$cible."' where id_message='".$checkbox_message."' and id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."'");
				}
				else
				{
				db_query("UPDATE gt_jointure_messagerie_utilisateur set supprime_reception='".$cible."' where id_message='".$checkbox_message."' and id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."'");
				}
			}
		}
	}

If (($_GET["cible"]) == "archives")
{
	redir('index.php?cible=archives&id_dossier='.$_GET["id_dossier"].'&tri='.$_GET["tri"].'');
}
else
{
	redir('index.php?cible='.$_GET["cible"].'&tri='.$_GET["tri"].'');
}

}
?>