<?php
////	SUPPRIME UN FICHIER JOINT D'UN OBJET
////
require_once "../includes/global.inc.php";
require_once "commun.inc.php";
$fichier = db_ligne("SELECT * FROM gt_jointure_objet_fichier WHERE id_fichier='".$_GET["id_fichier"]."'");

////		LANCEMENT DU TELECHARGEMENT
$chemin_fichier = PATH_OBJECT_FILE.$_GET["id_fichier"].extension($fichier["nom_fichier"]);
telecharger($fichier["nom_fichier"], $chemin_fichier);
?>
