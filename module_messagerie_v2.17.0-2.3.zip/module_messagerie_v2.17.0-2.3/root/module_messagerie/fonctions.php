<?php
////	INITIALISATION
////
require_once "../includes/global.inc.php";
$nb_fichiers_max=10;
?>

<script type="text/javascript">
				
//// Message_edit.php & transfert_edit.php & brouillon_edit.php

	//// Coche decoche checkbox destinataires
		function select_checkbox_destinataires()
		{
		checkbox_affichage_destinataire = document.getElementsByName("affichage_destinataire[]");
		 
		if(checkbox_affichage_destinataire[0].checked == false)
		{checkbox_affichage_destinataire[0].checked = true;}
		else
		{checkbox_affichage_destinataire[0].checked = false;}
		}
		
		//// Coche decoche checkbox fichier
		function select_checkbox_fichier(id)
		{
		checkbox_joindre_fichier = document.getElementById(id);
		 
		if(checkbox_joindre_fichier.checked == false)
		{checkbox_joindre_fichier.checked = true;}
		else
		{checkbox_joindre_fichier.checked = false;}
		}

	////	SUPPRESSION D'UN FICHIER JOINT
	////
	function suppr_fichier_joint(id_fichier)
	{
	if(confirm("<?php echo $trad["MESSAGERIE_confirmer_suppr"]; ?>")==true) {
		requete_ajax("GET", "fichier_joint_suppr.php?id_fichier="+id_fichier);
		if(trouver("oui",Http_Request_Result))	afficher("fichier_joint"+id_fichier,false);
	}
	}

			
	////	SELECTIONNER / DESELECTIONNER TOUS LES UTILISATEURS OU CONTACT
	function select_ensemble_users(id_espace_dossier)
	{	
	for(var i=0; i < users_ensembles[id_espace_dossier].length; i++)
	{
		id_tmp = users_ensembles[id_espace_dossier][i];
		if(element("box_"+id_tmp).checked==false)	{ element("box_"+id_tmp).checked = true;	element("txt_"+id_tmp).className = "lien_select"; }
		else										{ element("box_"+id_tmp).checked = false;	element("txt_"+id_tmp).className = "lien"; }
	}
	}

	////    On contr�le les champs pour l'envoi
	function controle_formulaire_envoi()
	{
	// Il doit y avoir un titre
	if (get_value("titre").length==0 || get_value("titre")=="<?php echo $trad["MESSAGERIE_titre"]; ?>")	{ alert("<?php echo $trad["MESSAGERIE_specifier_titre"]; ?>"); return false; }
	// Au moins un mails s�lectionn�!
	var nb_mails_coches = 0;
	inputs_mail = document.getElementsByName("id_destinataires[]");
	for(i=0; i<inputs_mail.length; i++){
		if(inputs_mail[i].checked==true)  nb_mails_coches++;
	}
	if (nb_mails_coches==0)	{ alert("<?php echo $trad["MESSAGERIE_specifier_mail"]; ?>");  return false; }
	else
	{
	var message1 = "<?php echo $trad["MESSAGERIE_controle_form_envoi1"]; ?>";
	var message2 = "<?php echo $trad["MESSAGERIE_controle_form_envoi2"]; ?>";
	var answer = confirm (message1+nb_mails_coches+message2);
	if (!answer) {return false;}
	}	
	}

	////    On contr�le les champs pour le brouillon
	function controle_formulaire_brouillon()
	{
	// Il doit y avoir un titre
	if (get_value("titre").length==0 || get_value("titre")=="<?php echo $trad["MESSAGERIE_titre"]; ?>")	{ alert("<?php echo $trad["MESSAGERIE_specifier_titre"]; ?>"); return false; }
	}

	////	AFFICHAGE DES INPUTS FICHIER
	////
	function affiche_fichiers(id_fichier)
	{
	// Affiche un nouvel input
	for(var i=1; i<=<?php echo $nb_fichiers_max; ?>; i++)
	{
		if(get_value("add_fichier_joint"+i)!="")		afficher("div_fichier_joint"+(i+1), true, "block");
	}
	// Fichier multim�dia ?  =>  affiche et pr�coche l'option "ajouter dans la description"  (voir controle_fichier() de type "fichier_joint")
	ext = extension(get_value("add_fichier_joint"+id_fichier));
	if("<?php echo @$cfg_inc["nom_textarea"]; ?>"!=""  &&  (ext=="jpg" || ext=="jpeg" || ext=="jpe" || ext=="png" || ext=="gif" || ext=="bmp" || ext=="wbmp" || ext=="mp4" || ext=="mpeg" || ext=="mpg" || ext=="avi" || ext=="flv" || ext=="ogv" || ext=="webm" || ext=="wmv" || ext=="mov" || ext=="mp3" || ext=="swf")){    
		check_txt_box("txt_add_fichier_joint"+id_fichier, "add_fichier_joint"+id_fichier);
		afficher("txt_add_fichier_joint"+id_fichier, true);
	}
	}

	////	AFFICHAGE OU MASQUAGE D'UN DIV AVEC FADING
	////
	function afficher_dynamic(id_elem, type_affichage, afficher)
	{
		if(afficher==undefined) {
		if(element(id_elem).style.display=="none")	{ afficher = true; }
		else										{ afficher = false; }
		}
		if(type_affichage==null || type_affichage=="show"){
		if(afficher==true)	{ $("#"+id_elem).slideDown(); }
		else				{ $("#"+id_elem).slideUp(); }
		}
		else if(type_affichage=="fade"){
		if(afficher==true)	{ $("#"+id_elem).fadeIn(200);  }
		else				{ $("#"+id_elem).fadeOut(200); }
		}
	}


//// Message_envoi.php
////

	////    On contr�le les champs des rappels
	function controle_formulaire_rappels()
	{
	// Au moins un destinataire s�lectionn� !
	var nb_rappel_coches = 0;
	inputs_rappel = document.getElementsByName("checkbox_rappel[]");
	for(i=0; i<inputs_rappel.length; i++){
		if(inputs_rappel[i].checked==true)  nb_rappel_coches++;
	}
	if(nb_rappel_coches==0)	{ alert("Cocher un utilisateur !");  return false; }
	}
	
	//// Coche decoche checkbox rappels
	function select_rappels()
	{
	checkbox_rappel = document.getElementsByName("checkbox_rappel[]");
	for(i=0; i<checkbox_rappel.length; i++)
	{ 
		if(checkbox_rappel[i].checked == false)
		{checkbox_rappel[i].checked = true;}
		else
		{checkbox_rappel[i].checked = false;}
	}
	}
	
//// Message_reception.php
////

	////    On contr�le les champs
function controle_formulaire_reception()
{
	// Il doit y avoir un titre
	if (get_value("titre").length==0 || get_value("titre")=="<?php echo $trad["MESSAGERIE_titre"]; ?>")	{ alert("<?php echo $trad["MESSAGERIE_specifier_titre"]; ?>"); return false; }
}


////	SELECTION USER GROUPE
////
function check_user_groupe(id_tmp)
{

  // S�lectionne / d�s�lectionne utilisateur groupe
    var nb_txt_user = document.getElementsByName('txt_user_'+id_tmp);
    var checkbox = document.getElementById('box_'+id_tmp).checked;
   
   if (checkbox == true) 
    {
      document.getElementById('box_'+id_tmp).checked = false;
      element('txt_'+id_tmp).className = "lien";
      for(i=0; i<nb_txt_user.length; i++)
      {
	document.getElementsByName('txt_user_'+id_tmp)[i].style.color = "black";
      }
    }
    else 
    {
      document.getElementById('box_'+id_tmp).checked = true;
      element('txt_'+id_tmp).className = "txt_acces_admin";
      for(i=0; i<nb_txt_user.length; i++)
      {
	document.getElementsByName('txt_user_'+id_tmp)[i].style.color = "red";
      }
    }   
}

// REDIR LIGHTBOX
function redir_popupLightbox(url)
{
window.parent.location.replace(url);
}

function close_popupLightbox()
{
parent.$.fancybox.close();
}	
</script>
