<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",false);
require "commun.inc.php";
require_once PATH_INC."header.inc.php";

//// Fonctions javascript
////
require "fonctions.php";


if(isset($_GET["id_message"]))
{
	$messagerie_tmp = objet_infos($objet["messagerie"], $_GET["id_message"]);
}

////    Envoi du Rappel
////
if(isset($_POST["rappel"]))
{
   foreach($_POST["checkbox_rappel"] as $checkbox_rappel)
	{
	db_query("UPDATE gt_jointure_messagerie_utilisateur set rappel=1, daterappel=NOW() where id_message=".$_GET["id_message"]." and id_utilisateur=".$checkbox_rappel."");
	}
}

////	AFFICHE FICHIERS JOINTS ($affichage = popup  /  menu_element  /  normal)
////
function aff_fichiers_joints($obj_tmp, $id_objet, $affichage)
{
	global $trad;	
	$liste_fichiers_transfert = db_tableau("SELECT * FROM gt_transfert_id_fichier_messagerie WHERE id_message='".$_GET["id_message"]."' ");	
	$liste_fichiers_joint = db_tableau("SELECT * FROM gt_jointure_objet_fichier WHERE type_objet='".$obj_tmp["type_objet"]."' AND id_objet='".$id_objet."' ");
	
	if((count($liste_fichiers_transfert)>0) || (count($liste_fichiers_joint)>0))
	{
	$retour_ligne = ($affichage=="menu_element")  ?  "<br />"  :  "";
	if($affichage=="popup")		{ echo "<br /><div style=\"width:97%;text-align:center;".$_SESSION["skin"]["fond_opaque"]."\"><hr />"; }
		else						{ echo "<hr style=\"margin-top:15px\" />"; }
			
	//// Fichiers transférés
	if(count($liste_fichiers_transfert)>0)
	{
		foreach($liste_fichiers_transfert as $fichier_joint_tmp)	
		{ echo "<span onclick=\"redir('fichier_joint_telecharger.php?id_fichier=".$fichier_joint_tmp["id_fichier_origine"]."');\" class=\"lien\" ".infobulle($trad["MESSAGERIE_telecharger"])."><img src=\"".PATH_TPL."divers/telecharger.png\" /> ".$fichier_joint_tmp["nom_fichier"]."</span> &nbsp;".$retour_ligne; }
	}

	//// Fichiers joints
	if(count($liste_fichiers_joint)>0)
	{
		foreach($liste_fichiers_joint as $fichier_joint_tmp)	{ echo "<span onclick=\"redir('fichier_joint_telecharger.php?id_fichier=".$fichier_joint_tmp["id_fichier"]."');\" class=\"lien\" ".infobulle($trad["MESSAGERIE_telecharger"])."><img src=\"".PATH_TPL."divers/telecharger.png\" /> ".$fichier_joint_tmp["nom_fichier"]."</span> &nbsp;".$retour_ligne; }
	}
	
	if($affichage=="popup")		echo "</div>";
	}
}
?>

<style type="text/css">
body		{ background-image:url(<?php echo PATH_TPL; ?>module_messagerie/fond_popup.png);width:900px;margin:auto;}
.tab_user	{ width:100%; border-spacing:3px; font-weight:bold; }
.lib_user	{ width:150px; font-weight:normal;}
</style>

<fieldset class="fieldset_titre" style='width:98%'><?php echo $trad["MESSAGERIE_titre_message_envoi"]; ?></fieldset>
<div style="margin:auto;width:900px;">
<table style="width:100%;" cellpadding="3px" cellspacing="0px" >
<table style="width:100%;height:100px;border-spacing:8px;"><tr>
	
	<td style="text-align:left;vertical-align:middle;">
		<table class="tab_user">
<?php
		////	MESSAGE
		////
		echo "<div style=\"font-size:18px;margin-bottom:10px;\"><u><b>".$trad["MESSAGERIE_objet"]."</b></u> : ".$messagerie_tmp["titre"]."</div>";
		$expediteur=db_ligne("SELECT * FROM gt_utilisateur WHERE id_utilisateur=".$messagerie_tmp["id_expediteur"]."");
		echo "<div style=\"font-size:12px;margin-bottom:10px;\"><u><b>".$trad["MESSAGERIE_de"]."</b></u> : ".$expediteur["prenom"]." ".$expediteur["nom"]."</div>";
		echo "<div style=\"font-size:12px;margin-bottom:10px;\"><u><b>".$trad["MESSAGERIE_date_envoi"]."</b></u> : ".versDateHeureFR($messagerie_tmp["date"])."</div>";
	
	////  Destinataires
  $destinataires = db_tableau ("SELECT * FROM gt_jointure_messagerie_utilisateur where id_message = '".$_GET["id_message"]."' and id_expediteur='".$_SESSION["user"]["id_utilisateur"]."' ORDER BY utilisateur ASC");
		
  ////  Tests pour affichage input ou texte rappel  
  $nbrappelnul = db_valeur ("SELECT count(*) FROM gt_jointure_messagerie_utilisateur where id_message = ".$_GET["id_message"]." and id_expediteur=".$_SESSION["user"]["id_utilisateur"]." and lu=0 and rappel=0");
  $daterappel = db_valeur ("SELECT count(*) FROM gt_jointure_messagerie_utilisateur where id_message = ".$_GET["id_message"]." and id_expediteur=".$_SESSION["user"]["id_utilisateur"]." and daterappel is not null");
  		
			      
	echo '<form action="message_envoi.php?id_message='.$_GET["id_message"].'" method="POST" enctype="multipart/form-data" OnSubmit="return controle_formulaire_rappels();">';
	if(count($destinataires) >0) 
	{
    // début du tableau
    echo '<table>'."\n";
        // première ligne on affiche les titres prénom et surnom dans 2 colonnes
        echo '<tr>';
        ?>
        <td bgcolor="#669999" style="text-align:center;vertical-align:middle;">&nbsp;<b><u><?php echo $trad["MESSAGERIE_destinataire"]; ?> </u></b>&nbsp;</td>
        <td bgcolor="#669999" style="text-align:center;vertical-align:middle;">&nbsp;<b><u><?php echo $trad["MESSAGERIE_date_heure_lecture"]; ?></u></b>&nbsp;</td>
        <?php        
        if ($nbrappelnul==0)
        {
        		if ($daterappel)
        		{?>
        		<td><b><u><?php echo $trad["MESSAGERIE_date_heure_rappel"]; ?></u></b></td>
        		<?php
        		}
        		else {}
    		}
    	  else
    	  {
        echo"<td>";
        echo "<img style=\"margin-left:5px;\" src=\"../templates/module_messagerie/inverser_selection.png\" class=\"lien\" onclick=\"select_rappels();\" ".infobulle($trad["MESSAGERIE_inverser_selection"])." />";
		  echo "<input class=\"button\" style=\"margin-left:10px;width:60px;\" type=\"submit\" name=\"rappel\" value=\" ".$trad["MESSAGERIE_rappel"]." \" ".infobulle($trad["MESSAGERIE_envoi_rappel"])." />";
		  echo "</td>";
        }
        echo '</tr>'."\n";
		
	// lecture et affichage des résultats sur 2 colonnes, 1 résultat par ligne.
	foreach ($destinataires as $destinataire_tmp)
	{
	 	  $destinataire = db_ligne ("SELECT * FROM gt_utilisateur where id_utilisateur = '".$destinataire_tmp['id_utilisateur']."'");
   	  echo '<tr>';
        echo '<td bgcolor="#CCCCCC" style="vertical-align:middle;text-align:left;">'.$destinataire['nom'].' '.$destinataire['prenom'].'</td>';
        echo '<td bgcolor="#CCCCCC" style="vertical-align:middle;text-align:right;">'.versDateHeureFR($destinataire_tmp['datelu']).'</td>';
        if (($destinataire_tmp['lu']==0) && ($destinataire_tmp['rappel']==0))
        {echo '<td><input style="margin-left:5px;" type="checkbox" checked="true" name="checkbox_rappel[]" value='.$destinataire_tmp["id_utilisateur"].'></input><img style="margin-left:30px;" src="../templates/module_messagerie/rappel.png" /></td>';}
        if ((($destinataire_tmp['lu']==0) && ($destinataire_tmp['rappel']==1)) || (($destinataire_tmp['lu']==1) && ($destinataire_tmp['daterappel'])))
           {echo '<td style="text-align:right;">'.versDateHeureFR($destinataire_tmp['daterappel']).'</td>';}
           	
        echo '</tr>'."\n";
    }
    echo '</table>'."\n";
    echo '</form>';	
    // fin du tableau.	
	
}
		echo "<br />";
		echo "<div class=\"content\" style=\"padding:12px;padding-top:10px;width:95%;\"><b><u>".$trad["MESSAGERIE_message"].";</u></b>".$messagerie_tmp["description"]."";
		echo "<p style=\"margin-left:810px;\" class=\"lien\" onclick=\"window.print();\"><img style=\"padding-right:5px;\" src=\"".PATH_TPL."module_messagerie/imprimer.png\" /></p>";
		echo "</div>";
		echo "<br /><br />";
?>
		<div class="lien" style="width:100px;vertical-align:middle;" onclick="close_popupLightbox();"><img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/retour.png" /><?php echo $trad["MESSAGERIE_retour"]; ?></div>
		<div class="lien" style="width:100px;margin-left:400px;margin-top:-25px;vertical-align:middle;" <?php echo "onclick=\"redir('elements_trait.php?id_message=".$messagerie_tmp["id_message"]."&source=envoi&type=archiver&tri=".$_GET["tri"]."');\";" ?> ><img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/archive.png" /><?php echo $trad["MESSAGERIE_archiver"]; ?></div>
		<div class="lien" style="width:100px;margin-left:800px;margin-top:-25px;vertical-align:middle;" <?php echo "onclick=\"redir('elements_trait.php?id_message=".$messagerie_tmp["id_message"]."&source=envoi&type=corbeille&tri=".$_GET["tri"]."');\";" ?> ><img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/supprime.png" /><?php echo $trad["MESSAGERIE_supprimer"]; ?></div>
<?php	
	////	Fichiers joints + footer
		aff_fichiers_joints($objet["messagerie"], $_GET["id_message"], "popup");
		
?>
		</table>
	</td>
</tr></table>

</table>
</div>
		<div style="text-align:center;margin-top:20px;">
      <input type="button" class="button" name="transfert" value="<?php echo $trad["MESSAGERIE_envoyer"]; ?>" style="width:120px;" onclick="redir_popupLightbox('transfert_edit.php?id_message=<?php echo $_GET["id_message"]; ?>')"/>			
		</div>


<?php
require_once PATH_INC."footer.inc.php";
?>
