m<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
require_once PATH_INC."header.inc.php";
$delai = "300";
$version = " V2.17.0-2.3";
$nom_module ="Messagerie interne";

//// Vérification admin
if ($_SESSION['user']['admin_general'] == 1)
{
  //// Test la présence du module messagerie
  $test = 0;
  $test_module = db_tableau("SELECT * FROM gt_module");
  foreach ($test_module as $module)
  {
	if ($module["nom"] == "messagerie")
	{$test = 1;}
  }

  if ($test == 0)
  {
  
?>
	<script type="text/javascript">
	/* Installation du module */
  	var answer1 = confirm("Détail de l'installation du module <?php echo $nom_module.$version; ?>.\n\n- Création de la table gt_messagerie,\n- Création de la table gt_jointure_messagerie_utilisateur,\n- Création de la table gt_transfert_id_fichier_messagerie,\n- Inscription du module dans la table gt_module.\n\nY. VEILLET");
  	if (answer1)
  	{
	<?php
	//// Table gt_messagerie
	db_query("
	CREATE TABLE IF NOT EXISTS `gt_messagerie` 
	(
  `id_message` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_dossier` int( 10 ) unsigned NOT NULL DEFAULT '1',
  `expediteur` text NULL,   
  `id_expediteur` int(10) unsigned DEFAULT NULL,
  `titre` mediumtext,
  `description` mediumtext,
  `date` datetime DEFAULT NULL,
  `supprime_envoi` int(1) DEFAULT '0',
  `brouillon` int(1) DEFAULT '0',
  `affichage_destinataire` int(1) DEFAULT '0',
  `premier_destinataire` text NULL,   
   PRIMARY KEY (`id_message`)
   )
   ");
	//// Table gt_jointure_messagerie_utilisateur
	db_query("
	CREATE TABLE IF NOT EXISTS `gt_jointure_messagerie_utilisateur` 
	(
  `id_message` int(10) unsigned NOT NULL,
  `id_dossier` int( 10 ) unsigned NOT NULL DEFAULT '1',
  `utilisateur` text NULL,
  `id_utilisateur` int(11) NOT NULL,
  `id_expediteur` int(11) NOT NULL,
  `supprime_reception` int(1) DEFAULT '0',
  `lu` int(1) NOT NULL DEFAULT '0',
  `datelu` datetime DEFAULT NULL,
  `rappel` int(1) NOT NULL DEFAULT '0',
  `daterappel` datetime DEFAULT NULL,
  PRIMARY KEY (`id_message`,`id_utilisateur`)
	)
	");
	//// Table gt_transfert_id_fichier_messagerie
	db_query("
	CREATE TABLE IF NOT EXISTS `gt_transfert_id_fichier_messagerie`
	(
  `id_transfert` int(10) unsigned NOT NULL auto_increment,
  `id_message` int(10) unsigned NOT NULL,
  `nom_fichier` mediumtext NOT NULL,   
  `id_fichier_origine` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_transfert`)
	)
	");
	//// Table gt_messagerie_dossier
	
	 db_query(" 
	CREATE TABLE IF NOT EXISTS `gt_messagerie_dossier` 
	(
	`id_dossier` int(10) unsigned NOT NULL auto_increment,
	`id_dossier_parent` int(10) unsigned NOT NULL default '0',
	`nom` tinytext,
	`description` text,
	`raccourci` tinyint(4) default NULL,
	`date_crea` datetime default NULL,
	`id_utilisateur` int(10) unsigned default NULL,
	`invite` tinytext,
	`date_modif` datetime default NULL,
	`id_utilisateur_modif` int(10) unsigned default NULL,
	PRIMARY KEY  (`id_dossier`,`id_dossier_parent`)
	) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=85
	");
	//// Table gt_messagerie_reglages
	
	db_query(" 
	CREATE TABLE IF NOT EXISTS `gt_messagerie_reglages` 
	(
	`id_utilisateur` int(10) unsigned NOT NULL,
	`alerte_sonore` int(10) unsigned NOT NULL,
	`delai` int(10) unsigned NOT NULL DEFAULT '".$delai."' ,
	PRIMARY KEY  (`id_utilisateur`)
	) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=85
	");  	
	//// Activation du module dans agora
	db_query("INSERT INTO `gt_module` (`nom`, `module_path`) VALUES ('messagerie', 'module_messagerie')");
	?>
	alert("Module <?php echo $nom_module.$version; ?> installé.\n\nRenommer ou supprimer le fichier Install.php !\nAttendre la redirection pour configurer le module.");
  	window.location.replace('../module_espaces/index.php');
  	}
	else 
	{window.location.replace('index.php');}
</script>
<?php 
}
  else
  {
	//// MAJ 2.15.2-2.1
	// TRI DOSSIERS
	$test1_id_dossier = db_query("SHOW COLUMNS FROM `gt_messagerie` LIKE '`id_dossier`'");
	if(!count($test1_id_dossier)) 
	{
	  db_query("ALTER TABLE `gt_messagerie` ADD  `id_dossier` int( 10 ) unsigned NOT NULL DEFAULT '1' AFTER  `id_message`");
	}
	
	$test2_id_dossier = db_query("SHOW COLUMNS FROM `gt_jointure_messagerie_utilisateur` LIKE '`id_dossier`'");
	if(!count($test2_id_dossier)) 
	{
	    db_query("ALTER TABLE `gt_jointure_messagerie_utilisateur` ADD  `id_dossier` int( 10 ) unsigned NOT NULL DEFAULT '1' AFTER `id_message`");
	}
		
	db_query(" 
	CREATE TABLE IF NOT EXISTS `gt_messagerie_dossier` 
	(
	`id_dossier` int(10) unsigned NOT NULL auto_increment,
	`id_dossier_parent` int(10) unsigned NOT NULL default '0',
	`nom` tinytext,
	`description` text,
	`raccourci` tinyint(4) default NULL,
	`date_crea` datetime default NULL,
	`id_utilisateur` int(10) unsigned default NULL,
	`invite` tinytext,
	`date_modif` datetime default NULL,
	`id_utilisateur_modif` int(10) unsigned default NULL,
	PRIMARY KEY  (`id_dossier`,`id_dossier_parent`)
	) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=85
	");
	// REGLAGES
	db_query(" 
	CREATE TABLE IF NOT EXISTS `gt_messagerie_reglages` 
	(
	`id_utilisateur` int(10) unsigned NOT NULL,
	`alerte_sonore` int(10) unsigned NOT NULL,
	`delai` int(10) unsigned NOT NULL DEFAULT '".$delai."' ,
	PRIMARY KEY  (`id_utilisateur`)
	) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=85
	");  	
	
	 //// MAJ 2.16.3
	 // PROBLEME DE TRANSFERT FICHIER
	 db_query("RENAME TABLE `gt_transfert_id_fichier_messagerie` TO  `gt_transfert_id_fichier_messagerie_old` ");
	 db_query("
	CREATE TABLE IF NOT EXISTS `gt_transfert_id_fichier_messagerie`
	(
	 `id_transfert` int(10) unsigned NOT NULL auto_increment,
	 `id_message` int(10) unsigned NOT NULL,
	 `nom_fichier` mediumtext NOT NULL,   
	 `id_fichier_origine` int(10) unsigned NOT NULL,
	 PRIMARY KEY (`id_transfert`)
	)
	");
	$transfert_table = db_tableau("SELECT * FROM `gt_transfert_id_fichier_messagerie_old`");
	foreach ($transfert_table as $table_tmp)
	{
	     db_query("INSERT INTO `gt_transfert_id_fichier_messagerie` SET `id_message` = '".$table_tmp['id_message']."', `nom_fichier` = '".$table_tmp['nom_fichier']."', `id_fichier_origine` = '".$table_tmp['id_fichier_origine']."' ");
	}
	db_query("DROP TABLE `gt_transfert_id_fichier_messagerie_old` ");
	// VISIBILITE DOSSIERS SUR TOUS LES ESPACES
	db_query("UPDATE `gt_jointure_objet` SET `id_espace`= NULL WHERE `type_objet`= 'messagerie_dossier' ");

	// INFO ET REDIRECTION
	alert("Modifications SQL faites pour mettre à jour le module ".$nom_module.$version.".");
	redir('index.php');
  }
}
else 
{redir('index.php');}
?>