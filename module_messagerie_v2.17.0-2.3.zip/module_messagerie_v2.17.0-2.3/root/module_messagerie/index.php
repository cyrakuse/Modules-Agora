<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
init_id_dossier();
$droit_acces_dossier = droit_acces_controler($objet["messagerie_dossier"], $_GET["id_dossier"], 1);
elements_width_height_type_affichage("medium","50px","bloc");
		

//// Traitement du Form
require_once "inputs_trait.php";	

$cpt_element = 0;
$red1 = "";
$red2 = "";
$red3 = "";
$red4 = "";
$red5 = "";

if (!$_SESSION["user"]["id_utilisateur"])
{
alert("Connexion obligatoire pour l'utilisation de ce module !");
}
else
{
//// Redirection Cible = reception
////
if(!isset($_GET["cible"]))
{redir('index.php?cible=reception&tri='.$trad["MESSAGERIE_date"].''); }

//// Cibles
////
if (isset($_GET["cible"]))
{	
	//// SQL
	$sql0="select * from gt_messagerie where ";
	$sql1= " id_message in (select id_message from gt_jointure_messagerie_utilisateur where id_utilisateur=".$_SESSION["user"]["id_utilisateur"];
	$sql2 = " id_expediteur=".$_SESSION["user"]["id_utilisateur"];
	$sql3 = $sql0.$sql1." and supprime_reception=1 )"." or ".$sql2." and supprime_envoi=1  order by ".$tri."";
	$sql4 = $sql0.$sql1." and supprime_reception=3 and id_dossier='".$_GET["id_dossier"]."')"." or ".$sql2." and supprime_envoi=3  and id_dossier='".$_GET["id_dossier"]."' order by ".$tri."";
	$sql = $sql0.$sql1." and supprime_reception=0 ) order by ".$tri."";
	//// Nombre de messages de chaque cible
	$nbmessage_reception = db_valeur ("select count(*) from gt_jointure_messagerie_utilisateur where id_utilisateur = '".$_SESSION["user"]["id_utilisateur"]."' and supprime_reception=0 ");						
	$nbmessage_envoi = db_valeur ("select count(*) from gt_messagerie where id_expediteur = '".$_SESSION["user"]["id_utilisateur"]."' and supprime_envoi=0 and brouillon=0 ");						
	$nbmessage_brouillons = db_valeur ("select count(*) from gt_messagerie where id_expediteur = '".$_SESSION["user"]["id_utilisateur"]."' and supprime_envoi=0 and brouillon=1 ");						
	$nbmessage_archives_envoi = db_valeur ("select count(*) from gt_messagerie where id_expediteur = '".$_SESSION["user"]["id_utilisateur"]."' and supprime_envoi=3");						
	$nbmessage_archives_reception = db_valeur ("select count(*) from gt_jointure_messagerie_utilisateur where id_utilisateur = '".$_SESSION["user"]["id_utilisateur"]."' and supprime_reception=3");						
	$nbmessage_archives = $nbmessage_archives_envoi + $nbmessage_archives_reception;
	
	$nbcorbeille=0;
	$tbcorbeille = db_tableau($sql3);

	foreach($tbcorbeille as $message_tmp)
	{
	$nbcorbeille++;
	}
	$src_photo_corbeille = PATH_TPL."module_messagerie/Corbeille_pleine.png";
	
	if ($nbcorbeille==0)
	{
	$src_photo_corbeille =  PATH_TPL."module_messagerie/corbeille.png";
	}
	if ($nbcorbeille > 5)
	{
	?>
	<script type="text/javascript">
	alert ("<?php echo $trad["MESSAGERIE_suppression_corbeille"]; ?>")
	</script>
	<?php 
	}
	?>
	<table id="contenu_principal_centre" width="95%"style="margin:auto;"><tr>
	<td id="menu_gauche_block_td">
	<div id="menu_gauche_block_flottant">
	
	<?php
	//// ACTIVATION/DESACTIVATION DU SON
	// INITIALISATION
	$alerte_sonore = 0;
	$style_son_on = '';
	$style_son_off = '';
	
	// INSERTION ET MAJ DE REGLAGES
	if (isset($_POST["reglages_user"]))	
	{
		if ($_POST["reglages_user"] > 0)
		{
			db_query("UPDATE `gt_messagerie_reglages` SET `alerte_sonore` = '".$_POST["alerte_sonore"]."' WHERE `id_utilisateur` = '".$_SESSION["user"]["id_utilisateur"]."'");
		}
	redir('index.php?cible='.$_GET["cible"].'&tri='.$trad["MESSAGERIE_date"].'');
	}
	
	// FORMULAIRE DE REGLAGES	
	$reglages_user = db_valeur("SELECT COUNT(*) FROM `gt_messagerie_reglages` WHERE `id_utilisateur` = '".$_SESSION["user"]["id_utilisateur"]."'");
	if (!$reglages_user)
	{
		db_query("INSERT INTO `gt_messagerie_reglages` SET `id_utilisateur` = '".$_SESSION["user"]["id_utilisateur"]."', `alerte_sonore` = '0'");
	}
	
	$alerte_sonore = db_valeur("SELECT `alerte_sonore` FROM `gt_messagerie_reglages` WHERE `id_utilisateur` = '".$_SESSION["user"]["id_utilisateur"]."'");
	if($alerte_sonore != 1)
	{
		$style_son_off = "color:red;"; $style_son_on = '';
	}
	else
	{
		$style_son_on = "color:red;"; $style_son_off = '';
	}
	
	echo "<div class=\"menu_gauche_block content\" style=\"height:28px;\">"; 
	echo "<table>";
	echo "<tr><td class=\"menu_gauche_img\"><img src=\"".PATH_TPL."module_messagerie/son.png\" ".infobulle($trad["MESSAGERIE_alerte_sonore"])."></td>"; 
	echo "<form name=\"range\" action=\"\" method=\"POST\">";
	echo "<td><input type=\"hidden\" name=\"reglages_user\" value=\"".$reglages_user."\"/>";
	
	////  SELECT POUR FIREFOX ET IE 
	if((preg_match('/Firefox/i',$_SERVER['HTTP_USER_AGENT'])) || (preg_match('/MSIE/i',$_SERVER['HTTP_USER_AGENT'])))
	{
	    echo "<td style='margin-left:10px;'>".$trad["MESSAGERIE_alerte_sonore"]."";
	    echo "<SELECT name='alerte_sonore' onchange='document.range.submit();'>";
	    if($alerte_sonore != 1)
	    {
		echo "<OPTION VALUE='0' style='".$style_son_off."'>".$trad["MESSAGERIE_Off"]."</OPTION>";
		echo "<OPTION VALUE='1' style='".$style_son_on."'>".$trad["MESSAGERIE_On"]."</OPTION>";
	    }
	    else
	    {
		echo "<OPTION VALUE='1' style='".$style_son_on."'>".$trad["MESSAGERIE_On"]."</OPTION>";
		echo "<OPTION VALUE='0' style='".$style_son_off."'>".$trad["MESSAGERIE_Off"]."</OPTION>";
	    }
	    echo "</SELECT>";
	    echo "</td>";
	}
	else
	//// RANGE POUR CHROME
	{
	?>
	<td style="margin-left:20px;<?php echo $style_son_off; ?>"><?php echo $trad["MESSAGERIE_Off"]; ?></td>
	<td>
	<input style="margin-top:10px;width:50px;height:10px;" id="inputRange1" type="range" min="0" max="1" value="<?php echo $alerte_sonore; ?>" step="1" name="alerte_sonore" />
	</td>

	<td style="<?php echo $style_son_on;?>"><?php echo $trad["MESSAGERIE_On"]; ?></td>
	</td>
	<td><input class="button" style="margin-left:25px;width:70px;" type="submit" value="<?php echo $trad["MESSAGERIE_modifier"]; ?>"/></td>
	<?php
	}
	?>
	
	</form>
	</tr>
	</table>
	</div>
		
	<div class="menu_gauche_block content">
	<table width="100%">

	<?php
	if ($_GET["cible"]=="reception")
	{
	$messages_non_lu = db_tableau ("SELECT * FROM gt_jointure_messagerie_utilisateur WHERE id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."' and supprime_reception=0 and lu=0");						
	$nb_messages_non_lu = count($messages_non_lu);
	?>
	
	<script type="text/javascript">
	
	////		AFFICHAGE ET VERIFICATION DES MESSAGES INTERNES TOUTES LES 5 MINUTES (defaut)
	////
	
	function messagerie_verif()
	{
		requete_ajax("../module_messagerie/messagerie_messages.php");
		var nb_messages_non_lu = Http_Request_Result;
		<?php
		$delai = db_valeur("SELECT `delai` FROM `gt_messagerie_reglages` WHERE `id_utilisateur` = '".$_SESSION["user"]["id_utilisateur"]."'");
		if (!$delai) {$delai="300";}
		?>
		var delai = <?php echo $delai; ?>*1000;
		if (nb_messages_non_lu != <?php echo $nb_messages_non_lu; ?>)
		{
		$('#contenu_principal_centre').load('index_ajax.php?cible=reception&tri=<?php echo $_GET["tri"]; ?>').fadeIn("slow");
		}
		window.setTimeout("messagerie_verif()",delai);
	}
	
	function forcer_affichage_statut_message(url)
	{
	$('#contenu_principal_centre').load('index_ajax.php?cible=reception&tri=<?php echo $_GET["tri"]; ?>').fadeIn("fast");
	popupLightbox(url,false,950);
	}
	
	<?php
	{echo "$(window).load(function(){ messagerie_verif(); });";}
	?>
	</script>
	<?php
		//// Ajout du logs
		add_logs("Boite de réception");	
		//// Couleurs cibles affichages entêtes DIV
		$red1 = "color:red";
		$entete = $trad["MESSAGERIE_reçu"];
	}
		
	if ($_GET["cible"]=="envoi")
	{
		//// Ajout du logs
		add_logs("Message envoyés");	
		//// SQL
		$sql = $sql0.$sql2." and supprime_envoi=0 and brouillon = 0 order by ".$tri."";
		//// Couleurs cibles affichages entêtes DIV
		$red2 = "color:red";
		$entete = $trad["MESSAGERIE_envoye"];
	}
		
	if ($_GET["cible"]=="corbeille")
	{
		//// Ajout du logs
		add_logs("Corbeille");	
		//// SQL
		$sql = $sql3;
		//// Couleurs cibles
		$red3 = "color:red";
		$entete = $trad["MESSAGERIE_corbeille"];
	}
		
	if ($_GET["cible"]=="brouillons")
	{
		//// Ajout du logs
		add_logs("Brouillons");	
		//// SQL
		$sql = $sql0.$sql2." and supprime_envoi = 0 and brouillon = 1 order by ".$tri."";
				//// Couleurs cibles affichages entêtes DIV
		$red4 = "color:red";
		$entete = $trad["MESSAGERIE_brouillons"];
	}
	
	if ($_GET["cible"]=="archives")
	{
		//// Ajout du logs
		add_logs("Archives");	
		//// SQL
		$sql = $sql4;
		//// Couleurs cibles affichages entêtes DIV
		$red5 = "color:red";
		$entete = $trad["MESSAGERIE_archives"];
	}
					
	?>
	<tr class="lien" onclick="redir('index.php?cible=reception&tri=<?php echo $trad["MESSAGERIE_date"];?>');"><td class="menu_gauche_img"><img src="<?php echo PATH_TPL; ?>module_messagerie/boite_reception.png" /></td><td class="menu_gauche_txt" style="<?php echo $red1; ?>;"><?php echo $trad["MESSAGERIE_boite_reception"]." (".$nbmessage_reception.")";?></td></tr>
	<tr class="lien" onclick="redir('index.php?cible=envoi&tri=<?php echo $trad["MESSAGERIE_date"];?>');"><td class="menu_gauche_img"><img src="<?php echo PATH_TPL; ?>module_messagerie/boite_envoi.png" /></td><td class="menu_gauche_txt" style="<?php echo $red2; ?>;"><?php echo $trad["MESSAGERIE_boite_envoi"]." (".$nbmessage_envoi.")"; ?></td></tr>
	<tr class="lien" ><td onclick="redir('index.php?cible=corbeille&tri=<?php echo $trad["MESSAGERIE_date"];?>');" class="menu_gauche_img"><img src="<?php echo $src_photo_corbeille; ?>" /></td><td onclick="redir('index.php?cible=corbeille&tri=<?php echo $trad["MESSAGERIE_date"];?>');" class="menu_gauche_txt" style="<?php echo $red3; ?>;"> <?php echo $trad["MESSAGERIE_corbeille"]." (".$nbcorbeille.")";?></td><td><input class= "button" type="button" style="width:50px;" value="<?php echo $trad["MESSAGERIE_vider"]; ?>" onclick="redir('elements_trait.php?type=vider&cible=<?php echo $_GET["cible"]; ?>&tri=<?php echo $_GET["tri"]; ?>');"/></td></tr>
	</table>
	</div>
	<div class="content menu_gauche_block">
	<table width="100%">
	<?php
	if ($_GET["cible"]!="archives")
	{
	?>
	<tr class="lien" onclick="redir('index.php?cible=archives&id_dossier=1&tri=<?php echo $trad["MESSAGERIE_date"];?>');"><td class="menu_gauche_img"><img src="<?php echo PATH_TPL; ?>module_messagerie/archive.png" /></td><td class="menu_gauche_txt" style="<?php echo $red5; ?>;"><?php echo $trad["MESSAGERIE_archives"]." (".$nbmessage_archives.")"; ?></td></tr>
	<?php
	}
	if ($_GET["cible"]=="archives")
	{
	////	MENU D'ARBORESCENCE
	$cfg_menu_arbo = array("objet"=>$objet["messagerie_dossier"], "id_objet"=>$_GET["id_dossier"], "ajouter_dossier"=>true, "droit_acces_dossier"=>$droit_acces_dossier);
 	require_once "menu_arborescence.inc.php";
	$cfg_menu_elements = array("objet"=>$objet["messagerie"], "objet_dossier"=>$objet["messagerie_dossier"], "id_objet_dossier"=>$_GET["id_dossier"], "droit_acces_dossier"=>$droit_acces_dossier);
	require_once "elements_menu_selection.inc.php";
 	}
 	
	?>
	</table>
	</div>
	<div class="content menu_gauche_block">
	<table width="100%">
	<tr class="lien" onclick="redir('index.php?cible=brouillons&tri=<?php echo $trad["MESSAGERIE_date"];?>');"><td class="menu_gauche_img"><img style="width:28px;" src="<?php echo PATH_TPL; ?>module_messagerie/brouillon.png" /></td><td class="menu_gauche_txt" style="<?php echo $red4; ?>;"><?php echo $trad["MESSAGERIE_brouillons"]." (".$nbmessage_brouillons.")"; ?></td></tr>
	<tr class="lien" onclick="redir('message_edit.php');"><td class="menu_gauche_img"><img src="<?php echo PATH_TPL; ?>module_messagerie/ajouter.png" /></td><td class="menu_gauche_txt"><?php echo $trad["MESSAGERIE_ecrire_message"]; ?></td></tr>
	</table>
	</div>
	
	<?php
	//// MENU ADMIN
	if ($_SESSION['user']['admin_general'] == 1)
	{
	echo "<div class=\"content menu_gauche_block\"  >";
	echo "<input type=\"checkbox\" id=\"checkbox_menu\" style=\"display:none;\">";
	echo "<div class='menu_gauche_img lien' onClick=\"select_checkbox_message('checkbox_menu');afficher_menu_admin();\"><img src=\"".PATH_TPL."module_messagerie/nettoyage.png\"/></div>";
	echo "<div id=\"entete_admin\" class='menu_gauche_txt lien' onClick=\"select_checkbox_message('checkbox_menu');afficher_menu_admin();\">".$trad["MESSAGERIE_parametres"]."</div>";

	// DELAI
	if (isset($_POST["delai"]))	
	{
		db_query("UPDATE `gt_messagerie_reglages` SET `delai` = '".$_POST["delai"]."'");
		alert("".$trad["MESSAGERIE_nouveau_delai"]."".$_POST["delai"]."");
		redir('index.php?cible=reception&tri='.$trad["MESSAGERIE_date"].'');
	}
	
	$delai = db_valeur("SELECT `delai` FROM `gt_messagerie_reglages` WHERE `id_utilisateur` = '".$_SESSION["user"]["id_utilisateur"]."'");
	//	MENU DEPLIABLE
	echo "<div id='menu_admin_edit' style='padding-left:30px;display:none;'>";
		// NETTOYAGE / DELAI
		echo "<table>";
		echo "<tr class=\"lien\" onClick=\"redir('nettoyage_messages.php');\"><td class=\"menu_gauche_txt\"><img style=\"margin-right:5px;\" src=\"".PATH_TPL."divers/fleche_droite.png\">".$trad["MESSAGERIE_nettoyage"]."</td></tr>";
		echo "<form action=\"\" method=\"POST\" name=\"form_delai\" onsubmit=\"return controle_delai();\">";
		echo "<tr><td class=\"menu_gauche_txt\"><img style=\"margin-right:5px;\" src=\"".PATH_TPL."divers/fleche_droite.png\">".$trad["MESSAGERIE_delai"]."<input type=\"text\" value=\"".$delai."\" name=\"delai\" style=\"width:30px;\" /><input class=\"button\" style=\"text-align:center;width:35px;margin-left:5px;\" type=\"submit\" name=\"ok\" value=\"OK\"/></td></tr>";
		echo "</form>";
		echo "</table>";
		echo "</div>";
	echo "</div>";
	}

	echo "</td>";
	echo "<td>";
	
	if ($_GET["cible"] == "archives")
	{ 
		////	MENU CHEMIN + OBJETS_DOSSIERS
		////
		require_once "dossiers.inc.php";
	}
	?>
	<div class="div_elem_deselect" style="width:98%;padding:5px;">
	<table>
	<tr>
	<script type="text/javascript">
					
					
	//// Coche decoche checkbox
		function select_messages()
		{
			checkbox_message = document.getElementsByName("checkbox_message[]");
			for(i=0; i<checkbox_message.length; i++)
			{	 
				var value_div_elem = checkbox_message[i].value;
				if(checkbox_message[i].checked == false)
				{
				checkbox_message[i].checked = true;
				selection_element_message("div_elem_message_"+value_div_elem);
				}
				else
				{
				checkbox_message[i].checked = false;
				selection_element_message("div_elem_message_"+value_div_elem);
				}
			}
		}

	//// Coche decoche checkbox
		function select_checkbox_message(id_checkbox)
		{
			checkbox_message = document.getElementById(id_checkbox);
			if(checkbox_message.checked == false)
			{
				checkbox_message.checked = true;
			}
			else
			{
				checkbox_message.checked = false;
			}
		}

		////	SÉLECTION / DÉSELECTION D'UN ÉLEMENT  (onClick sur l'élement ("bascule") / via selection_tous_elements() )
		////	select => true / false / "bascule"
		function deselection_element_message(cpt_div_element, select)
		{
		if(isNaN(cpt_div_element))	cpt_div_element = cpt_div_element.replace('checkbox_element_message_','').replace('div_elem_message_','');
		checkbox_element = element("checkbox_element_message_"+cpt_div_element);
		if(select==true ||  (select==undefined && checkbox_element.checked==false))			{ checkbox_element.checked = true;   element("div_elem_message_"+cpt_div_element).className = "div_elem_select"; }
		else if(select==false ||  (select==undefined && checkbox_element.checked==true))	{ checkbox_element.checked = false;  element("div_elem_message_"+cpt_div_element).className = "div_elem_deselect"; }
		}
	
	////    On contrôle les messages cochés
		function controle_formulaire()
		{
		//// Au moins un message sélectionné!
		var nb_message_coches = 0;
		inputs_message = document.getElementsByName("checkbox_message[]");
		for(i=0; i<inputs_message.length; i++){
		if(inputs_message[i].checked==true)  nb_message_coches++;
		}
		if(nb_message_coches==0)	{ alert("<?php echo "".$trad["MESSAGERIE_Checkbox_message"]."";?>");  return false; }
		}
		
	////   Deplie/plie le menu admin
		function afficher_menu_admin()
		{
			if(existe("menu_admin_edit"))
			{
				var checkbox_menu = document.getElementById("checkbox_menu");
				if((checkbox_menu.checked == true) && (element("menu_admin_edit").style.display=="none"))	
				{
					afficher_dynamic('menu_admin_edit',true);
					element("entete_admin").style.color = "blue";
				}
				if((checkbox_menu.checked == false) && (element("menu_admin_edit").style.display!="none"))
				{
					afficher_dynamic('menu_admin_edit',false);
					element("entete_admin").style.color = "";
				}
			}
		}
		
		////    On contrôle le form admin
		function controle_delai()
		{
		// Il doit y avoir un titre
		if ((get_value("delai").length==0) || (get_value("delai")==0)) {alert("<?php echo $trad["MESSAGERIE_specifier_delai"]; ?>"); return false; }
			if (get_value("delai")<60) 
			{
			alert("<?php echo $trad["MESSAGERIE_alerte_delai"]; ?>");
			return true;
			}
		}
		
	</script>
					
	<?php 
	echo "<form action=\"\" name='form_tri' method=\"GET\" >";
	echo "<input type=\"hidden\" name=\"cible\" value=\"".$_GET["cible"]."\"/>";
	if ($_GET["cible"] == "archives")
	{
	echo "<input type=\"hidden\" name=\"id_dossier\" value=\"".$_GET["id_dossier"]."\" style=\"margin-right:5x;\" />";
	}
	
		if ($_GET["cible"]=="corbeille")
		{
			echo "<td>";
			echo "<img style=\"margin-left:5px;\" src=\"".PATH_TPL."module_messagerie/inverser_selection.png\" class=\"lien\" onclick=\"select_messages();\" ".infobulle($trad["MESSAGERIE_inverser_selection"])." />";
			echo "<b style=\"color:red;margin-left:5px;padding-right:40px;\"> ".$entete." </b>";
			echo "<input class=\"button\" type=\"submit\" name=\"action\" value=\"".$trad["MESSAGERIE_restaure"]."\" style=\"margin-right:40px;\" Onclick=\"return controle_formulaire();\"/>";
			echo "</td>";
		}
		else
		{
			echo "<td>";
			echo "<img style=\"margin-left:5px;\" src=\"".PATH_TPL."module_messagerie/inverser_selection.png\" class=\"lien\" onclick=\"select_messages();\" ".infobulle($trad["MESSAGERIE_inverser_selection"])." />";
			echo "<b style=\"color:red;margin-left:5px;padding-right:40px;\"> ".$entete." </b>";
			echo "</td>";
		}
		
		if ($_GET["cible"] != "archives")
		{
		?>
		<script type="text/javascript">
		////	SÉLECTION / DÉSELECTION D'UN ÉLEMENT  (onClick sur l'élement ("bascule") / via selection_tous_elements() )
		////	select => true / false / "bascule"
		function selection_element_message(cpt_div_element, select)
		{
			if(isNaN(cpt_div_element))	cpt_div_element = cpt_div_element.replace('checkbox_element_message_','').replace('div_elem_message_','');
			checkbox_element = element("checkbox_element_message_"+cpt_div_element);
			if(select==true ||  (select==undefined && checkbox_element.checked==false))			{ checkbox_element.checked = true;   element("div_elem_message_"+cpt_div_element).className = "div_elem_select"; }
			else if(select==false ||  (select==undefined && checkbox_element.checked==true))	{ checkbox_element.checked = false;  element("div_elem_message_"+cpt_div_element).className = "div_elem_deselect"; }
		}
		</script>
		<td><input class="button" type="submit" name="action" value="<?php echo "".$trad["MESSAGERIE_archiver"]."";?>" style="margin-right:40px;" Onclick="return controle_formulaire();"/></td>
		<?php
		}
		?>
		<td><input class="button" type="submit" name="action" value="<?php echo "".$trad["MESSAGERIE_supprimer"]."";?>" style="margin-right:40px;" Onclick="return controle_formulaire();"/></td>
		<td><b><?php echo "".$trad["MESSAGERIE_trier_par"]."";?></b>
		<select name="tri" onchange="window.document.form_tri.submit();">
		<?php echo "<option>".$tri1."</option>";
		if (($_GET["cible"] != "envoi") && ($_GET["cible"] != "brouillons"))
		{
		echo "<option>".$tri2."</option>";
		}
		if ($_GET["cible"] == "envoi")
		{
		echo "<option>".$tri4."</option>";
		}
		echo "<option>".$tri3."</option>";
		echo "</select>";
		echo "</td>";
		echo "</tr>";
		echo "</table>";
		echo "</div>";
		echo "<hr style=\"clear:both;visibility:hidden;\">";
		
		$liste_message=db_tableau($sql);
		@$_REQUEST["type_affichage"]="liste";
		$height_element="50px";
		$width_element ="99%";
		
		foreach($liste_message as $message_tmp)
		{
		$id_div_message = div_element_message($objet["messagerie"], $message_tmp["id_message"]);
					
		$id_message=$message_tmp['id_message'];
		$lu= db_valeur ("select lu from gt_jointure_messagerie_utilisateur where id_message = '".$id_message."' and id_utilisateur=".$_SESSION["user"]["id_utilisateur"]."" );
		$rappel = db_valeur ("select rappel from gt_jointure_messagerie_utilisateur where id_message = '".$id_message."' and id_utilisateur=".$_SESSION["user"]["id_utilisateur"]."" );
		$nblud = db_valeur ("select count(*) from gt_jointure_messagerie_utilisateur where id_message = '".$id_message."' and lu=1 and id_expediteur=".$_SESSION["user"]["id_utilisateur"]."" );								
		$nbnlud = db_valeur ("select count(*) from gt_jointure_messagerie_utilisateur where id_message = '".$id_message."' and lu=0 and id_expediteur=".$_SESSION["user"]["id_utilisateur"]."" );								
		$nbrappeld = db_valeur ("select count(*) from gt_jointure_messagerie_utilisateur where id_message = '".$id_message."' and rappel=1 and id_expediteur=".$_SESSION["user"]["id_utilisateur"]."" );		
		$nbmessage = db_valeur ("select count(*) from gt_jointure_messagerie_utilisateur where id_message = '".$id_message."' and id_expediteur=".$_SESSION["user"]["id_utilisateur"]."" );						
		$nbbrouillon = db_valeur ("select count(*) from gt_messagerie where id_message = '".$id_message."' and brouillon = 1 ");						
		$fichier_joint = db_valeur("SELECT count(*) FROM gt_jointure_objet_fichier WHERE type_objet='messagerie' AND id_objet='".$id_message."'");
		$fichier_joint_transferer = db_valeur("SELECT count(*) FROM gt_transfert_id_fichier_messagerie WHERE id_message='".$id_message."'");	
		$fichiers_joints = $fichier_joint + $fichier_joint_transferer;
		$cpt_element++;
		$stop_propagation = "deselection_element_message('$id_div_message');select_checkbox_message('box_".$message_tmp["id_message"]."');";
		$lien_popup = "onclick=\"".$stop_propagation."popupLightbox('message_envoi.php?id_message=".$message_tmp["id_message"]."&tri=".$_GET["tri"]."',false,950);\" ";
			
   			
			if ($_GET["cible"]=="envoi")
			{
				if ($nbnlud==0)
				{
				$src_photo  =  PATH_TPL."module_messagerie/envoi.png";
				$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_lu"]);
				}
				else 
				{
				$src_photo  =  PATH_TPL."module_messagerie/boite_envoi.png";
				$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_envoye"]);
				}
			}
			
			if ($_GET["cible"]=="brouillons")
			{
				$lien_popup = "onclick=\"".$stop_propagation."redir('brouillon_edit.php?id_message=".$message_tmp["id_message"]."&tri=".$_GET["tri"]."');\" ";
				$src_photo  =  PATH_TPL."module_messagerie/brouillon.png";
				$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_brouillons"]);	
			}
								
			if (($_GET["cible"]=="corbeille") || ($_GET["cible"]=="archives"))
			{
				if ($_GET["cible"]=="archives")
				{$lien_popup = "onclick=\"".$stop_propagation."popupLightbox('message_archives.php?lu=ok&id_dossier=".$_GET["id_dossier"]."&id_message=".$message_tmp["id_message"]."&tri=".$_GET["tri"]."',false,950);\" ";}
				else {$lien_popup = "onclick=\"".$stop_propagation."popupLightbox('message_corbeille.php?lu=ok&id_message=".$message_tmp["id_message"]."&tri=".$_GET["tri"]."',false,950);\" ";}
				$nb = 0;
		     	$id_expediteur=$_SESSION["user"]["id_utilisateur"];
		     	$tab = db_tableau("select * from gt_messagerie where id_message='".$id_message."' and id_expediteur='".$id_expediteur."' ");
				
		  		foreach($tab as $message)
		  		{
		  		$nb++;
		  		}
		
				if ( $nb == 1 )
		     	{
					if ($nbbrouillon)
					{
					$src_photo  =  PATH_TPL."module_messagerie/brouillon.png";
					$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_brouillons"]);
					}
					else
					{
					$src_photo  =  PATH_TPL."module_messagerie/envoi.png";
					$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_envoye"]);
					}
		     	}
				else
				{
					if ($lu == 1)
					{
					$src_photo  =  PATH_TPL."module_messagerie/lu.png";
					$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_reçu"]);
					}
					else
					{
						if ($rappel==1)
						{
							//icone rappel
							$src_photo  =  PATH_TPL."module_messagerie/rappel.png";
							$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_rappel_non_lu"]);
						}
						else 
						{
							$src_photo  =  PATH_TPL."module_messagerie/non_lu.png";
							$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_reçu"]);
						}
					}
				}
			}
			
			if ($_GET["cible"]=="reception")
			{				
				//$lien_popup = "onclick=\"".$stop_propagation."popupLightbox('message_reception.php?lu=ok&id_message=".$message_tmp["id_message"]."',false,950);\" ";
				$lien_popup = "onclick=\"".$stop_propagation."forcer_affichage_statut_message
				('message_reception.php?lu=ok&id_message=".$message_tmp["id_message"]."&tri=".$_GET["tri"]."');\" ";
					
				if ($lu==1)
				{
					//icone message lu
					$src_photo  =  PATH_TPL."module_messagerie/lu.png";
					$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_lu"]);
				}
				else
				{
					if ($rappel==1)
					{
						//icone rappel
						$src_photo  =  PATH_TPL."module_messagerie/rappel.png";
						$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_rappel_non_lu"]);
					}
					else 
					{
						//icone message non lu
						$src_photo  =  PATH_TPL."module_messagerie/non_lu.png";
						$lien_popup=$lien_popup.infobulle($trad["MESSAGERIE_nonlu"]);
					}	
				}
			}
			echo "<div class=\"div_elem_contenu\" onclick=\"selection_element_message('$id_div_message');select_checkbox_message('box_".$message_tmp["id_message"]."');\" >";
			echo "<table class=\"div_elem_table\"><tr>";
			echo "<td style=\"width:10px;vertical-align:middle; \"><input onclick=\" select_checkbox_message('box_".$message_tmp["id_message"]."'); \" type=\"checkbox\" name=\"checkbox_message[]\" id=\"box_".$message_tmp["id_message"]."\" value=\"".$message_tmp["id_message"]."\" /></td>";  							
			echo "<td class=\"div_elem_td lien\" style=\"width:70px;text-align:center;\" ".$lien_popup." ><img src=\"".$src_photo."\" style=\"max-width:70px;max-height:35px;\" /></td>";

			if ((isset ($_GET["cible"])) && ($_GET["cible"]=="envoi") || (isset ($_GET["cible"])) && ($_GET["cible"]=="brouillons"))
			{
				echo "<td class=\"div_elem_td\"><span class=\"lien\" ".$lien_popup.">".$trad["MESSAGERIE_objet"]." : ".$message_tmp["titre"]."";
				
				if ($_GET["cible"]=="envoi")
				{
					echo "<p>".$trad["MESSAGERIE_destinataire"]." : ";
					$destinataires = db_tableau("SELECT * from gt_jointure_messagerie_utilisateur WHERE id_message='".$id_message."' order by utilisateur");
					$nb_affichage_destinataire = 0;
						foreach ($destinataires as $id_destinataires)
						{
							$nb_affichage_destinataire ++;
							$info_destinataires = db_ligne ("select * from gt_utilisateur where id_utilisateur = '".$id_destinataires["id_utilisateur"]."'");
							if (count($destinataires) == 1)
							{
								echo "".$info_destinataires["nom"]." ".$info_destinataires["prenom"]."";
							}
							else 
							{						
								if ($nb_affichage_destinataire < 4)
								{
									echo "".$info_destinataires["nom"]." ".$info_destinataires["prenom"]."";
									if ($nb_affichage_destinataire < 3)
									{echo ", ";} 
									else 
									{echo " ...";}
								}
							}
						}
							echo "</p>";
						echo "</span></td>";
				}
			}
			
			else
			{
				$expediteur=db_ligne("select * from gt_utilisateur where id_utilisateur=".$message_tmp["id_expediteur"]."");						
				echo "<td class=\"div_elem_td\"><span class=\"lien\" ".$lien_popup.">".$trad["MESSAGERIE_de"]." : ".$expediteur["prenom"]." ".$expediteur["nom"]."<p>".$trad["MESSAGERIE_objet"]." : ".$message_tmp["titre"]."</p></span></td>";
			}
			
			if($fichiers_joints)
			{	
				$lienfichier=infobulle($trad["MESSAGERIE_fichier"]);
				echo "<td class=\"div_elem_td\" style=\"text-align:right;\">".$fichiers_joints."<img ".$lienfichier." src=\"".PATH_TPL."module_messagerie/piece_jointe.png\" style=\"height:30px;margin-right:20px;\" />".versDateHeureFR($message_tmp["date"])."</br></td>";
			}
			else
			{
				echo "<td class=\"div_elem_td\" style=\"text-align:right;\">".versDateHeureFR($message_tmp["date"])."</br></td>";
			}
			
			echo "<td style=\"width:30px;padding-left:5px;text-align:right;\">";
			
			
			if ((isset ($_GET["cible"])) && ($_GET["cible"]=="envoi"))
			{
				$lienlecteur=infobulle($trad["MESSAGERIE_lecteur"]);
				//echo "<table><tr class=\"lien\" ><td ".$lienlecteur." onclick=\"redir('message_envoi.php?id_message=".$message_tmp["id_message"]."');\" style=\"width:15px;\"><img src=\"".PATH_TPL."module_messagerie/lecteur.png\" /><b>".$nblud."/".$nbmessage."</b></td>";
				echo "<table><tr class=\"lien\" ><td ".$lienlecteur." onclick=\"popupLightbox
				('message_envoi.php?id_message=".$message_tmp["id_message"]."',false,950);\" style=\"width:15px;\"><img src=\"".PATH_TPL."module_messagerie/lecteur.png\" /><b>".$nblud."/".$nbmessage."</b></td>";
				if ($nbrappeld)
				{
				$lienrappel=infobulle($trad["MESSAGERIE_rappel_envoi"]);
				//echo "<td ".$lienrappel." onclick=\"redir('message_envoi.php?id_message=".$message_tmp["id_message"]."');\" style=\"width:15px;\"><img style=\"margin-left:5px;\"src=\"".PATH_TPL."module_messagerie/rappel.png\" /><b style=\"color:red;\">".$nbrappeld."</b></td>";}
				echo "<td ".$lienrappel." onclick=\"popupLightbox('message_envoi.php?id_message=".$message_tmp["id_message"]."',false,950);\" style=\"width:15px;\"><img style=\"margin-left:5px;\"src=\"".PATH_TPL."module_messagerie/rappel.png\" /><b style=\"color:red;\">".$nbrappeld."</b></td>";}
				echo "</tr></table>";
			}
														
			echo "</td>";
			echo "<td style=\"width:30px;padding-left:5px;text-align:right;\">";
			echo "</td>";
			echo "</tr></table>";
			echo "</div>";
			echo "</div>";
			//echo "<hr style=\"clear:both;visibility:hidden;\">";
			
		}
								
			////	AUCUN MESSAGE
			if($cpt_element==0)		echo "<div class=\"div_elem_aucun\">".$trad["MESSAGERIE_aucun_message"]."</div>";
			?>
	</td>
	</tr>
	</table>

<?php
		echo "</form>";	
}
require_once PATH_INC."footer.inc.php"; 
}
?>
