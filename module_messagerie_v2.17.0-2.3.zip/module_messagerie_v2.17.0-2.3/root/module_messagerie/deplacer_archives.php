<?php
////	INIT
require_once "commun.inc.php";
require_once PATH_INC."header.inc.php";
$nbmessage_archives_envoi = db_valeur ("select count(*) from gt_messagerie where id_expediteur = '".$_SESSION["user"]["id_utilisateur"]."' and supprime_envoi=3");						
$nbmessage_archives_reception = db_valeur ("select count(*) from gt_jointure_messagerie_utilisateur where id_utilisateur = '".$_SESSION["user"]["id_utilisateur"]."' and supprime_reception=3");						
$nbmessage_archives = $nbmessage_archives_envoi + $nbmessage_archives_reception;
?>


<script type="text/javascript">
////	On redimensionne le popup
resizePopup(450,400);
////    On indique le dossier sélectionné dans le formulaire
function select_dossier_action(id_dossier)		{ set_value("id_dossier",id_dossier); }
</script>


<form action="deplacer.php" method="post">
	<fieldset class="fieldset_titre"><?php echo $trad["deplacer_autre_dossier"]; ?></fieldset>
	<?php
	////	MENU D'ARBORESCENCE
	$cfg_menu_arbo = array("objet"=>$objet[$_GET["type_objet_dossier"]], "id_objet"=>$_GET["id_dossier_parent"]);
	require_once "menu_arborescence.inc.php";
	?>
	<div style="text-align:right;padding:10px;">
		<input type="hidden" name="id_dossier" id="id_dossier" value="<?php echo $_GET["id_dossier"]; ?>">
		<?php
		// Mets en mémoire les elements à déplacer
		foreach($_GET["SelectedElems"] as $type_elem => $ids_elems)  echo "<input type='hidden' name='SelectedElems[".$type_elem."]' value=\"".$ids_elems."\" />";
		?>
		<input type="submit" value="<?php echo $trad["modifier"]; ?>" class="button_big" />
	</div>
</form>


<?php require PATH_INC."footer.inc.php"; ?>