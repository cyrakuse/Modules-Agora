<?php
////	INITIALISATION
////
@define("MODULE_NOM","messagerie");
@define("MODULE_PATH","module_messagerie");
require_once "../includes/global.inc.php";
//$objet["messagerie"]= array("type_objet"=>"messagerie", "cle_id_objet"=>"id_message", "table_objet"=>"gt_messagerie");
$objet["messagerie"] = array("type_objet"=>"messagerie", "cle_id_objet"=>"id_message", "type_conteneur"=>"messagerie_dossier", "cle_id_conteneur"=>"id_dossier", "table_objet"=>"gt_messagerie");
$objet["messagerie_dossier"] = array("type_objet"=>"messagerie_dossier", "cle_id_objet"=>"id_dossier", "type_contenu"=>"messagerie", "cle_id_contenu"=>"id_message", "table_objet"=>"gt_messagerie_dossier");

patch_dossier_racine($objet["messagerie_dossier"]);

// transforme une date heure fr (jj/mm/aaaa) en date heure us (aaaa-mm-jj)
function versDateHeureUS($madate)
{
	if ($madate!="")
	{
		$annee    = substr($madate, 6, 4);
		$mois    = substr($madate, 3, 2);
		$jour        = substr($madate, 0, 2);
		$heure=substr($madate, 11, 8);
		$nouv_date=$annee."-".$mois."-".$jour." ".$heure;
		return $nouv_date;
	}
	else
	{
		return "";
	}
}

// transforme une date heure us (aaaa-mm-jj) en date heure fr (jj/mm/aaaa)
function versDateHeureFR($madate)
{
	if ($madate!="")
	{
		$annee    = substr($madate, 0, 4);
		$mois    = substr($madate, 5, 2);
		$jour        = substr($madate, 8, 2);
		$heure=substr($madate, 11, 8);
		$nouv_date=$jour."/".$mois."/".$annee." ".$heure;
		return $nouv_date;
	}
	else
	{
		return "";
	}
}

////	SUPPRESSION D'UN MESSAGE
////
function suppr_messagerie_message($id_message)
{
	$cible = 1;
	$testenvoi = db_valeur("SELECT * FROM gt_messagerie where id_message='".$id_message."' and id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");
	if ($testenvoi)
	{
		db_query("UPDATE gt_messagerie set supprime_envoi='".$cible."', id_dossier=1 where id_message='".$id_message."' and id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");
	}
	else
	{
	  	db_query("UPDATE gt_jointure_messagerie_utilisateur set id_dossier=1, supprime_reception='".$cible."' where id_message='".$id_message."' and id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."'");
	}
}

////	SUPPRESSION D'UN DOSSIER
////
function suppr_messagerie_dossier($id_dossier)
{
	global $objet;
	if($id_dossier>1)
	{
		// on créé la liste des dossiers & on supprime chaque dossier
		$liste_dossiers_suppr = arborescence($objet["messagerie_dossier"], $id_dossier, "tous");
		foreach($liste_dossiers_suppr as $dossier_tmp)
		{
			// On supprime chaque message du dossier puis le dossier en question
			$liste_messagerie = db_tableau("SELECT * FROM gt_messagerie WHERE id_dossier='".$dossier_tmp["id_dossier"]."'");
			foreach($liste_messagerie as $infos_messagerie)	{ suppr_messagerie_message($infos_messagerie["id_message"]); }
			
			$liste_jointure_messagerie = db_tableau("SELECT * FROM gt_jointure_messagerie_utilisateur WHERE id_dossier='".$dossier_tmp["id_dossier"]."'");
			foreach($liste_jointure_messagerie as $infos_messagerie)	{ suppr_messagerie_message($infos_messagerie["id_message"]); }
			
			suppr_objet($objet["messagerie_dossier"], $dossier_tmp["id_dossier"]);
		}
	}
}


////	DEPLACEMENT D'UN MESSAGE
////
function deplacer_messagerie_message($id_message, $id_dossier_destination)
{
	global $objet;
	////	On déplace le message
	$testenvoi = db_valeur("SELECT * FROM gt_messagerie where id_message=".db_format($id_message)." and id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");
	if ($testenvoi)
	{
		db_query("UPDATE gt_messagerie SET id_dossier=".db_format($id_dossier_destination)." WHERE id_expediteur='".$_SESSION["user"]["id_utilisateur"]."' and id_message=".db_format($id_message)." ");
	}
	else
	{
		db_query("UPDATE gt_jointure_messagerie_utilisateur SET id_dossier=".db_format($id_dossier_destination)." WHERE id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."' and id_message=".db_format($id_message)." ");
	}
}

////	DEPLACEMENT D'UN DOSSIER
////
function deplacer_messagerie_dossier($id_dossier, $id_dossier_destination)
{
	global $objet;
	////	Accès total au dossier en question  &  accès en écriture au dossier destination  &  controle du déplacement du dossier
	if(controle_deplacement_dossier($objet["messagerie_dossier"],$id_dossier,$id_dossier_destination)==1) 
	{
	db_query("UPDATE gt_messagerie_dossier SET id_dossier_parent=".db_format($id_dossier_destination)." WHERE id_dossier=".db_format($id_dossier));
	}
}

////	MENU CHEMIN (ARBORESCENCE DOSSIER)
////
function menu_archives($obj_tmp, $id_objet, $url_destination="index.php?cible=archives")
{
	////	INIT
	global $trad;
	$affichage = "<div class='div_menu_horizontal pas_selection'>";
	foreach(chemin($obj_tmp,$id_objet,"tableau") as $dossier_tmp)
	{
		if ($dossier_tmp["id_dossier"] == 1)
		{
			$affichage .= "<a href=\"".$url_destination."&id_dossier=".$dossier_tmp["id_dossier"]."&tri=".$trad["MESSAGERIE_date"]."\" class='lien'><img src=\"".PATH_TPL."divers/dossier_arborescence.png\" />&nbsp;".$trad["MESSAGERIE_archives"]."</a> &nbsp; ";
		}
		else
		{
			$affichage .= "<a href=\"".$url_destination."&id_dossier=".$dossier_tmp["id_dossier"]."&tri=".$trad["MESSAGERIE_date"]."\" class='lien'><img src=\"".PATH_TPL."divers/dossier_arborescence.png\" />&nbsp;".text_reduit($dossier_tmp["nom"],30)."</a> &nbsp; ";
		}
	}
	$affichage .= "</div>";
	$affichage .= "<hr style='clear:both;visibility:hidden;' />";
	return $affichage;
}

////	DIV & CHECKBOX DE SELECTION D'ELEMENT
////
function div_element_message($obj_tmp, $id_objet)
{
	// Init
	global $cpt_div_element, $width_element, $height_element;
	//$cpt_div_element ++;
	$cpt_div_element = $id_objet;
	$id_div_element = "div_elem_message_".$cpt_div_element;
	// Style
	$style  = "width:".$width_element.";height:".$height_element.";cursor:url('".PATH_TPL."divers/check.png'),crosshair;";
	//if(@$_REQUEST["type_affichage"]=="liste")	$style .= STYLE_ELEMENT_LISTE.STYLE_BORDER_RADIUS2;
	// Affiche le menu
	echo "<div id='".$id_div_element."' class='div_elem_deselect' style=\"".$style."\" onMouseMove='$(this).click(function(event){ event.stopPropagation();	});'>
				<input type='checkbox' name='SelectedElems[]' id='checkbox_element_message_".$cpt_div_element."' value=\"".$obj_tmp["type_objet"]."-".$id_objet."\" style='display:none;' />";
	// Retourne l'id du block de l'element
	return $id_div_element;
}

function contenu_archives($obj_tmp, $id_objet, $affichage="page")
{
	global $objet, $trad;
	// Recup des resultats
	$objet_enfant = $objet[$obj_tmp["type_contenu"]];
	$nb_elems_tmp1	 = db_valeur("SELECT count(*) FROM ".$objet_enfant["table_objet"]." WHERE id_dossier=".$id_objet." ".sql_affichage($objet_enfant,$id_objet));
	$nb_elems_tmp2	 = db_valeur("SELECT count(*) FROM gt_jointure_messagerie_utilisateur WHERE id_dossier=".$id_objet." ".sql_affichage($objet_enfant,$id_objet));
	$nb_elems_tmp = $nb_elems_tmp1 + $nb_elems_tmp2;
	$nb_dossiers_tmp = db_valeur("SELECT count(*) FROM ".$obj_tmp["table_objet"]." WHERE id_dossier_parent=".$id_objet." ".sql_affichage($obj_tmp)." ");
	// Prepare l'affichage
	$contenu_dossier = $nb_elems_tmp." ".($nb_elems_tmp>1?$trad["MESSAGERIE_message(s)"]:$trad["MESSAGERIE_message(s)"]);
	if($nb_dossiers_tmp>0)		$contenu_dossier .= " &nbsp;-&nbsp; ".$nb_dossiers_tmp." ".($nb_dossiers_tmp>1?$trad["dossiers"]:$trad["dossier"]);
	if($obj_tmp["type_objet"]=="fichier_dossier" && $nb_elems_tmp>0)	$contenu_dossier .= " &nbsp;-&nbsp; ".afficher_taille(dossier_taille(PATH_MOD_FICHIER.chemin($obj_tmp,$id_objet,"url")));
	// Affichage
	if($affichage=="page")	$contenu_dossier = "<div class='menu_gauche_ligne'><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/info.png\" /></div><div class='menu_gauche_txt'>".$contenu_dossier."</div></div>";
	return $contenu_dossier;
}

function redir_popupLightbox($url)
{
echo "<script type=\"text/javascript\">";
echo "window.parent.location.replace('".$url."')";
echo "</script>";
exit;
}


?>