<?php 
////	AFFICHAGE DES DOSSIERS
////
elements_width_height_type_affichage("medium","63px","bloc");
$cfg_dossiers = array("objet"=>$objet["messagerie_dossier"], "id_objet"=>$_GET["id_dossier"]);
$tri_dossiers = array("date_crea@@desc","date_crea@@asc","date_modif@@desc","date_modif@@asc","id_utilisateur@@asc","id_utilisateur@@desc","nom@@asc","nom@@desc");
$liste_dossiers	= db_tableau("SELECT * FROM ".$cfg_dossiers["objet"]["table_objet"]." WHERE id_dossier_parent='".$cfg_dossiers["id_objet"]."' ".sql_affichage($cfg_dossiers["objet"])."  ".tri_sql($tri_dossiers)." ");

$liste_archives	= db_valeur("SELECT COUNT(*) FROM ".$cfg_dossiers["objet"]["table_objet"]." WHERE id_utilisateur = '".$_SESSION["user"]["id_utilisateur"]."'");
if ($liste_archives > 0)
{
echo menu_archives($objet["messagerie_dossier"], $_GET["id_dossier"]);

foreach($liste_dossiers as $dossier_tmp)
{
	////	INIT + JAVASCRIPT REDIRECTION
	$dossier_tmp["droit_acces"]	= droit_acces($cfg_dossiers["objet"],$dossier_tmp);
	$dossier_racine = is_dossier_racine($cfg_dossiers["objet"],$dossier_tmp["id_dossier"]);
	$js_redir =  " class='lien' onClick=\"redir('".php_self()."?cible=archives&id_dossier=".$dossier_tmp["id_dossier"]."&tri=".$trad["MESSAGERIE_date"]."');\" ";
	////	MENU ELEMENT  &  MODIFIER / DEPLACER / SUPPRIMER
	$cfg_menu_elem = array("objet"=>$cfg_dossiers["objet"], "objet_infos"=>$dossier_tmp);
	if($dossier_tmp["droit_acces"]==3)
	{
		$cfg_menu_elem["modif"] = "dossier_edit.php?type_objet_dossier=".$cfg_dossiers["objet"]["type_objet"]."&id_dossier=".$dossier_tmp["id_dossier"];
		if($dossier_racine==false){
			$cfg_menu_elem["deplacer"] = "deplacer_archives.php?type_objet_dossier=".$cfg_dossiers["objet"]["type_objet"]."&id_dossier_parent=".$dossier_tmp["id_dossier_parent"]."&SelectedElems[".$cfg_dossiers["objet"]["type_objet"]."]=".$dossier_tmp["id_dossier"];
			$cfg_menu_elem["suppr"] = "elements_suppr.php?id_dossier=".$dossier_tmp["id_dossier"]."&id_dossier_retour=".$dossier_tmp["id_dossier_parent"];
			$cfg_menu_elem["suppr_text_confirm"] = $trad["confirmer_suppr_dossier"];
		}
	}
	
	////	DIV SELECTIONNABLE + OPTIONS
	$cfg_menu_elem["id_div_element"] = div_element($cfg_dossiers["objet"], $dossier_tmp["id_dossier"]);
	//require "element_menu.inc.php";
	require "element_menu_contextuel.inc.php";
		////	AFFICHAGE BLOCK
			echo "<div class='div_elem_contenu' ".infobulle($dossier_tmp["description"])." >";
				echo "<table class='div_elem_table div_elem_infos'>";
					// Affichage : 2 lignes / 2 colonnes
					if(str_replace("px","",$width_element)<=200) {
						echo "<tr><td style='vertical-align:middle;' ><img src=\"".PATH_TPL."divers/dossier.png\" ".$js_redir." /></td></tr>";
						echo "<tr><td ".$js_redir." > ".$dossier_tmp["nom"]."</td></tr>";
					}
					else {
						echo "<tr><td style='vertical-align:middle;text-align:center;width:80px'><img src=\"".PATH_TPL."divers/dossier.png\" ".$js_redir." /></td>";
						echo "<td style='vertical-align:middle;text-align:left;'><div ".$js_redir." style='line-height:15px;'>".$dossier_tmp["nom"]."</div></td></tr>";
					}
				echo "</table>";
			echo "</div>";
		echo "</div>";
	echo "</div>";
}
echo "<hr style=\"clear:both;visibility:hidden;\">";
}
?>