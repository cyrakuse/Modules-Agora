<?php
////	INIT
require_once "commun.inc.php";
require_once PATH_INC."header.inc.php";//pour charger la lib. javascript..


////	ON DEPLACE PLUSIEURS ELEMENTS
// MESSAGE
foreach(SelectedElemsArray("messagerie") as $id_message)
{deplacer_messagerie_message($id_message, $_POST["id_dossier"]);}
// DOSSIER
foreach(SelectedElemsArray("messagerie_dossier") as $id_dossier)
{deplacer_messagerie_dossier($id_dossier, $_POST["id_dossier"]);}

////		DECONNEXION À LA BDD & FERMETURE DU POPUP
reload_close();
//redir_popupLightbox("index.php?cible=archives&id_dossier=".$_POST["id_dossier"]."&tri=date");
?>