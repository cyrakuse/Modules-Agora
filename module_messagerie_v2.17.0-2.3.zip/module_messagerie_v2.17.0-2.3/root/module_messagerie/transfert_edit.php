<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
require_once PATH_INC."header.inc.php";
init_editeur_tinymce();


//// Fonctions javascript
////
require "fonctions.php";


if(isset($_GET["id_message"]))
{
	$messagerie_tmp = objet_infos($objet["messagerie"], $_GET["id_message"]);
}

////	TRANSFERT DU MESSAGE
////
if(isset($_POST["titre"]) && isset($_POST["envoyer"]))
{
   db_query("INSERT INTO gt_messagerie SET id_expediteur='".$_SESSION["user"]["id_utilisateur"]."', expediteur='".$_SESSION["user"]["nom"]."', titre=".db_format($_POST["titre"]).", description=".db_format($_POST["description"],"editeur").", date=NOW()");
	$id_message= db_last_id();
	
	if (isset($_POST["affichage_destinataire"]))
   {
   	db_query("UPDATE gt_messagerie SET affichage_destinataire=1 where id_expediteur='".$_SESSION["user"]["id_utilisateur"]."' and id_message='".$id_message."'");
   }
	
	foreach($_POST["id_destinataires"] as $id_destinataire)
	{
	  $utilisateur= db_valeur("SELECT nom from gt_utilisateur WHERE id_utilisateur = '".$id_destinataire."'");
	  db_query("INSERT INTO gt_jointure_messagerie_utilisateur SET id_message='".$id_message."', utilisateur='".$utilisateur."', id_utilisateur= '".$id_destinataire."', id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");
	}
	
	$premier_destinataire = db_valeur("SELECT utilisateur from gt_jointure_messagerie_utilisateur where id_message='".$id_message."' order by utilisateur");
	db_query("UPDATE gt_messagerie SET premier_destinataire='".$premier_destinataire."' WHERE id_message = '".$id_message."' ");
	
	
	////	AJOUTER FICHIERS JOINTS
	affecter_droits_acces($objet["messagerie"],$id_message);
	ajouter_fichiers_joint($objet["messagerie"],$id_message);
		
	////	AJOUTER FICHIERS JOINTS DEJA PRESENTS
	$fichiers_a_transferes = db_tableau("SELECT * FROM gt_jointure_objet_fichier WHERE type_objet='messagerie' AND id_objet='".$_GET["id_message"]."' ORDER BY nom_fichier");
	if(count($fichiers_a_transferes)>0)
	{
		foreach ($fichiers_a_transferes as $fichiers_en_transfert)
		{
			if (isset($_POST["joindre_fichier_".$fichiers_en_transfert["id_fichier"].""]))
			{
				db_query("INSERT INTO gt_transfert_id_fichier_messagerie SET id_message='".$id_message."' , nom_fichier='".$fichiers_en_transfert["nom_fichier"]."', id_fichier_origine= '".$fichiers_en_transfert["id_fichier"]."'");
			}
		}
	}
	
	////	AJOUTER FICHIERS JOINTS DEJA TRANSFERER
	$fichiers_deja_transferer = db_tableau("SELECT * FROM gt_transfert_id_fichier_messagerie WHERE id_message='".$_GET["id_message"]."' ORDER BY nom_fichier");	
	if(count($fichiers_deja_transferer)>0)
	{		
		foreach ($fichiers_deja_transferer as $fichiers_en_transfert)
		{
			if (isset($_POST["joindre_fichier_".$fichiers_en_transfert["id_fichier_origine"].""]))
			{
				db_query("INSERT INTO gt_transfert_id_fichier_messagerie SET id_message='".$id_message."' , nom_fichier='".$fichiers_en_transfert["nom_fichier"]."', id_fichier_origine= '".$fichiers_en_transfert["id_fichier_origine"]."'");
			}
		}
	}

	//// REDIRECTION
	redir('index.php?cible=envoi&tri='.$trad["MESSAGERIE_date"].'');
}

$nb_fichiers_max=10;
?>

<form action="transfert_edit.php?id_message=<?php echo $_GET["id_message"]; ?>" method="POST" id="form_mail" enctype="multipart/form-data" class="contenu_principal_centre">
	<table id="contenu_principal_table" cellspacing="10px"><tr>
		<td id="menu_gauche_block_td">
		 <div id="menu_gauche_block_td">
		      <div style="vertical-align:middle;" class="menu_gauche_block content lien" onclick="redir('index.php?cible=reception&tri=<?php echo $trad["MESSAGERIE_date"]; ?>');">
				<img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/retour.png" /><?php echo $trad["MESSAGERIE_retour"]; ?>
			</div>
		
			<div class="menu_gauche_block content">
				<img src="<?php echo PATH_TPL; ?>module_utilisateurs/menu.png" style="margin-top:-10px;margin-right:-10px;float:right;opacity:0.4;filter:alpha(opacity=40);" />

			<?php
				////	UTILISATEURS DE CHAQUE ESPACE
				////
				foreach(espaces_affectes_user(null,true) as $espace_tmp)
				{
					////	ESPACE (+ tableau pour les affectations auto)
					$id_espace_tmp = "E".$espace_tmp["id_espace"];
					echo "<img src=\"".PATH_TPL."module_messagerie/espaces.png\" align=\"absmiddle\" />&nbsp; <span class=\"lien\" onClick=\"afficher_dynamic('".$id_espace_tmp."');\" ".infobulle($espace_tmp["description"]).">".$espace_tmp["nom"]."</span> &nbsp;";
					echo "<div class='content' id=\"".$id_espace_tmp."\" style=\"display:".(($_SESSION["espace"]["id_espace"]==$espace_tmp["id_espace"])?"block":"none")."\">";
						
						$groupes_users = groupes_users($espace_tmp["id_espace"]);
						if ($groupes_users)
						{
						echo "<p class='lien' style='color:blue' onclick=\"afficher_dynamic('div_groupe_E".$espace_tmp["id_espace"]."');\"><img src=\"".PATH_TPL."divers/dossier_ouvrir.png\" class='icone_groupe' /><img src=\"".PATH_TPL."module_utilisateurs/utilisateurs_groupe.png\" class='icone_groupe' />".$trad["MESSAGERIE_groupes"]."</p>";
						echo "<div id=\"div_groupe_E".$espace_tmp["id_espace"]."\" style=\"display:none;margin-left:15px\">";		
						foreach($groupes_users as $groupe_tmp)
						{
							// Init
							$checkbox_users_groupe = ''; 
							foreach($groupe_tmp["users_tab"] as $id_user)	
							{
							  @$groupe_tmp["users_tab_bis"][] = "'E".$espace_tmp["id_espace"]."_U".$id_user.",'";
							  if ($id_user != $_SESSION["user"]["id_utilisateur"])
							  {
							    $checkbox_tmp = "check_user_groupe('E".$espace_tmp["id_espace"]."_U".$id_user."');";
							    $checkbox_users_groupe = $checkbox_users_groupe.$checkbox_tmp;
							  }
							}
							$groupe_tmp["id_groupe_bis"] = "E".$espace_tmp["id_espace"]."_G".$groupe_tmp["id_groupe"];
							
							// Groupe  +  tableau des utilisateurs
							echo "<div style='padding-left:5px;'>";
							echo "<img src=\"".PATH_TPL."module_messagerie/plus.png\" class='noprint' onclick=\"afficher_dynamic('div_E".$espace_tmp["id_espace"]."_G".$groupe_tmp["id_groupe"]."');\"/>";
							echo "<img onclick=\"afficher_dynamic('div_E".$espace_tmp["id_espace"]."_G".$groupe_tmp["id_groupe"]."');\" src=\"".PATH_TPL."module_utilisateurs/utilisateurs_groupe.png\" class='icone_groupe' />";
							echo "<span id='txt_".$groupe_tmp["id_groupe_bis"]."' class='lien' onClick=\"afficher_dynamic('div_E".$espace_tmp["id_espace"]."_G".$groupe_tmp["id_groupe"]."');\" title=\"".$groupe_tmp["users_title"]."\">".$groupe_tmp["titre"]."</span>";
							echo "<img style='margin-left:10px;' src=\"".PATH_TPL."module_messagerie/inverser_selection.png\" class='icone_groupe lien' onclick=\"checkbox_text(this);".$checkbox_users_groupe."\" ".infobulle($trad["MESSAGERIE_inverser_selection"])." />";
							echo "<input type='checkbox' id='box_".$groupe_tmp["id_groupe_bis"]."' style='visibility:hidden;' />";
												
							//echo "<script type='text/javascript'>  users_ensembles['".$groupe_tmp["id_groupe_bis"]."'] = array(".implode(",",$groupe_tmp["users_tab_bis"])."); </script>";
							
							echo "<div id=\"div_E".$espace_tmp["id_espace"]."_G".$groupe_tmp["id_groupe"]."\" style=\"display:none;margin-left:5px;\">";
							foreach(text2tab($groupe_tmp["id_utilisateurs"]) as $id_user)
							{
							$user_groupe_tmp['nom'] ='';
							$user_groupe_tmp['prenom']='';
							echo "<div name='txt_user_E".$espace_tmp["id_espace"]."_U".$id_user."' id='txt_user_E".$espace_tmp["id_espace"]."_U".$id_user."' class ='lien'";
							if ($id_user != $_SESSION["user"]["id_utilisateur"])
							{ echo "onclick = \"check_user_groupe('E".$espace_tmp["id_espace"]."_U".$id_user."');\"";}
							echo "><img src=\"".PATH_TPL."module_utilisateurs/acces_utilisateur.png\" class='icone_groupe' />";
							$sql_user = "FROM gt_utilisateur WHERE id_utilisateur = '".$id_user."'";
							$user_groupe_tmp['nom']= db_valeur("SELECT nom ".$sql_user."");
							$user_groupe_tmp['prenom']= db_valeur("SELECT prenom ".$sql_user."");
							//echo auteur($id_user);
							echo "".$user_groupe_tmp['nom']." ".$user_groupe_tmp['prenom']."";
							echo "</div>";
							}
							echo "</div>";	
							echo "</div>";
						}
						echo "</div>";
						echo "<hr/>";
						}
						
				
						////	USERS
						$tab_id_utilisateur_tmp = array();
						echo "<b class='lien' onclick=\"afficher_dynamic('div_user_E".$espace_tmp["id_espace"]."');\" style='color:blue'><img src=\"".PATH_TPL."divers/dossier_ouvrir.png\" class='icone_groupe' /><img src=\"".PATH_TPL."module_utilisateurs/acces_utilisateur.png
								\" class='icone_groupe' />".$trad["MESSAGERIE_utilisateurs"]."</b>";
								echo "<img style='margin-left:10px;' src=\"".PATH_TPL."module_messagerie/inverser_selection.png\" class=\"icone_groupe lien\" onclick=\"select_ensemble_users('".$id_espace_tmp."');afficher_dynamic('div_user_E".$espace_tmp["id_espace"]."',null,true);\" ".infobulle($trad["MESSAGERIE_inverser_selection"])." />";
					
						echo "<div id=\"div_user_E".$espace_tmp["id_espace"]."\" style=\"display:none;margin-left:5px\">";		
						foreach(users_espace($espace_tmp["id_espace"],"tableau") as $user_tmp)
						{
								$id_utilisateur_tmp = "E".$espace_tmp["id_espace"]."_U".$user_tmp["id_utilisateur"];
								$tab_id_utilisateur_tmp[] = "'".$id_utilisateur_tmp."'";
								if ($user_tmp["id_utilisateur"]!= $_SESSION["user"]["id_utilisateur"])
								{
								echo "<div style=\"padding-left:15px;\" ".infobulle($user_tmp["nom"]."<br />".$user_tmp["prenom"]."<br />".$user_tmp["societe_organisme"])." >";
								echo "<input type=\"checkbox\" name=\"id_destinataires[]\" value=\"".$user_tmp["id_utilisateur"]."\" id=\"box_".$id_utilisateur_tmp."\" onClick=\"checkbox_text(this);\" />";
								echo "<img src=\"".PATH_TPL."module_utilisateurs/acces_utilisateur.png\" class='icone_groupe' />";
								echo "<span class=\"lien\" id=\"txt_".$id_utilisateur_tmp."\" onClick=\"checkbox_text(this);\">".$user_tmp["nom"]." ".$user_tmp["prenom"]."</span>";
								echo "</div>";
							    }
						}
						////	TAB JS DES USERS  &  FIN DE LA LISTE DES USERS
						echo "<script>  users_ensembles['".$id_espace_tmp."'] = Array(".implode(",",$tab_id_utilisateur_tmp)."); </script>";
					echo "</div>";
					echo "</div><br />";
				}
				?>
			</div>
			</div>
			
			</td>
		<td>
			<div class="content">
				<p class="lien" style="color:red;">
				<input name="affichage_destinataire[]" type="checkbox" style="margin-right:5px;margin-top:-1px;" /><b onclick="select_checkbox_destinataires();"><?php echo $trad["MESSAGERIE_affichage_destinataire"];?></b>
				</p>
				<br />
				<input type="text" name="titre" value="Fwd : <?php echo $messagerie_tmp["titre"]; ?>" id="titre" style="width:90%;margin-bottom:10px;" onFocus="if(this.value=='<?php echo $trad["MESSAGERIE_titre"]; ?>') this.value='';" />
				<div class="form_libelle"><?php echo $trad["MESSAGERIE_description"]; ?>
				<textarea name="description" id="description" style="width:100%;height:250px;"><?php echo $messagerie_tmp["description"]; ?></textarea>
				<table style="width:100%;margin-top:10px;">
					
					<tr>
						<td>
							<?php
echo "<div id=\"menu_edit_objet_options\" style=\"margin-top:20px;margin-bottom:20px;float:left;\" onselectstart=\"return false;\">";

	////	FICHIERS JOINTS
	////
	
	$cfg_menu_edit = array("objet"=>$objet["messagerie"], "id_objet"=>@$_GET["id_message"]);
	
	$block_fichiers_joints = "";
		
		////	Bouton principal
		echo "<img src=\"".PATH_TPL."module_messagerie/fichier_joint.png\" />&nbsp;<span onclick=\"afficher('div_fichiers_joints','bascule','block');redir('#bottom_fichier');\" class=\"lien\">".$trad["MESSAGERIE_fichier_joint"]."</span>";
		////	Menu
		$text_max_filesize = $trad["MESSAGERIE_limite_chaque_fichier"]." ".afficher_taille(return_bytes(ini_get("upload_max_filesize")));
		$fichiers_joints = db_tableau("SELECT * FROM gt_jointure_objet_fichier WHERE type_objet='".$cfg_menu_edit["objet"]["type_objet"]."' AND id_objet='".$cfg_menu_edit["id_objet"]."' ORDER BY nom_fichier");
		$block_fichiers_joints .= "<div id=\"div_fichiers_joints\" class=\"div_options\" style=\"float:left;".((count($fichiers_joints)>0)?"display:block;":"")."\" >";
		////	Inputs d'ajout de fichiers + ajoute dans le textarea (si possible)
		for($i=1; $i<=10; $i++){
			$block_fichiers_joints .= "<div id=\"div_fichier_joint".$i."\"  ".(($i>1)?"class=\"cacher\"":"")."><input type=\"file\" name=\"add_fichier_joint".$i."\" onChange=\"affiche_fichiers(".$i.");\" title=\"".$text_max_filesize."\" /> &nbsp; ";
			$block_fichiers_joints .= "<span id=\"txt_add_fichier_joint".$i."\" onClick=\"checkbox_text(this);\" title=\"".$trad["MESSAGERIE_inserer_fichier_info"]."\" class=\"lien\" style=\"display:none;\"><img src=\"".PATH_TPL."module_messagerie/fleche_droite.png\" /> ".$trad["MESSAGERIE_inserer_fichier"]."/></span><input type=\"checkbox\" name=\"tab_add_fichier_joint[]\" value=\"add_fichier_joint".$i."\" id=\"box_add_fichier_joint".$i."\" style=\"visibility:hidden;\" /></div>";
		}
		////	FICHIERS JOINTS A TRANSFERER
		if(count($fichiers_joints)>0)	
		{
			$block_fichiers_joints .= "<hr style=\"margin:10px;\" />";
			$block_fichiers_joints .= "<b style=\"color:red;\"><u>".$trad["MESSAGERIE_fichier_a_transferer"]."</u></b>";
			$block_fichiers_joints .= "<br />";
			$block_fichiers_joints .= "<br />";
		
			foreach($fichiers_joints as $fichier_tmp)
			{
				$block_fichiers_joints .= "<div style=\"margin:5px\" id=\"fichier_joint".$fichier_tmp["id_fichier"]."\">";
				$block_fichiers_joints .= "<img src=\"".PATH_TPL."module_messagerie/fichier.png\" style=\"height:30px;\"> &nbsp; &nbsp; <i>".$fichier_tmp["nom_fichier"]."</i> ";
				$block_fichiers_joints .= "</div>";
				$block_fichiers_joints .= "<input id=\"".$fichier_tmp["id_fichier"]."\" name=\"joindre_fichier_".$fichier_tmp["id_fichier"]."[]\" type=\"checkbox\" checked=\"true\" style=\"margin-right:5px;margin-top:-1px;\" /><i class=\"lien \" onclick=\"select_checkbox_fichier(".$fichier_tmp["id_fichier"].");\">".$trad["MESSAGERIE_joindre"]." ".$fichier_tmp["nom_fichier"]." ?</i>";
				$block_fichiers_joints .= "<br />";
				$block_fichiers_joints .= "<br />";		
			}	
		}
		
		//// FICHIERS DEJA TRANSFERES
		$fichiers_deja_transferer = db_tableau("SELECT * FROM gt_transfert_id_fichier_messagerie WHERE id_message='".$_GET["id_message"]."' ORDER BY nom_fichier");	
		
		if(count($fichiers_deja_transferer)>0)
		{
			$block_fichiers_joints .= "<hr style=\"margin:10px;\" />";
			$block_fichiers_joints .= "<b style=\"color:red;\"><u>".$trad["MESSAGERIE_fichier_a_transferer"]."</u></b>";
			$block_fichiers_joints .= "<br />";
			$block_fichiers_joints .= "<br />";
				
			foreach($fichiers_deja_transferer as $fichier_tmp)
			{
				$block_fichiers_joints .= "<div style=\"margin:5px\" id=\"fichier_joint".$fichier_tmp["id_fichier_origine"]."\">";
				$block_fichiers_joints .= "<img src=\"".PATH_TPL."module_messagerie/fichier.png\" style=\"height:30px;\"> &nbsp; &nbsp; <i>".$fichier_tmp["nom_fichier"]."</i> ";
				$block_fichiers_joints .= "</div>";
				$block_fichiers_joints .= "<input id=\"".$fichier_tmp["id_fichier_origine"]."\" name=\"joindre_fichier_".$fichier_tmp["id_fichier_origine"]."[]\" type=\"checkbox\" checked=\"true\" style=\"margin-right:5px;margin-top:-1px;\" /><i class=\"lien \" onclick=\"select_checkbox_fichier(".$fichier_tmp["id_fichier_origine"].");\">".$trad["MESSAGERIE_joindre"]." ".$fichier_tmp["nom_fichier"]." ?</i>";
				$block_fichiers_joints .= "<br />";
				$block_fichiers_joints .= "<br />";
			}
		}
		
		$block_fichiers_joints .= "</div>";
		echo "<a name='bottom_fichier'></a>";

////	AFFICHAGE DES BLOCKS HIDDEN "NOTIFICATION PAR MAIL" + "FICHIERS JOINTS"  &  FIN DES OPTIONS
echo "<hr style=\"visibility:hidden;\" />".$block_fichiers_joints;
echo "</div>";

?>
					</td>
					</tr>
					<tr>
					<td colspan="2" style="text-align:center;margin-top:20px;">
						<input name="envoyer" class="button" type="submit" value="<?php echo $trad["MESSAGERIE_envoyer"]; ?>" OnClick="return controle_formulaire_envoi();" style="width:100px;" />
					</td
					</td></tr>
				</table>
			</div>
		</td>
	</tr>
</table></form>

<?php require_once PATH_INC."footer.inc.php"; ?>
