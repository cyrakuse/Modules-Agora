<?php
////	INIT
////
if(!isset($cfg_menu_elem["objet_infos"]))	$cfg_menu_elem["objet_infos"] = objet_infos($cfg_menu_elem["objet"], $cfg_menu_elem["id_objet"]);
else										$cfg_menu_elem["id_objet"] = $cfg_menu_elem["objet_infos"][$cfg_menu_elem["objet"]["cle_id_objet"]];
$id_menu_contextuel = "menu_context_".rand(1,99)."_".$cfg_menu_elem["objet"]["type_objet"]."_".$cfg_menu_elem["id_objet"];// "rand()" pour afficher 2 menus contextuels du même elem (ex: menu d'agendas)
$objet_independant = objet_independant($cfg_menu_elem["objet"],$cfg_menu_elem["objet_infos"]);
$dossier_racine = is_dossier_racine($cfg_menu_elem["objet"],$cfg_menu_elem["id_objet"]);
$txt_lecture = $txt_ecriture_limit = $txt_ecriture = "";
$icone_element_individuel = true;

////	POSITIONNEMENT DU CONTENEUR
////
if(@$cfg_menu_elem["taille_icone"]=="big")				$div_elem_style = "float:left;margin:-4px;margin-right:15px;";//menu de l'agenda, etc.
elseif(@$cfg_menu_elem["taille_icone"]=="small_inline")	$div_elem_style = "display:inline;margin-left:5px;";
else													$div_elem_style = "float:left;margin:0px;";

////	AFFICHE LE MENU
////
echo "<div class='noprint' style='".$div_elem_style."'>";

	////	AFFICHAGE DU MENU CONTEXTUEL DE L'ELEMENT
	////
	echo "<div class='menu_context' id='".$id_menu_contextuel."'>"; 

		////	MODIFIER / DEPLACER
		if(isset($cfg_menu_elem["modif"]))		echo "<div class='menu_context_ligne lien' onclick=\"popupLightbox('".$cfg_menu_elem["modif"]."',false,650);\"><div class='menu_context_img'><img src=\"".PATH_TPL."divers/crayon.png\" /></div><div class='menu_context_txt'>".$trad["modifier"]."</div></div>";
		if(isset($cfg_menu_elem["deplacer"]))	echo "<div class='menu_context_ligne lien' onclick=\"popupLightbox('".$cfg_menu_elem["deplacer"]."',false,650);\"><div class='menu_context_img'><img src=\"".PATH_TPL."divers/dossier_deplacer.png\" /></div><div class='menu_context_txt'>".$trad["deplacer_elements"]."</div></div>";

		////	SUPPRIMER
		if(isset($cfg_menu_elem["suppr"])){
			$suppr_text		 = (isset($cfg_menu_elem["suppr_text"]))  ?  $cfg_menu_elem["suppr_text"]  :  $trad["supprimer"];
			$suppr_text_confirm = (isset($cfg_menu_elem["suppr_text_confirm"]))  ?  $cfg_menu_elem["suppr_text_confirm"]  :  $trad["confirmer_suppr"];
			echo "<div class='menu_context_ligne lien' onclick=\"confirmer('".str_replace("<br>","\\n",addslashes($suppr_text_confirm))."','".$cfg_menu_elem["suppr"]."');\"><div class='menu_context_img'><img src=\"".PATH_TPL."divers/supprimer.png\" /></div><div class='menu_context_txt'>".$suppr_text."</div></div>";
		}

		////	OPTIONS DIVERSES
		if(isset($cfg_menu_elem["options_divers"])){
			foreach($cfg_menu_elem["options_divers"] as $option_tmp){
				echo "<div class='menu_context_ligne lien' onclick=\"".$option_tmp["action_js"]."\"><div class='menu_context_img'><img src=\"".$option_tmp["icone_src"]."\" /></div><div class='menu_context_txt'>".$option_tmp["text"]."</div></div>";
			}
		}

		// séparation <hr> ?
		if(isset($cfg_menu_elem["modif"]) || isset($cfg_menu_elem["deplacer"]) || isset($cfg_menu_elem["options_divers"]) || isset($cfg_menu_elem["suppr"]))
			echo "<hr class='menu_context_hr' />";

		////	DOSSIER :  NOMBRE D'ELEMENTS + TAILLE DU DOSSIER (module fichiers)
		if(preg_match("/dossier/i",$cfg_menu_elem["objet"]["type_objet"]))
			echo "<div class='menu_context_ligne'><div class='menu_context_txt_left'>".$trad["contenu_dossier"]." :</div><div class='menu_context_txt'>".contenu_archives($cfg_menu_elem["objet"],$cfg_menu_elem["id_objet"],"menu_element")."</div></div>";
	
	echo "</div>";


	////	ICONE "PLUS" & AFFICHAGE DU MENU CONTEXTUEL  (position absolute pour que l'icone "plus" soit au dessus du contenu du bloc -> exemple des images du gestionnaire de fichier qui occupent tout le bloc)
	////
	if(empty($cfg_menu_elem["taille_icone"]))		$icone_height_tmp = "height:24px;";
	elseif($cfg_menu_elem["taille_icone"]=="small")	$icone_height_tmp = "height:17px;";
	elseif($cfg_menu_elem["taille_icone"]=="big")	$icone_height_tmp = "height:30px;";
	else											$icone_height_tmp = "";
	$icone_pos_absolute	= (@$cfg_menu_elem["icone_plus_position_absolute"]==true)  ?  "position:absolute;"  :  "";
	$icone_src_tmp		= ($_SESSION["user"]["id_utilisateur"] > 0 && @strtotime($cfg_menu_elem["objet_infos"]["date_crea"]) > @$_SESSION["user"]["precedente_connexion"])  ?  "options_new"  :  "options";
	if(@$cfg_menu_elem["taille_icone"]=="small_inline")		$icone_src_tmp .= "_inline";
	echo "<img src=\"".PATH_TPL."divers/".$icone_src_tmp.".png\" class='noprint' style='".$icone_height_tmp.$icone_pos_absolute."' id='icone_".$id_menu_contextuel."' />";
	echo "<script type='text/javascript'>  menu_contextuel('".$id_menu_contextuel."','".@$cfg_menu_elem["id_div_element"]."');  </script>";


	////	SIMPLE CLICK SUR LE BLOCK -> FONCTION SPECIFIQUE OU SELECTION DU BLOCK  /  DOUBLE CLICK SUR LE BLOCK -> MODIFICATION DE L'ELEMENT
	if(isset($cfg_menu_elem["id_div_element"])){
		$clickBlock		= (isset($cfg_menu_elem["action_click_block"]))	?  $cfg_menu_elem["action_click_block"]  :  "if(typeof(selection_element)!='undefined') selection_element('".$cfg_menu_elem["id_div_element"]."');";
		$dblclickBlock	= (isset($cfg_menu_elem["modif"]))				?  "popupLightbox('".$cfg_menu_elem["modif"]."');"  :  "";
		echo "<script type='text/javascript'>  click_dblclick(\"".$cfg_menu_elem["id_div_element"]."\", \"".$clickBlock."\", \"".$dblclickBlock."\");  </script>";
	}

	////	ICONE D'UTILISATEUR SI L'ELEMENT EST PERSONNEL
	////
	if($_SESSION["user"]["id_utilisateur"]>0 && $icone_element_individuel==true && $objet_independant==true && !isset($cfg_menu_elem["taille_icone"]))
		echo "<br><img src=\"".PATH_TPL."module_utilisateurs/acces_utilisateur.png\" style='width:13px;' ".infobulle($trad["acces_perso"])." />";

echo "</div>";
?>