<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",false);
require "commun.inc.php";
require_once PATH_INC."header.inc.php";
init_editeur_tinymce();
$affichage_destinataire = db_valeur("SELECT affichage_destinataire FROM gt_messagerie WHERE id_message='".$_GET["id_message"]."'");	
$destinataires = db_tableau("SELECT * from gt_jointure_messagerie_utilisateur WHERE id_message='".$_GET["id_message"]."' order by utilisateur");
		
//// Fonctions javascript
////
require "fonctions.php";

if(isset($_GET["id_message"]))
{
	$messagerie_tmp = objet_infos($objet["messagerie"], $_GET["id_message"]);
}

//// Repondre au message 
if(isset($_POST["repondre2"]))
{
   $id_destinataire = $messagerie_tmp["id_expediteur"];
   db_query("INSERT INTO gt_messagerie SET id_expediteur='".$_SESSION["user"]["id_utilisateur"]."', expediteur='".$_SESSION["user"]["nom"]."', titre=".db_format($_POST["titre"]).", description=".db_format($_POST["description"],"editeur").", date=NOW()");
	$id_message= db_last_id();

	if (isset($_POST["affichage_destinataire"]))
    {
    db_query("UPDATE gt_messagerie SET affichage_destinataire=1 where id_expediteur='".$_SESSION["user"]["id_utilisateur"]."' and id_message='".$id_message."'");
    }
	
	$utilisateur= db_valeur("SELECT nom from gt_utilisateur WHERE id_utilisateur = '".$id_destinataire."'");
	db_query("INSERT INTO gt_jointure_messagerie_utilisateur SET id_message='".$id_message."', utilisateur='".$utilisateur."', id_utilisateur= '".$id_destinataire."', id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");

	$premier_destinataire = db_valeur("SELECT utilisateur from gt_jointure_messagerie_utilisateur where id_message='".$id_message."' order by utilisateur");
	db_query("UPDATE gt_messagerie SET premier_destinataire='".$premier_destinataire."' WHERE id_message = '".$id_message."' ");
	
	////	AJOUTER FICHIERS JOINTS
	affecter_droits_acces($objet["messagerie"],$id_message);
	ajouter_fichiers_joint($objet["messagerie"],$id_message);
		
	redir_popupLightbox("index.php?cible=envoi&tri=<?php echo ".$trad["MESSAGERIE_date"].";?>");
}

//// Repondre tous
if(isset($_POST["repondre4"]))
{
   //// Enregistrement du message dans gt_messagerie
   db_query("INSERT INTO gt_messagerie SET id_expediteur='".$_SESSION["user"]["id_utilisateur"]."', expediteur='".$_SESSION["user"]["nom"]."', titre=".db_format($_POST["titre"]).", description=".db_format($_POST["description"],"editeur").", date=NOW()");
	$id_message= db_last_id();
	
	//// Autorise l'affichage des destinataires
   if (isset($_POST["affichage_destinataire"]))
    {
    db_query("UPDATE gt_messagerie SET affichage_destinataire=1 where id_expediteur='".$_SESSION["user"]["id_utilisateur"]."' and id_message='".$id_message."'");
    }
		
	//// Enregistrement du message pour les destinataires dans gt_jointure_messagerie_utilisateur
	$destinataires = db_tableau("SELECT * from gt_jointure_messagerie_utilisateur WHERE id_message='".$_GET["id_message"]."' and id_utilisateur != ".$_SESSION["user"]["id_utilisateur"]."");
	foreach ($destinataires as $id_destinataires)
	{
	$utilisateur= db_valeur("SELECT nom from gt_utilisateur WHERE id_utilisateur = '".$id_destinataires["id_utilisateur"]."'");
	db_query("INSERT INTO gt_jointure_messagerie_utilisateur SET id_message='".$id_message."', utilisateur='".$utilisateur."', id_utilisateur= '".$id_destinataires["id_utilisateur"]."', id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");
	
	$premier_destinataire = db_valeur("SELECT utilisateur from gt_jointure_messagerie_utilisateur where id_message='".$id_message."' order by utilisateur");
	db_query("UPDATE gt_messagerie SET premier_destinataire='".$premier_destinataire."' WHERE id_message = '".$id_message."' ");
	
	////	AJOUTER FICHIERS JOINTS
	affecter_droits_acces($objet["messagerie"],$id_message);
	ajouter_fichiers_joint($objet["messagerie"],$id_message);
	}
	
	//// Enregistrement du message pour l'expediteur dans gt_jointure_messagerie_utilisateur
   $id_destinataire = $messagerie_tmp["id_expediteur"];
	$utilisateur= db_valeur("SELECT nom from gt_utilisateur WHERE id_utilisateur = '".$id_destinataire."'");
	db_query("INSERT INTO gt_jointure_messagerie_utilisateur SET id_message='".$id_message."', utilisateur='".$utilisateur."', id_utilisateur= '".$id_destinataire."', id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");

	////	AJOUTER FICHIERS JOINTS
	affecter_droits_acces($objet["messagerie"],$id_message);
	ajouter_fichiers_joint($objet["messagerie"],$id_message);
		
	redir_popupLightbox("index.php?cible=envoi&tri=<?php echo ".$trad["MESSAGERIE_date"].";?>");
}


$nb_fichiers_max=10;

/// Marquer Lu
if(isset($_GET["lu"]) && $_GET["lu"]=="ok")
{
db_query("update gt_jointure_messagerie_utilisateur set lu='1', datelu=NOW(), rappel ='0' where id_message='".$_GET["id_message"]."' and id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."'");
}

////	AFFICHE FICHIERS JOINTS ($affichage = popup  /  menu_element  /  normal)
////
function aff_fichiers_joints($obj_tmp, $id_objet, $affichage)
{
	global $trad;	
	$liste_fichiers_transfert = db_tableau("SELECT * FROM gt_transfert_id_fichier_messagerie WHERE id_message='".$_GET["id_message"]."' ");	
	$liste_fichiers_joint = db_tableau("SELECT * FROM gt_jointure_objet_fichier WHERE type_objet='".$obj_tmp["type_objet"]."' AND id_objet='".$id_objet."' ");
	
	if((count($liste_fichiers_transfert)>0) || (count($liste_fichiers_joint)>0))
	{
	$retour_ligne = ($affichage=="menu_element")  ?  "<br />"  :  "";
	if($affichage=="popup")		{ echo "<br /><div style=\"width:97%;text-align:center;".$_SESSION["skin"]["fond_opaque"]."\"><hr />"; }
		else						{ echo "<hr style=\"margin-top:15px\" />"; }
			
	//// Fichiers transférés
	if(count($liste_fichiers_transfert)>0)
	{
		foreach($liste_fichiers_transfert as $fichier_joint_tmp)	
		{ echo "<span onclick=\"redir('fichier_joint_telecharger.php?id_fichier=".$fichier_joint_tmp["id_fichier_origine"]."');\" class=\"lien\" ".infobulle($trad["MESSAGERIE_telecharger"])."><img src=\"".PATH_TPL."divers/telecharger.png\" /> ".$fichier_joint_tmp["nom_fichier"]."</span> &nbsp;".$retour_ligne; }
	}

	//// Fichiers joints
	if(count($liste_fichiers_joint)>0)
	{
		foreach($liste_fichiers_joint as $fichier_joint_tmp)	{ echo "<span onclick=\"redir('fichier_joint_telecharger.php?id_fichier=".$fichier_joint_tmp["id_fichier"]."');\" class=\"lien\" ".infobulle($trad["MESSAGERIE_telecharger"])."><img src=\"".PATH_TPL."divers/telecharger.png\" /> ".$fichier_joint_tmp["nom_fichier"]."</span> &nbsp;".$retour_ligne; }
	}
	
	if($affichage=="popup")		echo "</div>";
	}
}
?>

<style type="text/css">
body		{ background-image:url(<?php echo PATH_TPL; ?>module_messagerie/fond_popup.png);width:900px;margin:auto;}
.tab_user	{ width:100%; border-spacing:3px; font-weight:bold; }
.lib_user	{ width:150px; font-weight:normal;}
</style>
<fieldset class="fieldset_titre" style='width:98%'><?php echo $trad["MESSAGERIE_titre_message_reception"]; ?></fieldset>
<?php
if ((!isset($_POST["repondre1"])) && (!isset($_POST["repondre3"]))){
?>
<div style="margin:auto;width:900px;">
<table style="width:100%;" cellpadding="3px" cellspacing="0px" >
<table style="width:100%;height:100px;border-spacing:8px;"><tr>
	
	<td style="text-align:left;vertical-align:middle;">
		<table class="tab_user">
		
<?php
		////	MESSAGE
		////
		echo "<div style=\"font-size:18px;margin-bottom:10px;\"><u><b>".$trad["MESSAGERIE_objet"]."</b></u> : ".$messagerie_tmp["titre"]."</div>";
		$expediteur=db_ligne("select * from gt_utilisateur where id_utilisateur=".$messagerie_tmp["id_expediteur"]);
		echo "<div style=\"font-size:12px;margin-bottom:10px;\"><u><b>".$trad["MESSAGERIE_de"]."</b></u> : ".$expediteur["prenom"]." ".$expediteur["nom"]."</div>";
		echo "<div style=\"font-size:12px;margin-bottom:10px;\"><u><b>".$trad["MESSAGERIE_date_envoi"]."</b></u> : ".versDateHeureFR($messagerie_tmp["date"])."</div>";
		
		if (($affichage_destinataire) && (count($destinataires) >0))
		{
		echo "<div style=\"font-size:12px;margin-bottom:10px;\"><u><b>".$trad["MESSAGERIE_destinataire"]."</b></u> : ";
		foreach ($destinataires as $id_destinataires)
		{
		$info_destinataires = db_ligne ("select * from gt_utilisateur where id_utilisateur = '".$id_destinataires["id_utilisateur"]."'");
		{echo "".$info_destinataires["nom"]." ".$info_destinataires["prenom"].", ";}	
		}	
		echo "</div>";
		}
				
		echo "<div class=\"content\" style=\"padding:12px;padding-top:10px;width:95%;\"><b><u>".$trad["MESSAGERIE_message"].";</u></b>".$messagerie_tmp["description"]."";
		echo "<p style=\"margin-left:810px;\" class=\"lien\" onclick=\"window.print();\"><img style=\"padding-right:5px;\" src=\"".PATH_TPL."module_messagerie/imprimer.png\" /></p>";
		echo "</div>";
		echo "<br /><br />";
		
?>		
		<div class="lien" style="width:100px;vertical-align:middle;" onclick="close_popupLightbox();"><img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/retour.png" /><?php echo $trad["MESSAGERIE_retour"]; ?></div>
		<div class="lien" style="width:100px;margin-left:400px;margin-top:-25px;vertical-align:middle;" <?php echo "onclick=\"redir('elements_trait.php?id_message=".$messagerie_tmp["id_message"]."&source=reception&type=archiver&tri=".$_GET["tri"]."');\";" ?> ><img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/archive.png" /><?php echo $trad["MESSAGERIE_archiver"]; ?></div>
		<div class="lien" style="width:100px;margin-left:800px;margin-top:-25px;vertical-align:middle;" <?php echo "onclick=\"redir('elements_trait.php?id_message=".$messagerie_tmp["id_message"]."&source=reception&type=corbeille&tri=".$_GET["tri"]."');\";" ?> ><img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/supprime.png" /><?php echo $trad["MESSAGERIE_supprimer"]; ?></div>
<?php

		////	Fichiers joints + footer
		aff_fichiers_joints($objet["messagerie"], $_GET["id_message"], "popup");
?>
		</table>
	</td>
</tr></table>

</table></div>

<div style="text-align:center;margin-top:20px;">
		<form method="post" style="padding:10px" >
		<input type="submit" class="button" name="repondre1" value="<?php echo $trad["MESSAGERIE_repondre"]; ?>" style="width:120px;margin-right:40px;"/>		
		<?php
		if (($affichage_destinataire) && (count($destinataires) >0))
		{?>
		<input type="submit" class="button" name="repondre3" value="<?php echo $trad["MESSAGERIE_repondre_tous"]; ?>" style="width:120px;margin-right:40px;"/>		
      <?php } ?>
      <input type="button" class="button" name="transfert" value="<?php echo $trad["MESSAGERIE_transferer"]; ?>" style="width:120px;" onclick="redir_popupLightbox('transfert_edit.php?id_message=<?php echo $_GET["id_message"]; ?>');"/>			
		</form>
		</div>
<?php
}
else 
{
?>

<form method="POST" id="form_mail" enctype="multipart/form-data" OnSubmit="return controle_formulaire_reception();">
	<table><tr>
		<td>
				
				<div class="content" style="width:870px;">
				<div class="lien" style="width:100px;vertical-align:middle;" onclick="close_popupLightbox();" ><img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/retour.png" /><?php echo $trad["MESSAGERIE_retour"]; ?></div>
				<div class="lien" style="width:100px;margin-left:390px;margin-top:-25px;vertical-align:middle;" <?php echo "onclick=\"redir('elements_trait.php?id_message=".$messagerie_tmp["id_message"]."&source=reception&type=archiver&tri=".$_GET["tri"]."');\";" ?> ><img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/archive.png" /><?php echo $trad["MESSAGERIE_archiver"]; ?></div>
				<div class="lien" style="width:100px;margin-left:770px;margin-top:-25px;vertical-align:middle;" <?php echo "onclick=\"redir('elements_trait.php?id_message=".$messagerie_tmp["id_message"]."&source=reception&type=corbeille&tri=".$_GET["tri"]."');\";" ?> ><img style="padding-right:5px;" src="<?php echo PATH_TPL; ?>module_messagerie/supprime.png" /><?php echo $trad["MESSAGERIE_supprimer"]; ?></div>
				  <hr>
				<?php
				if (isset($_POST["repondre3"]))
				{
				?>
				<p class="lien" style="color:red;text-align:left;" onclick="select_checkbox_destinataires();">
				<input name="affichage_destinataire[]" type="checkbox" style="margin-right:5px;margin-top:-1px;" /><?php echo $trad["MESSAGERIE_affichage_destinataire"];?>
				</p>
				<br />
				<?php
				}
				?>
				<p style="text-align:left;">
				<input type="text" name="titre" value="<?php echo 'Re : ',$messagerie_tmp["titre"]; ?>" id="titre" style="width:90%;margin-bottom:10px;" onFocus="if(this.value=='<?php echo $trad["MESSAGERIE_titre"]; ?>') this.value='';" />
				<div class="form_libelle">
				<textarea name="description" id="description" style="width:100%;height:250px;"><?php echo $messagerie_tmp["description"]; ?><hr><br></textarea>
				</div>
				
				<table style="width:100%;margin-top:10px;">
					
					<tr>
						<td>
							<?php
echo "<div id=\"menu_edit_objet_options\" style=\"margin-top:20px;margin-bottom:20px;float:left;\" onselectstart=\"return false;\">";

////	FICHIERS JOINTS
	////
	$cfg_menu_edit = array("objet"=>$objet["messagerie"], "id_objet"=>@$faq_tmp["id_message"]);
	$block_fichiers_joints = "";

	////	Bouton principal
		echo "<img src=\"".PATH_TPL."divers/fichier_joint.png\" />&nbsp;<span onclick=\"afficher('div_fichiers_joints','bascule','block');redir('#bottom_fichier');\" class=\"lien\">".$trad["MESSAGERIE_fichier_joint"]."</span>";
		////	Menu
		$text_max_filesize = $trad["MESSAGERIE_limite_chaque_fichier"]." ".afficher_taille(return_bytes(ini_get("upload_max_filesize")));
		$fichiers_joints = db_tableau("SELECT * FROM gt_jointure_objet_fichier WHERE type_objet='".$cfg_menu_edit["objet"]["type_objet"]."' AND id_objet='".$cfg_menu_edit["id_objet"]."' ORDER BY nom_fichier");
		$block_fichiers_joints .= "<div id=\"div_fichiers_joints\" class=\"div_options\" style=\"float:left;".((count($fichiers_joints)>0)?"display:block;":"")."\" >";
		////	Inputs d'ajout de fichiers + ajoute dans le textarea (si possible)
		for($i=1; $i<=10; $i++){
			$block_fichiers_joints .= "<div id=\"div_fichier_joint".$i."\"  ".(($i>1)?"class=\"cacher\"":"")."><input type=\"file\" name=\"add_fichier_joint".$i."\" onChange=\"affiche_fichiers(".$i.");\" title=\"".$text_max_filesize."\" /> &nbsp; ";
			$block_fichiers_joints .= "<span id=\"txt_add_fichier_joint".$i."\" onClick=\"check_txt_box(this.id,'add_fichier_joint".$i."');\" title=\"".$trad["MESSAGERIE_inserer_fichier_info"]."\" class=\"lien\" style=\"display:none;\"><img src=\"".PATH_TPL."divers/fleche_droite.png\" /> ".$trad["MESSAGERIE_inserer_fichier"]." <img src=\"".PATH_TPL."divers/message_insert.png\" /></span><input type=\"checkbox\" name=\"tab_add_fichier_joint[]\" value=\"add_fichier_joint".$i."\" id=\"box_add_fichier_joint".$i."\" style=\"visibility:hidden;\" /></div>";
		}

////	AFFICHAGE DES BLOCKS HIDDEN "NOTIFICATION PAR MAIL" + "FICHIERS JOINTS"  &  FIN DES OPTIONS
echo "<hr style=\"visibility:hidden;\" />".$block_fichiers_joints;
echo "</div>";
?>
						</td>
					</tr>
					<tr><td colspan="2" style="text-align:center;margin-top:20px;">
					<?php
					if (($affichage_destinataire) && (count($destinataires) >0) && (!isset($_POST["repondre1"])))
					{?>
					<input type="submit" style="width:120px;" class="button" name="repondre4" value="<?php echo $trad["MESSAGERIE_repondre_tous"]; ?>"/>
					<?php } else { ?>
					<input type="submit" class="button" name="repondre2" value="<?php echo $trad["MESSAGERIE_repondre"]; ?>" style="width:100px;"/>
					<?php } ?>
					</td></tr>
				</table>
			</div>
		</td>
	</tr>
</table></form>
<?php
}
require_once PATH_INC."footer.inc.php";
?>
