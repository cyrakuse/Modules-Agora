<?php
////	INITIALISATION
////
require "commun.inc.php";

////  Bouton Vider la corbeille
////
if (isset($_GET["type"]) && $_GET["type"]=="vider")
	{	
	  db_query("update gt_jointure_messagerie_utilisateur set supprime_reception='2' where id_utilisateur = '".$_SESSION["user"]["id_utilisateur"]."' and supprime_reception='1'");
	  db_query("update gt_messagerie set supprime_envoi='2' where id_expediteur='".$_SESSION["user"]["id_utilisateur"]."' and supprime_envoi='1'");
	  If (($_GET["cible"]) == "archives")
	  {
	    redir('index.php?cible=archives&id_dossier=1&tri='.$_GET["tri"].'');
	  }
	  else
	  {
	    redir('index.php?cible='.$_GET["cible"].'&tri='.$_GET["tri"].'');
	  }
	}
	
/////  Actions sur les messages : supprimer, archiver, restaurer
////
if (isset($_GET["id_message"]) && isset($_GET["type"]))
{
		$id_message = $_GET["id_message"];
		$nb = 0;
		$nb = db_valeur("SELECT * FROM gt_messagerie where id_message='".$id_message."' and id_expediteur='".$_SESSION["user"]["id_utilisateur"]."'");
		
	if (($_GET["type"]=="corbeille") && ($_GET["source"]=="reception") )
	{
		db_query("update gt_jointure_messagerie_utilisateur set supprime_reception='1' where id_message='".$_GET["id_message"]."' and id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."'");
		redir_popupLightbox('index.php?cible=reception&tri='.$_GET["tri"].'');
	}
	
	if ($_GET["type"]=="corbeille" && ($_GET["source"]=="envoi")  )
	{
		db_query("update gt_messagerie set supprime_envoi='1' where id_message='".$_GET["id_message"]."'");
		redir_popupLightbox('index.php?cible=envoi&tri='.$_GET["tri"].'');
	}
	
	if ($_GET["type"]=="definitif" && ($_GET["source"]=="corbeille")  )
	{ 
      if ($nb)
		{
			db_query("update gt_messagerie set supprime_envoi='2' where id_message='".$_GET["id_message"]."'");
		}
		else
		{
			db_query("update gt_jointure_messagerie_utilisateur set supprime_reception='2' where id_utilisateur = '".$_SESSION["user"]["id_utilisateur"]."' and id_message='".$_GET["id_message"]."'");
		}	
		redir_popupLightbox('index.php?cible=corbeille&tri='.$_GET["tri"].'');
	}
		
	if ($_GET["type"]=="corbeille" && ($_GET["source"]=="archives")  )
	{ 
      if ($nb)
		{
			db_query("update gt_messagerie set supprime_envoi='1', id_dossier='1' where id_message='".$_GET["id_message"]."'");
		}
		else
		{
			db_query("update gt_jointure_messagerie_utilisateur set supprime_reception='1', id_dossier='1' where id_utilisateur = '".$_SESSION["user"]["id_utilisateur"]."' and id_message='".$_GET["id_message"]."'");
		}	
		redir_popupLightbox('index.php?cible=archives&tri='.$_GET["tri"].'');
		}
		
	if (($_GET["type"]=="restaurer"))
	{
		if ($nb)
		{
			db_query("update gt_messagerie set supprime_envoi='0' where id_message='".$_GET["id_message"]."'");
			redir_popupLightbox('index.php?cible=envoi&tri='.$_GET["tri"].'');	
		}
		else
		{
			db_query("update gt_jointure_messagerie_utilisateur set supprime_reception='0' where id_utilisateur = '".$_SESSION["user"]["id_utilisateur"]."' and id_message='".$_GET["id_message"]."'");
			redir_popupLightbox('index.php?cible=reception&tri='.$_GET["tri"].'');	
		}
	}
		
	if (($_GET["type"]=="archiver") )
	{
	if ($nb)
		{
			db_query("update gt_messagerie set supprime_envoi='3' where id_message='".$_GET["id_message"]."'");
			redir_popupLightbox('index.php?cible=envoi&tri='.$_GET["tri"].'');	
		}
		else
		{
			db_query("update gt_jointure_messagerie_utilisateur set supprime_reception='3' where id_utilisateur = '".$_SESSION["user"]["id_utilisateur"]."' and id_message='".$_GET["id_message"]."'");
			redir_popupLightbox('index.php?cible=reception&tri='.$_GET["tri"].'');	
		}
	
	}
}
else
{
redir_popupLightbox('index.php?cible=reception&tri='.$_GET["tri"].'');
}
?>