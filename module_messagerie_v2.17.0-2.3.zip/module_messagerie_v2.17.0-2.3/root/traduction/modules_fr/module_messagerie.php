<?php
///  Menu principal
$trad["MESSAGERIE_nom_module"] = "Messagerie interne";
$trad["MESSAGERIE_nom_module_header"] = "Messagerie";
$trad["MESSAGERIE_description_module"] = "Messagerie interne";

///  Messagerie sur tableau de bord
$trad["MESSAGERIE_utilisateur(s)"] = " utilisateur(s) :";
$trad["MESSAGERIE_vous_avez"] = " Vous avez ";
$trad["MESSAGERIE_vous_rappelle"] = "vous rappelle que";
$trad["MESSAGERIE_vous_rappellent"] = "vous rappellent que";
$trad["MESSAGERIE_message(s)"] = " message(s)";

///  Index.php
$trad["MESSAGERIE_boite_reception"]= "Boite de réception";
$trad["MESSAGERIE_boite_envoi"]= "Messages envoyés";
$trad["MESSAGERIE_corbeille"]="Corbeille";
$trad["MESSAGERIE_ecrire_message"]="Ecrire un nouveau message";
$trad["MESSAGERIE_lu"]="Ce message a déjà été lu";
$trad["MESSAGERIE_nonlu"]="Ce message n'a pas encore été lu";
$trad["MESSAGERIE_envoye"]= "Message(s) envoyé(s)";
$trad["MESSAGERIE_reçu"] = "Message(s) reçu(s)";
$trad["MESSAGERIE_aucun_message"]=" Aucun message pour le moment";
$trad["MESSAGERIE_suppression_corbeille"]="Vous avez plus de 5 messages dans la corbeille. Merci de la vider !";
$trad["MESSAGERIE_retour"]= "Retour";
$trad["MESSAGERIE_lecteur"]= "Lecteur(s) du message";
$trad["MESSAGERIE_supprimer"]= "Supprimer";
$trad["MESSAGERIE_restaure"]= "Restaurer";
$trad["MESSAGERIE_marquer_non_lu"]= "Marquer non lu";
$trad["MESSAGERIE_objet"] = "Objet";
$trad["MESSAGERIE_vider"]= "Vider";
$trad["MESSAGERIE_archiver"]= "Archiver";
$trad["MESSAGERIE_archives"] = "Archives";
$trad["MESSAGERIE_trier_par"] ="Trier par : ";
$trad["MESSAGERIE_trier"]= "Ok";
$trad["MESSAGERIE_Checkbox_message"]= "Cochez au moins un message !";
$trad["MESSAGERIE_rappel_non_lu"]= "Rappel : ce message n'a pas encore été lu !";
$trad["MESSAGERIE_rappel_envoi"]= "Nombre de rappel(s) en cours";
$trad["MESSAGERIE_pas_de_rappel"]= "Pas de rappel";
$trad["MESSAGERIE_brouillons"] = "Brouillons";
$trad["MESSAGERIE_fichier"] = "Nombre de fichier(s) joint(s)";
$trad["MESSAGERIE_maintenance"] = "Outils de maintenance";
$trad["MESSAGERIE_nettoyage"] = "Nettoyer la base sql";
$trad["MESSAGERIE_alerte_sonore"] = "Alerte sonore : ";
$trad["MESSAGERIE_Off"] = "Off";
$trad["MESSAGERIE_On"] = "On";
$trad["MESSAGERIE_modifier"] = "Modifier";
$trad["MESSAGERIE_parametres"] = "Paramètres avancés";
$trad["MESSAGERIE_delai"] = "Délai (300s = 5min) : ";
$trad["MESSAGERIE_nouveau_delai"] = "Nouveau délai (s) : ";
$trad["MESSAGERIE_specifier_delai"] = "Saisir un délai correct !";
$trad["MESSAGERIE_alerte_delai"] = "Un délai trop faible peut ralentir Agora.";


///   inputs_trait.php
$trad["MESSAGERIE_date"] = "date";
$trad["MESSAGERIE_expediteur"] = "expéditeur";
$trad["MESSAGERIE_objet_tri"] = "objet";
$trad["MESSAGERIE_premier_destinataire"] = "destinataire";


/// message_reception.php & message_edit.php & brouillon_edit.php & tranfert_edit.php
$trad["MESSAGERIE_titre_message_reception"]= "Message reçu";
$trad["MESSAGERIE_repondre"] = "Répondre";
$trad["MESSAGERIE_repondre_tous"] = "Répondre à tous";
$trad["MESSAGERIE_transferer"] = "Transférer";
$trad["MESSAGERIE_telecharger"] = "Télécharger";
$trad["MESSAGERIE_specifier_titre"] = "Merci de spécifier un titre !";
$trad["MESSAGERIE_confirmer_suppr"] = "Confirmer la suppression ?";
$trad["MESSAGERIE_inverser_selection"] = "Sélectionner tous";
$trad["MESSAGERIE_fichier_joint"] = "Ajouter des fichiers : photo, video, etc ...";
$trad["MESSAGERIE_limite_chaque_fichier"] = "Les fichiers ne doivent pas dépasser"; // ...2 Mega Octets
$trad["MESSAGERIE_inserer_fichier_info"] = "Afficher l'image / video / Lecteur Mp3... dans la description ci-dessus";
$trad["MESSAGERIE_inserer_fichier"] = "Afficher dans la description";
$trad["MESSAGERIE_supprimer"] = "Supprimer";
$trad["MESSAGERIE_imprimer"] = "Imprimer";
$trad["MESSAGERIE_envoyer"] = "Envoyer";
$trad["MESSAGERIE_envoyer_brouillon"] = "Brouillon";
$trad["MESSAGERIE_controle_form_envoi1"] = "Confirmez l'envoi du message à ";
$trad["MESSAGERIE_controle_form_envoi2"] = " destinataire(s) ?";
$trad["MESSAGERIE_fichier_a_joindre"] = "Fichier(s) joint(s)";
$trad["MESSAGERIE_groupes"] = "Groupe(s) d'utilisateurs";
$trad["MESSAGERIE_utilisateurs"] = "Liste des utilisateurs";


/// message_envoi.php
$trad["MESSAGERIE_titre_message_envoi"]= "Message envoyé";
$trad["MESSAGERIE_titre"] = "Titre du message";
$trad["MESSAGERIE_message"] = "Message ";
$trad["MESSAGERIE_description"] = "Corps du message";
$trad["MESSAGERIE_de"] = "De";
$trad["MESSAGERIE_date_envoi"] = "Envoyé le";
$trad["MESSAGERIE_specifier_mail"] = "Merci de specifier au moins un contact !";
$trad["MESSAGERIE_date_heure_lecture"] = "Date et heure de lecture";
$trad["MESSAGERIE_date_heure_rappel"] = "Date et heure du rappel";
$trad["MESSAGERIE_rappel"] = "Rappel";
$trad["MESSAGERIE_envoi_rappel"] = "Envoyé le(s) rappel(s)";

/// message_corbeille.php
$trad["MESSAGERIE_titre_message_corbeille"]= "Message supprimé";

/// message_archives.php
$trad["MESSAGERIE_titre_message_archives"]= "Message archivé";

/// message_edit.php && transfert_edit
$trad["MESSAGERIE_destinataire"]="Destinataire(s)";
$trad["MESSAGERIE_affichage_destinataire"] = "Autoriser l'affichage de tous les destinataires dans le message";
$trad["MESSAGERIE_joindre"]="Joindre";
$trad["MESSAGERIE_fichier_a_transferer"] = "Fichier(s) à transférer";

/// Nettoyage_message.php
$trad["MESSAGERIE_confirmer_nettoyage"] = "Confirmez vous le nettoyage des anciens messages ?";
$trad["MESSAGERIE_fin_nettoyage"] = "Nettoyage OK !";

/// Elements_menu_selection.inc.php
$trad["MESSAGERIE_selection_dossier"] = "Sélectionner tous les dossiers";



?>
