<?php
///  Menu principal
$trad["MESSAGERIE_nom_module"] = "Local messages";
$trad["MESSAGERIE_nom_module_header"] = "Mail";
$trad["MESSAGERIE_description_module"] = "Local messages";

///  Messagerie sur tableau de bord
$trad["MESSAGERIE_utilisateur(s)"] = " user(s) :";
$trad["MESSAGERIE_vous_avez"] = " You have ";
$trad["MESSAGERIE_vous_rappelle"] = "reminds you that";
$trad["MESSAGERIE_vous_rappellent"] = "remind you that";
$trad["MESSAGERIE_message(s)"] = " message(s)";

///  Index.php
$trad["MESSAGERIE_boite_reception"]= "Inbox";
$trad["MESSAGERIE_boite_envoi"]= "Sent messages";
$trad["MESSAGERIE_corbeille"]="Bin";
$trad["MESSAGERIE_ecrire_message"]="Write a new message";
$trad["MESSAGERIE_lu"]="This message has already been read";
$trad["MESSAGERIE_nonlu"]="This message has not been read yet";
$trad["MESSAGERIE_envoye"]= "Message(s) sent";
$trad["MESSAGERIE_reçu"] = "New message(s)";
$trad["MESSAGERIE_aucun_message"]=" No new message";
$trad["MESSAGERIE_suppression_corbeille"]="You have more than 5 messages in the bin. Please empty the bin !";
$trad["MESSAGERIE_retour"]= "Back";
$trad["MESSAGERIE_lecteur"]= "Message read by";
$trad["MESSAGERIE_supprimer"]= " Delete";
$trad["MESSAGERIE_restaure"]= "Restore";
$trad["MESSAGERIE_marquer_non_lu"]= "Mark as unread";
$trad["MESSAGERIE_objet"] = "Object";
$trad["MESSAGERIE_vider"]= "Empty";
$trad["MESSAGERIE_archiver"]= "Archive";
$trad["MESSAGERIE_archives"] = "Archives";
$trad["MESSAGERIE_trier_par"] ="Order by : ";
$trad["MESSAGERIE_trier"]= "Ok";
$trad["MESSAGERIE_Checkbox_message"]= "Select one message !";
$trad["MESSAGERIE_rappel_non_lu"]= "Reminder : This message has not been read yet !";
$trad["MESSAGERIE_rappel_envoi"]= "Number of reminder(s) send";
$trad["MESSAGERIE_pas_de_rappel"]= "No reminder";
$trad["MESSAGERIE_brouillons"] = "Drafts";
$trad["MESSAGERIE_fichier"] = "Number of join(s) file(s)";
$trad["MESSAGERIE_nettoyage"] = "Clean the sql table";
$trad["MESSAGERIE_alerte_sonore"] = "Sound Alert";
$trad["MESSAGERIE_Off"] = "Off";
$trad["MESSAGERIE_On"] = "On";
$trad["MESSAGERIE_modifier"] = "Apply";
$trad["MESSAGERIE_parametres"] = "Admin settings";
$trad["MESSAGERIE_delai"] = "Delai (300s = 5min) : ";
$trad["MESSAGERIE_nouveau_delai"] = "New delai (s) : ";
$trad["MESSAGERIE_specifier_delai"] = "Enter a correct delai !";
$trad["MESSAGERIE_alerte_delai"] = "Un shorter delai may be slowly Agora.";
$trad["MESSAGERIE_groupes"] = "Groups of users";
$trad["MESSAGERIE_utilisateurs"] = "All users";



///   inputs_trait.php
$trad["MESSAGERIE_date"] = "date";
$trad["MESSAGERIE_expediteur"] = "sender";
$trad["MESSAGERIE_objet_tri"] = "object";
$trad["MESSAGERIE_premier_destinataire"] = "recipient";



/// message_reception.php & message_edit.php & brouillon_edit.php & tranfert_edit.php
$trad["MESSAGERIE_titre_message_reception"]= "Received message";
$trad["MESSAGERIE_repondre"] = "Reply";
$trad["MESSAGERIE_repondre_tous"] = "Reply to all";
$trad["MESSAGERIE_transferer"] = "Forward";
$trad["MESSAGERIE_telecharger"] = "Download";
$trad["MESSAGERIE_specifier_titre"] = "Please enter a title !";
$trad["MESSAGERIE_confirmer_suppr"] = "Would you like to delete ?";
$trad["MESSAGERIE_inverser_selection"] = "Check / Uncheck all";
$trad["MESSAGERIE_fichier_joint"] = "Upload files : picture, video ...";
$trad["MESSAGERIE_limite_chaque_fichier"] = "The size of file not exceed"; // ...2 Mega Octets
$trad["MESSAGERIE_inserer_fichier_info"] = "Show the picture / video / Mp3";
$trad["MESSAGERIE_inserer_fichier"] = "Show the description";
$trad["MESSAGERIE_supprimer"] = "Delete";
$trad["MESSAGERIE_envoyer"] = "Send";
$trad["MESSAGERIE_envoyer_brouillon"] = "Draft";
$trad["MESSAGERIE_controle_form_envoi1"] = "Send the message to ";
$trad["MESSAGERIE_controle_form_envoi2"] = " recipient(s) ?";




/// message_envoi.php
$trad["MESSAGERIE_titre_message_envoi"]= "Send message";
$trad["MESSAGERIE_titre"] = "Title";
$trad["MESSAGERIE_message"] = "Message ";
$trad["MESSAGERIE_description"] = "Contents";
$trad["MESSAGERIE_de"] = "From";
$trad["MESSAGERIE_date_envoi"] = "Sent on";
$trad["MESSAGERIE_specifier_mail"] = "Choose at least one contact !";
$trad["MESSAGERIE_date_heure_lecture"] = "Date and time of reading";
$trad["MESSAGERIE_date_heure_rappel"] = "Date and time of reminder";
$trad["MESSAGERIE_rappel"] = "Reminder";
$trad["MESSAGERIE_envoi_rappel"] = "Send reminder(s)";

/// message_corbeille.php
$trad["MESSAGERIE_titre_message_corbeille"]= "Deleted message";

/// message_archives.php
$trad["MESSAGERIE_titre_message_archives"]= "Archived message";

/// message_edit.php
$trad["MESSAGERIE_destinataire"]="Recipient(s)";
$trad["MESSAGERIE_affichage_destinataire"] = "Show all recipients in the message";
$trad["MESSAGERIE_joindre"]="Join";
$trad["MESSAGERIE_fichier_a_transferer"] = "File(s) to forward";

/// Nettoyage_message.php
$trad["MESSAGERIE_confirmer_nettoyage"] = "Would you like to clean the sql table ?";
$trad["MESSAGERIE_fin_nettoyage"] = "Cleaning OK !";

?>
