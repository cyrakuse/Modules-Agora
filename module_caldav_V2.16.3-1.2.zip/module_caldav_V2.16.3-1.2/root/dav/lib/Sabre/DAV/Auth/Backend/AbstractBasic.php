<?php

namespace Sabre\DAV\Auth\Backend;

use Sabre\DAV;
use Sabre\HTTP;

/**
 * HTTP Basic authentication backend class
 *
 * This class can be used by authentication objects wishing to use HTTP Basic
 * Most of the digest logic is handled, implementors just need to worry about
 * the validateUserPass method.
 *
 * @copyright Copyright (C) 2007-2013 Rooftop Solutions. All rights reserved.
 * @author James David Low (http://jameslow.com/)
 * @author Evert Pot (http://www.rooftopsolutions.nl/)
 * @license http://code.google.com/p/sabredav/wiki/License Modified BSD License
 *
 * Modified by Yov for Agora Project
 */
    //abstract class AbstractBasic implements BackendInterface {
    class AbstractBasic implements BackendInterface {

    /**
     * This variable holds the currently logged in username.
     *
     * @var string|null
     */
    protected $currentUser;

    /**
     * Returns information about the currently logged in username.
     *
     * If nobody is currently logged in, this method should return null.
     *
     * @return string|null
     */
    public function getCurrentUser() 
    {
        return $this->currentUser;
    }

    /**
     * Authenticates the Agora user based on the current request.
     *
     * If authentication is successful, true must be returned.
     * If authentication fails, an exception must be thrown.
     *
     * @param DAV\Server $server
     * @param string $realm
     * @throws DAV\Exception\NotAuthenticated
     * @return bool
     */
     public function authenticate(DAV\Server $server, $realm) 
     {

	$auth = new HTTP\BasicAuth();
        $auth->setHTTPRequest($server->httpRequest);
        $auth->setHTTPResponse($server->httpResponse);
        $auth->setRealm($realm);
        $userpass = $auth->getUserPass();
        if (!$userpass) {
            $auth->requireLogin();
            throw new DAV\Exception\NotAuthenticated('No basic authentication headers were found');
        }
        
         // Authenticates the user
	 $stmt = $this->pdo->prepare('SELECT identifiant, pass FROM gt_utilisateur WHERE identifiant = ?');
	 $stmt->execute(array($userpass[0]));
	 $result = $stmt->fetchAll();
	 
	 if (!count($result)) 
	 {
		$auth->requireLogin();
		throw new DAV\Exception\NotAuthenticated('Username or password does not match');
	 }
	 
	 if(count($result) > 0)
	 {	    
	      $sha1_pass = sha1_pass($userpass[1]);
	      // Authenticates the user with the upper login
	      $userpass_majuscules[0] = mb_strtoupper($userpass[0],'UTF-8');
	 
	      if(($userpass[0] == $result[0]['identifiant']) || ($userpass_majuscules[0] == $result[0]['identifiant']))
	      {
		    // AUTH HTTP
		    if($sha1_pass == $result[0]['pass'])
		    {
			$_SESSION["user"]  = db_ligne("SELECT * FROM gt_utilisateur WHERE identifiant ='".$result[0]['identifiant']."' ");
			$this->currentUser = $result[0]['identifiant'];
			return true;
		    }
		    // TOKEN CURL FOR AGORA
		    if($sha1_pass != $result[0]['pass'])
		    {
			$informations = $userpass[0].$result[0]['pass'];
			include "../module_agenda/token/cle.php";
			$token = sha1($informations.$Clecaldav);
	    
			if($token == $userpass[1])
			{
			  $_SESSION["user"]  = db_ligne("SELECT * FROM gt_utilisateur WHERE identifiant ='".$userpass[0]."' ");
			  $this->currentUser = $userpass[0];
			  return true;
			}
			else
			{
			    $auth->requireLogin();
			    throw new DAV\Exception\NotAuthenticated('Username or password does not match');
			}
		      }
	
	      }
	      else
	      {
		  $auth->requireLogin();
		  throw new DAV\Exception\NotAuthenticated('Username or password does not match');
	      }
	 }
      }
}