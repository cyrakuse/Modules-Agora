<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",false);
require "commun.inc.php";
require_once PATH_INC."header.inc.php";

if ((monagenda($_REQUEST['id_agenda'],$_SESSION['user']['id_utilisateur'])) == true)
{

//// VALIDATION DES DROITS
if (isset($_POST['valider']))
{
	// INIT
	$principal_id_read = "";
	$principal_id_write = "";
	$identifiant_user_tmp = "";
	$member_id = "";
	$id_agenda_caldav = $_POST['id_agenda'];
	$info_agenda = db_ligne("SELECT * FROM `gt_agenda` WHERE `id_utilisateur` =  '".$_SESSION['user']['id_utilisateur']."' AND `id_agenda`= '".$id_agenda_caldav."' ");
	
	if (($info_agenda['type']) == 'utilisateur')
	{
	    $principal_id_read = db_valeur("SELECT id from principals where uri='principals/".$_SESSION['user']['identifiant']."/calendar-proxy-read' ");
	    $principal_id_write = db_valeur("SELECT id from principals where uri='principals/".$_SESSION['user']['identifiant']."/calendar-proxy-write' ");
	}
	
	if (($info_agenda['type']) == 'ressource')
	{
	    $principal_id_read = db_valeur("SELECT id from principals where uri='principals/ressource".$info_agenda['id_agenda']."/calendar-proxy-read' ");
	    $principal_id_write = db_valeur("SELECT id from principals where uri='principals/principals/ressource".$info_agenda['id']."/calendar-proxy-write' ");
	}
	
	// SUPPRESSION DES ANCIENS DROITS
	db_query("DELETE FROM groupmembers WHERE principal_id = '".$principal_id_read."' ");
	$member_id = db_valeur("SELECT id from principals where uri='principals/".$_SESSION['user']['identifiant']."' ");
	db_query("DELETE FROM groupmembers WHERE principal_id = '".$principal_id_write."' AND member_id != '".$member_id."' ");
			
    // LECTURE
    if(isset($_POST['lecture_users']))
    {
		foreach (($_POST['lecture_users']) as  $id_user_tmp)
		{
			$identifiant_user_tmp = db_valeur("SELECT identifiant FROM gt_utilisateur WHERE id_utilisateur = '".$id_user_tmp."' ");
			$member_id = db_valeur("SELECT id from principals where uri='principals/".$identifiant_user_tmp."' ");
			$sql_lecture = db_query("INSERT INTO groupmembers SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_caldav."', principal_id = '".$principal_id_read."', member_id = '".$member_id."' ");
		}
    }
    
    // ECRITURE
    if(isset($_POST['ecriture_users']))
    {
		foreach (($_POST['ecriture_users']) as  $id_user_tmp)
		{
			$identifiant_user_tmp = db_valeur("SELECT identifiant FROM gt_utilisateur WHERE id_utilisateur = '".$id_user_tmp."' ");
			$member_id = db_valeur("SELECT id from principals where uri='principals/".$identifiant_user_tmp."' ");
			$sql_ecriture = db_query("INSERT INTO groupmembers SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_caldav."',  principal_id = '".$principal_id_write."', member_id = '".$member_id."' ");
		}
    }
reload_close();
}
?>
<style type="text/css">
.table_ligne			{ display:table; width:100%; }
.table_ligne:hover		{ background-color:<?php echo STYLE_TR_DESELECT; ?> }
.cellule_lib			{ display:table-cell; padding:0px; text-align:left;width:70%; }
.cellule_input			{ display:table-cell; padding:0px; text-align:center; width:87px; }
.cellule_input2			{ display:table-cell; padding:0px; text-align:center; width:130px; }
.objet_deselect			{ height:20px; padding-left:5px; cursor:pointer; font-weight:normal; }
.objet_lecture			{ height:20px; padding-left:5px; cursor:pointer; font-weight:bold; <?php echo STYLE_SELECT_YELLOW; ?> }
.objet_ecriture			{ height:20px; padding-left:5px; cursor:pointer; font-weight:bold; <?php echo STYLE_SELECT_RED; ?> }
.div_options			{ display:none; overflow:auto; margin:10px; margin-left:50px; padding:10px; max-height:200px; <?php echo STYLE_BLOCK; ?> }
.puce_point				{ width:15px; margin-right:5px; }
input[type=checkbox]	{ margin:1px; }
</style>

<script type="text/javascript">
////	Redimensionne
resize_iframe_popup(600,300);

////	ON MODIFIE LES DROITS ET LE STYLE DU TEXTE
////
function selection_affect(id, action)
{
	// RECUP LES ID DU TEXTE ET DES CHECKBOX  (lecture/écriture)
	id2 = id.replace("text_","").replace("lecture_","").replace("ecriture_limit_","").replace("ecriture_","");
	texte			= "text_"+id2;
	lecture			= "lecture_"+id2;
	ecriture_limit	= "ecriture_limit_"+id2;
	ecriture		= "ecriture_"+id2;

	// COMMANDE DEPUIS UN TEXTE
	if(trouver("text",id)==true)
	{
		// Lecture  (forcée OU rien de coché)
		if(element(lecture).disabled==false  &&  (action=="lecture" || (is_checked(lecture)==false && is_checked(ecriture_limit)==false && is_checked(ecriture)==false))) {
			set_check(lecture, true);
			set_check(ecriture_limit, false);
			set_check(ecriture, false);
		}
		// Ecriture limité  (forcée OU  ecriture limité décochée + ecriture décochée)
		else if(element(ecriture_limit).disabled==false  &&  (action=="ecriture_limit" || (is_checked(ecriture_limit)==false && is_checked(ecriture)==false))) {
			set_check(lecture, false);
			set_check(ecriture_limit, true);
			set_check(ecriture, false);
		}
		// Ecriture  (forcée OU ecriture décoché et lecture coché/désactivé  OU  force l'ecriture)
		else if(element(ecriture).disabled==false  &&  (action=="ecriture" || is_checked(ecriture)==false)) {
			set_check(lecture, false);
			set_check(ecriture_limit, false);
			set_check(ecriture, true);
		}
		// Aucun accès
		else {
			set_check(lecture, false);
			set_check(ecriture_limit, false);
			set_check(ecriture, false);
		}
	}
	// COMMANDE DEPUIS UNE CHECKBOX : DESACTIVE LES AUTRES BOX
	else
	{
		if(trouver("lecture",id))			{ set_check(ecriture_limit,false);  set_check(ecriture,false); }
		if(trouver("ecriture_limit",id))	{ set_check(lecture,false);  		set_check(ecriture,false); }
		else if(trouver("ecriture",id))		{ set_check(lecture,false);  		set_check(ecriture_limit,false); }
	}

	// ECRITURE LIMITE PAR DEFAUT : MESSAGE D'ALERTE SI ECRITURE SELECTIONNE
	<?php if($cfg_menu_edit["ecriture_limite_defaut"]==true){ ?>
	if(is_checked(ecriture) && element(ecriture_limit).disabled==false)  alert("<?php echo $trad["EDIT_OBJET_alert_ecriture_limite_defaut"]; ?>");
	<?php } ?>

	// ON MODIFIE LA COULEUR DU TEXTE
	if(is_checked(lecture))					element(texte).className="objet_lecture";
	else if(is_checked(ecriture_limit))		element(texte).className="objet_ecriture_limite";
	else if(is_checked(ecriture))			element(texte).className="objet_ecriture";
	else									element(texte).className="objet_deselect";
}

</script>

<?php
// ENTETE
echo "<div  class='content' style='margin-top:20px;'>";
echo "<div>";
echo "<br />";
echo "<div style='position:fixed;top:0px;left:0px;z-index:100000;width:100%;color:#000;font-weight:bold;font-size:13px;text-align:center;padding:7px;background-image:url(../templates/divers/popup_fond_titre.jpg);background-position:bottom left;'>";
echo "<b>".$trad["CALDAV_titre_popup"]."</b>";
echo "</div>";
echo "<div class='table_ligne' style='cursor:help;'>";
echo "<form action='caldav_config.php' method='post' enctype='multipart/form-data' name='form'>";
echo "<input type='hidden' name='id_agenda' value='".$_GET['id_agenda']."'>";
echo "<div class='cellule_lib'><b>".$trad["CALDAV_droit_acces"]."</b></div>";
echo "<div class='cellule_input' ".infobulle($trad["lecture_infos"]).">".$trad["lecture"]." <img src=\"".PATH_TPL."divers/oeil.png\" /></div>";
echo "<div class='cellule_input' ".infobulle($trad["ecriture_infos"]).">".$trad["ecriture"]." <img src=\"".PATH_TPL."divers/crayon.png\" /></div>";
echo "</div>";

$cpt_element = 0;
	
// AFFICHAGE UTILISATEURS ESPACE : STATUT CALDAV ACTIF ET DROITS ACCES AGENDA (LECTURE OU ECRITURE)
foreach(users_espace($_SESSION["espace"]["id_espace"],"tableau") as $user_tmp)
{
	// TOUS LES UTILISATEURS
	$droit_acces_tous_tmp = 0;
	$droit_acces_tous_tmp = db_valeur("SELECT droit FROM `gt_jointure_objet` WHERE type_objet= 'agenda' AND id_objet = '".$_GET['id_agenda']."' AND id_espace = '".$_SESSION["espace"]["id_espace"]."' AND target = 'tous' ");
	// UTILISATEUR TMP
	$droit_acces_user_tmp = 0;
	$droit_acces_user_tmp = db_valeur("SELECT droit FROM `gt_jointure_objet` WHERE type_objet= 'agenda' AND id_objet = '".$_GET['id_agenda']."' AND id_espace = '".$_SESSION["espace"]["id_espace"]."' AND target = 'U".$user_tmp['id_utilisateur']."' ");
	// GROUPES
	$droit_acces_groupe_tmp = 0;
	$info_droits_groupe_tmp = db_tableau("SELECT * FROM `gt_jointure_objet` WHERE type_objet= 'agenda' AND id_objet = '".$_GET['id_agenda']."' AND id_espace = '".$_SESSION["espace"]["id_espace"]."' AND target != 'U".$user_tmp['id_utilisateur']."' AND target != 'tous' ");
	foreach ($info_droits_groupe_tmp as $droit_groupe_tmp)
	{
	    $id_gpe_tmp = str_replace('G','',$droit_groupe_tmp['target']);
	    $id_utilisateurs = db_valeur("SELECT id_utilisateurs FROM `gt_utilisateur_groupe` WHERE id_groupe = '".$id_gpe_tmp."' ");
	    foreach (text2tab($id_utilisateurs) as $id_utilisateur_gpe)
	    {
		if ($id_utilisateur_gpe == $user_tmp['id_utilisateur'])
		{$droit_acces_groupe_tmp = $droit_groupe_tmp['droit'];}
	    }
	}
	
	// DROIT CALDAV USER
	$statut_tmp = 0;
	$statut_tmp = db_valeur("SELECT statut FROM gt_caldav_preferences WHERE id_utilisateur = '".$user_tmp['id_utilisateur']."' ");
	// AFFICHAGE
	$style_tmp = "objet_deselect";
	$check_1 = $check_2 = "";
	$test_acces_lecture = 0;
	$test_acces_ecriture = 0;
	$id_tmp = $user_tmp['id_utilisateur'];
	$icone_point = "divers/point_jaune.png";
	        
	if ($statut_tmp == 1)
	{
	    $icone_point = "module_agenda/caldav.png";
	    
	    $member_id = db_valeur("SELECT id from principals where uri='principals/".$user_tmp['identifiant']."' ");
	    $info_agenda = db_ligne("SELECT * FROM `gt_agenda` WHERE `id_utilisateur` =  '".$_SESSION['user']['id_utilisateur']."' AND `id_agenda`= '".$_GET['id_agenda']."' ");
	
	    if (($info_agenda['type']) == 'utilisateur')
	    {
		$principal_id_read = db_valeur("SELECT id from principals where uri='principals/".$_SESSION['user']['identifiant']."/calendar-proxy-read' ");
		$principal_id_write = db_valeur("SELECT id from principals where uri='principals/".$_SESSION['user']['identifiant']."/calendar-proxy-write' ");
	    }
	
	    if (($info_agenda['type']) == 'ressource')
	    {
		$principal_id_read = db_valeur("SELECT id from principals where uri = 'principals/ressource".$info_agenda['id_agenda']."/calendar-proxy-read' ");
		$principal_id_write = db_valeur("SELECT id from principals where uri = 'principals/ressource".$info_agenda['id_agenda']."/calendar-proxy-write' ");
	    }
	    
	    $test_acces_lecture = db_valeur("SELECT count(*) from groupmembers where principal_id = '".$principal_id_read."' AND member_id = '".$member_id."' ");
	    if ($test_acces_lecture >0)
	    {
		$style_tmp = "objet_lecture";
		$check_1 = "checked";
	    }
	    $test_acces_ecriture = db_valeur("SELECT count(*) from groupmembers where principal_id = '".$principal_id_write."' AND member_id = '".$member_id."' ");
	    if ($test_acces_ecriture >0)
	    {
		$style_tmp = "objet_ecriture";
		$check_2 = "checked";
	    }
	}    
	    if ($id_tmp != $_SESSION['user']['id_utilisateur'])
	    {
			echo "<div class='table_ligne'>";
			$disabled1 = '';
			$disabled2 = '';
			$infobulle = infobulle($trad["CALDAV_synchro"].$trad["CALDAV_active"]); 
			
			if($droit_acces_tous_tmp >= 1)
			{
				if($droit_acces_tous_tmp == 1)
				{
				$opacity1 = 'opacity:1;';
				$opacity2 = 'opacity:1;';
				$opacity3 = 'opacity:0.5;';
				$disabled2 = 'disabled';
				}
				if($droit_acces_tous_tmp == 2)
				{
				$opacity1 = 'opacity:1;';
				$opacity2 = 'opacity:1;';
				$opacity3 = 'opacity:1;';
				$disabled2 = '';
				}
			}
			
			if($droit_acces_groupe_tmp > $droit_acces_tous_tmp)
			{
				if($droit_acces_groupe_tmp == 1)
				{
				$opacity1 = 'opacity:1;';
				$opacity2 = 'opacity:1;';
				$opacity3 = 'opacity:0.5;';
				$disabled2 = 'disabled';
				}
				if($droit_acces_groupe_tmp == 2)
				{
				$opacity1 = 'opacity:1;';
				$opacity2 = 'opacity:1;';
				$opacity3 = 'opacity:1;';
				$disabled2 = '';
				}
			}
			
			
			if(($droit_acces_user_tmp > $droit_acces_tous_tmp) || ($droit_acces_user_tmp > $droit_acces_groupe_tmp)) 
			{
				if($droit_acces_user_tmp == 1)
				{
				$opacity1 = 'opacity:1;';
				$opacity2 = 'opacity:1;';
				$opacity3 = 'opacity:0.5;';
				$disabled2 = 'disabled';
				}
				if($droit_acces_user_tmp == 2)
				{
				$opacity1 = 'opacity:1;';
				$opacity2 = 'opacity:1;';
				$opacity3 = 'opacity:1;';
				$disabled2 = '';
				}
			}
			
					
			if($droit_acces_user_tmp || $droit_acces_tous_tmp || $droit_acces_groupe_tmp)
			{
				if($statut_tmp != 1)
				{
				    $opacity1 = 'opacity:0.5;';
				    $opacity2 = 'opacity:0.5;';
				    $opacity3 = 'opacity:0.5;';
				    $disabled1 = 'disabled';
				    $disabled2 = 'disabled';
				    $infobulle = infobulle($trad["CALDAV_synchro"].$trad["CALDAV_inactive"]); 
				}
				
				echo "<div class='cellule_lib ".$style_tmp."' style='".$opacity1."' ".$infobulle." id='text_".$id_tmp."' onClick=\"selection_affect(this.id);\"><img src=\"".PATH_TPL.$icone_point."\" class='puce_point' /> ".$user_tmp["prenom"]." ".$user_tmp["nom"]."</div>";
				echo "<div class='cellule_input' title=\"".$trad["lecture_infos"]."\"><input style='".$opacity2."' ".$disabled1." type='checkbox' name='lecture_users[]' id='lecture_".$id_tmp."' value='".$id_tmp."' onClick=\"selection_affect(this.id);\"  ".$check_1." /></div>";
				echo "<div class='cellule_input' title=\"".$trad["ecriture_infos"]."\"><input style='".$opacity3."' ".$disabled2." type='checkbox' name='ecriture_users[]' id='ecriture_".$id_tmp."' value='".$id_tmp."' onClick=\"selection_affect(this.id);\"  ".$check_2." /></div>";
				$cpt_element++;
		 	}
		 }
		  echo "</div>";
		 
}
echo "<hr/>";
echo "<div style='text-align:right;'>";
echo "<input class='button' type='submit' name='valider' value='".$trad["CALDAV_valider"]."'/>";
echo "</div>";
echo "</form>";
echo "</div>";
if ($cpt_element == 0){alert($trad['CALDAV_aucun_utilisateur']);reload_close();}
}
else
{
reload_close();
}