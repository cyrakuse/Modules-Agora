m<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
require_once PATH_INC."header.inc.php";
$version = " V2.16.3-1.2";
$nom_module ="Caldav";

//// Vérification admin
if ($_SESSION['user']['admin_general'] == 1)
{
?>
    <script type="text/javascript">
    /* Installation du module */
    var answer1 = confirm("Installation du module <?php echo $nom_module.$version; ?>.\nYov");
    if (answer1)
    {
    <?php
    // Structure de la table `calendarobjects`
    mysql_query("
    CREATE TABLE IF NOT EXISTS `calendarobjects` (
      `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
      `id_evenement` int(10) NOT NULL,
      `calendardata` mediumblob,
      `uri` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
      `calendarid` int(10) unsigned NOT NULL,
      `lastmodified` int(11) unsigned DEFAULT NULL,
      `etag` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
      `size` int(11) unsigned NOT NULL,
      `componenttype` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
      `firstoccurence` int(11) unsigned DEFAULT NULL,
      `lastoccurence` int(11) unsigned DEFAULT NULL,
      PRIMARY KEY (`id`),
      UNIQUE KEY `calendarid` (`calendarid`,`uri`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 
    ");

    // Structure de la table `calendars`
    mysql_query("
    CREATE TABLE IF NOT EXISTS `calendars` (
      `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
      `id_utilisateur` int(10) NOT NULL,
      `id_agenda` int(10) NOT NULL,
      `principaluri` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
      `displayname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
      `uri` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
      `ctag` int(10) unsigned NOT NULL DEFAULT '0',
      `description` text COLLATE utf8_unicode_ci,
      `calendarorder` int(10) unsigned NOT NULL DEFAULT '0',
      `calendarcolor` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
      `timezone` text COLLATE utf8_unicode_ci,
      `components` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
      `transparent` tinyint(1) NOT NULL DEFAULT '0',
      PRIMARY KEY (`id`),
      UNIQUE KEY `principaluri` (`principaluri`,`uri`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1
    ");

    //Structure de la table `groupmembers`
    mysql_query("
    CREATE TABLE IF NOT EXISTS `groupmembers` (
      `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
      `id_utilisateur` int(10) NOT NULL,
      `id_agenda` int(10) NOT NULL,
      `principal_id` int(10) unsigned NOT NULL,
      `member_id` int(10) unsigned NOT NULL,
      PRIMARY KEY (`id`),
      UNIQUE KEY `principal_id` (`principal_id`,`member_id`)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1
    ");

    // Structure de la table `principals`
    mysql_query("
    CREATE TABLE IF NOT EXISTS `principals` (
      `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
      `id_utilisateur` int(10) NOT NULL,
      `id_agenda` int(10) NOT NULL,
      `uri` varchar(200) COLLATE latin1_general_ci NOT NULL,
      `email` varchar(80) COLLATE latin1_general_ci DEFAULT NULL,
      `displayname` varchar(80) COLLATE latin1_general_ci DEFAULT NULL,
      `vcardurl` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
      PRIMARY KEY (`id`),
      UNIQUE KEY `uri` (`uri`)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1
    ");

    // Structure de la table `gt_caldav_preferences`
    mysql_query("
    CREATE TABLE IF NOT EXISTS `gt_caldav_preferences` (
      `id_utilisateur` int(10) unsigned DEFAULT NULL,
      `id_agenda` int(10) NOT NULL,
      `statut` int(1) DEFAULT NULL,
      KEY `id_utilisateur` (`id_utilisateur`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8;
    ");

    // Ajout lieu, alarme, uri  table `gt_agenda_evenement`
    $sql_lieu = mysql_query("SELECT lieu FROM `gt_agenda_evenement` ");
    if (!$sql_lieu) 
    {mysql_query("ALTER TABLE  `gt_agenda_evenement` ADD  `lieu` TEXT AFTER  `description` ");}
    
    $sql_alarme = mysql_query("SELECT alarme FROM `gt_agenda_evenement` ");
    if (!$sql_alarme)
    {mysql_query("ALTER TABLE  `gt_agenda_evenement` ADD  `alarme` TEXT AFTER  `period_date_exception` ");}
    
    $sql_uri = mysql_query("SELECT uri FROM `gt_agenda_evenement` ");
    if (!$sql_uri) 
    {mysql_query("ALTER TABLE  `gt_agenda_evenement` ADD  `uri` VARCHAR( 200 ) AFTER  `id_utilisateur_modif` ");}
    ?>
    
    alert("Module <?php echo $nom_module.$version; ?> installé.\n\nRenommer ou supprimer le fichier Install.php !\n");
    window.location.replace('index.php');
    }
    else {window.location.replace('index.php');}
    </script>
<?php
}
else 
{redir('index.php');}
?>