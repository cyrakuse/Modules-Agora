<?php
//// MODIFIER $uri_agora par url de votre agora
$uri_agora="http://";

//// NE PAS MODIFIER CES PARAMETRES
$uri_dav = "/dav/caldav.php";
$url_dav = $uri_agora.$uri_dav."/calendars";
?>