<?php
////  index.php
$trad["CALDAV_alerte"]= "Activation de la synchronisation agenda utilisateur necessaire !";
$trad["CALDAV_specifier_pass"] = "Entrer un mot de passe !";
$trad["CALDAV_erreur_pass"] = "Erreur de mot de passe !";
$trad["CALDAV_off"]= "Off";
$trad["CALDAV_active"] = "active";
$trad["CALDAV_on"]= "On";
$trad["CALDAV_inactive"] = "inactive";
$trad["CALDAV_synchro"] = "Synchronisation CALDAV "; 
$trad["CALDAV_identifiant"] = "Identifiant : ";
$trad["CALDAV_password"] = "Mot de passe : ";
$trad["CALDAV_configurer"] = "Configurer le partage";
$trad["CALDAV_info_adresse"] = "L'adresse de synchronisation varie en fonction du client caldav :";
$trad["CALDAV_Android"] = "- Android : ";
$trad["CALDAV_Iphone"] = "- Iphone : ";
$trad["CALDAV_Lightning"] = "- Lightning : ";
$trad["CALDAV_aff_masq"] = "Afficher/Masquer les options de synchronisation";


//// evenement_edit.php
$trad["CALDAV_nom"] = " Caldav";
$trad["CALDAV_lieu"] = "Lieu";
$trad["CALDAV_rappel"] = "Rappel ";

//// caldav_config.php
$trad["CALDAV_titre_popup"] = "Configuration du partage Caldav pour cet agenda";
$trad["CALDAV_droit_acces"] = "Droit d'accés pour : "; 
$trad["CALDAV_valider"] = "Valider"; 
$trad['CALDAV_aucun_utilisateur'] = "Vérifier les droits d'accès à l'agenda !"; 

?>