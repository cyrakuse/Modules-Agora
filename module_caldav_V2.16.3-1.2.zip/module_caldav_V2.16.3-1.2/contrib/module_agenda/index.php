<?php
////	INIT
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
$cle_pref_db = "type_affichage_".MODULE_NOM;
if(isset($_GET["id_dossier"]))	$cle_pref_db .= "_".$_GET["id_dossier"];
pref_user("agendas_details");

////	INTEGRER UN EVENEMENT PROPOSE DANS UN AGENDA
////
if((isset($_GET["id_evt_confirm"]) || isset($_GET["id_evt_noconfirm"]))  &&  $AGENDAS_AFFICHES[$_GET["id_agenda"]]["droit"]>=2){
	if(isset($_GET["id_evt_confirm"]))	
	{
		db_query("UPDATE gt_agenda_jointure_evenement SET confirme='1' WHERE id_evenement=".db_format($_GET["id_evt_confirm"])." AND id_agenda=".db_format($_GET["id_agenda"]));
		// CALDAV
		$statut_caldav_user = db_valeur("SELECT statut FROM `gt_caldav_preferences` WHERE id_utilisateur = '".$_SESSION['user']['id_utilisateur']."' AND id_agenda = '".$_GET["id_agenda"]."' ");
		if ($statut_caldav_user == 1)
		{
			$detail_evt = db_ligne("SELECT * FROM gt_agenda_evenement WHERE id_evenement=".db_format($_GET["id_evt_confirm"])." ");
			$fichier_ics = fichier_caldav($detail_evt,$_SESSION['user']['id_utilisateur'],$_GET["id_agenda"]);
			// EVTS MULTIPLES
			if($detail_evt['uri'])
			{
				$new_uri = db_valeur("SELECT uri FROM gt_agenda_evenement WHERE id_evenement = ".db_format($_GET["id_evt_confirm"])." ");
				db_query("UPDATE `calendarobjects` SET uri='".$new_uri."' WHERE id_evenement = ".db_format($_GET["id_evt_confirm"])." ");
			}
		}
	}
	else
	{
		db_query("DELETE FROM gt_agenda_jointure_evenement WHERE id_evenement=".db_format($_GET["id_evt_noconfirm"])." AND id_agenda=".db_format($_GET["id_agenda"]));
	}
}

////	SUPPR ANCIENS EVENEMENTS D'UN AGENDA
////
if(@$_GET["action"]=="suppr_anciens_evt" && $AGENDAS_AFFICHES[$_GET["id_agenda"]]["droit"]>=2){
	foreach(liste_evenements($_GET["id_agenda"],0,$_GET["time_unix_limit"]) as $id_evt)		{ suppr_evenement($id_evt["id_evenement"],$_GET["id_agenda"]); }
}

////	SUPPR UN AGENDA DE RESSOURCE
////
if(@$_GET["action"]=="suppr_agenda_ressource")
{
	suppr_agenda($_GET["id_agenda"]);
	unset($_SESSION["cfg"]["espace"]["agendas_affiches"], $AGENDAS_AFFICHES, $AGENDAS_AFFECTATIONS);
	$redir_agenda =  db_valeur("SELECT id_agenda FROM gt_agenda WHERE id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."' AND type='utilisateur'");
	redir(php_self()."?agendas_demandes[]=".$redir_agenda);
}

////	SUPPR UN EVENEMENT DANS UN AGENDA
////
if(@$_GET["action"]=="suppr_evt"){
	suppr_evenement($_GET["id_evenement"], $_GET["id_agenda"], @$_GET["date_suppr"]);
	if(@$_GET["date_suppr"]!="")	redir(php_self());  // uniquement si modif d'evt
}

//// ACTIVATION-DESACTIVATION CALDAV
////
if($_POST["valider_caldav"])
{
  $id_agenda_agora = $_POST['id_agenda_caldav'];
  $info_agenda = db_ligne("SELECT * FROM `gt_agenda` WHERE `id_utilisateur` =  '".$_SESSION['user']['id_utilisateur']."' AND `id_agenda`= '".$id_agenda_agora."' ");
      
  if(isset($_POST['caldav_on']))
  {
    //INIT
    
    if (($info_agenda['type']) == 'utilisateur')
    {
    // SQL
    db_query("UPDATE  `gt_caldav_preferences` SET `statut` = '1' WHERE  `id_utilisateur` = '".$_SESSION['user']['id_utilisateur']."' AND id_agenda = '".$id_agenda_agora."' ");
    db_query("INSERT INTO `calendars` SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_agora."', principaluri = 'principals/".$_SESSION['user']['identifiant']."', displayname = '".$_SESSION['user']['prenom']." ".$_SESSION['user']['nom']."', uri = 'perso', ctag ='1', timezone = 'EUROPE/PARIS', components = 'VEVENT,VTODO' ");
    db_query("INSERT INTO `principals` SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."',id_agenda = '".$id_agenda_agora."', uri = 'principals/".$_SESSION['user']['identifiant']."', displayname = '".$_SESSION['user']['identifiant']."' ");
    db_query("INSERT INTO `principals` SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_agora."', uri = 'principals/".$_SESSION['user']['identifiant']."/calendar-proxy-read' ");
    db_query("INSERT INTO `principals` SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_agora."', uri = 'principals/".$_SESSION['user']['identifiant']."/calendar-proxy-write' ");
    
      //// CREATION DES EVT CALDAV
      $liste_evenements = liste_evenements($id_agenda_agora, (time()-(86400*30)), (time()+(86400*3650)), false); // T-30jours => T+10ans
      foreach ($liste_evenements as $evt_tmp)
      {$fichier_ics = fichier_caldav($evt_tmp,$_SESSION['user']['id_utilisateur'],$id_agenda_agora);}
    }
    
    if (($info_agenda['type']) == 'ressource')
    {
	$member_id = db_valeur("SELECT id from principals where uri='principals/".$_SESSION['user']['identifiant']."' ");
	if (!$member_id)
	{
	alert($trad["CALDAV_alerte"]);
	redir('index.php');
	}
	else
	{
	// SQL
	db_query("UPDATE  `gt_caldav_preferences` SET `statut` = '1' WHERE  `id_utilisateur` = '".$_SESSION['user']['id_utilisateur']."' AND id_agenda = '".$id_agenda_agora."' ");
	
	$name_ressource = str_replace(' ','_',$info_agenda['titre']);
	
	db_query("INSERT INTO `calendars` SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_agora."', principaluri = 'principals/ressource".$info_agenda['id_agenda']."', displayname = '".$info_agenda['titre']."', uri = '".$name_ressource."', ctag ='1', timezone = 'EUROPE/PARIS', components = 'VEVENT,VTODO' ");
	db_query("INSERT INTO `principals` SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_agora."', uri = 'principals/ressource".$info_agenda['id_agenda']."', displayname = '".$name_ressource."' ");
	db_query("INSERT INTO `principals` SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_agora."', uri = 'principals/ressource".$info_agenda['id_agenda']."/calendar-proxy-read' ");
	db_query("INSERT INTO `principals` SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_agora."', uri = 'principals/ressource".$info_agenda['id_agenda']."/calendar-proxy-write' ");
	$principal_id_write = db_last_id();
	$sql_ecriture = db_query("INSERT INTO groupmembers SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda_agora."', principal_id = '".$principal_id_write."', member_id = '".$member_id."' ");
		
	//// CREATION DES EVT CALDAV
	$liste_evenements = liste_evenements($id_agenda_agora, (time()-(86400*30)), (time()+(86400*3650)), false); // T-30jours => T+10ans
	foreach ($liste_evenements as $evt_tmp)
	{$fichier_ics = fichier_caldav($evt_tmp,$_SESSION['user']['id_utilisateur'],$id_agenda_agora);}
	}
    }

  }
  if(isset($_POST['caldav_off']))
  {
    if (($info_agenda['type']) == 'utilisateur')
    {
	db_query("UPDATE  `gt_caldav_preferences` SET `statut` = '0' WHERE  `id_utilisateur` = '".$_SESSION['user']['id_utilisateur']."' ");
	db_query("DELETE FROM `principals` WHERE id_utilisateur = '".$_SESSION['user']['id_utilisateur']."' ");
	db_query("DELETE FROM `groupmembers` WHERE id_utilisateur = '".$_SESSION['user']['id_utilisateur']."' ");
	$calendar_info = db_tableau("SELECT * FROM `calendars` WHERE `id_utilisateur` =  '".$_SESSION['user']['id_utilisateur']."' ");
	foreach ($calendar_info as $calendar_info_tmp)
	{
	  db_query("DELETE FROM `calendarobjects` WHERE calendarid = '".$calendar_info_tmp['id']."' ");
	}
	db_query("DELETE FROM `calendars` WHERE id_utilisateur = '".$_SESSION['user']['id_utilisateur']."' ");
    }
    if (($info_agenda['type']) == 'ressource')
    {
	db_query("UPDATE  `gt_caldav_preferences` SET `statut` = '0' WHERE  `id_utilisateur` = '".$_SESSION['user']['id_utilisateur']."' AND id_agenda = '".$id_agenda_agora."' ");
	db_query("DELETE FROM `principals` WHERE id_utilisateur = '".$_SESSION['user']['id_utilisateur']."' AND id_agenda = '".$id_agenda_agora."' ");
	db_query("DELETE FROM `groupmembers` WHERE id_utilisateur = '".$_SESSION['user']['id_utilisateur']."' AND id_agenda = '".$id_agenda_agora."' ");
	$calendar_id = db_valeur("SELECT `id` FROM `calendars` WHERE `id_utilisateur` =  '".$_SESSION['user']['id_utilisateur']."' AND id_agenda = '".$id_agenda_agora."' ");
	db_query("DELETE FROM `calendarobjects` WHERE calendarid = '".$calendar_id."' ");
	db_query("DELETE FROM `calendars` WHERE id = '".$calendar_id."' ");
    }
  }
redir('index.php');
}
?>


<script type="text/javascript">
////	Fonction pour cocher/décocher les agendas
////
function CheckAgendas(type)
{
	// Coche tout / Decoche la sélection ?
	coche_selection = false;
	if((type=="all" && $("input[name='agendas_demandes[]']:checked").length!=$("input[name='agendas_demandes[]']").length)  ||  (type=="utilisateur" && $(".type_utilisateur:checked").length!=$(".type_utilisateur").length)  ||  (type=="ressource" && $(".type_ressource:checked").length!=$(".type_ressource").length))
		coche_selection = true;

	// On parcour toutes les checkbox
	for(var i=0; i < $("input[name='agendas_demandes[]']").length; i++)
	{
		// Init les ID
		id_box = document.getElementsByName("agendas_demandes[]")[i].id;
		id_txt = id_box.replace("box_","txt_");
		// Coche / Decoche l'agenda courant ?
		if(coche_selection==true && (type=="all" || (type=="utilisateur" && element(id_box).className=="type_utilisateur") || (type=="ressource" && element(id_box).className=="type_ressource"))){
			element(id_box).checked = true;
			element(id_txt).className = "lien_select2";
		}else{
			element(id_box).checked = false;
			element(id_txt).className = "lien";
		}
	}
}
</script>


<style>
.agenda_conteneur	{ margin-bottom:25px; width:99.5%; <?php echo STYLE_BLOCK; ?> }
.libelle_agenda		{ text-align:center; }
.menu_agenda:hover	{ opacity:0.9; filter:alpha(opacity=90); cursor:pointer; }
.div_evt_contenu	{ padding:3px; cursor:pointer; text-align:left; line-height:12px; font-size:11px; }
/* IMPRESSION */
@media print {
	@page {size:landscape;}
	.agenda_conteneur	{ margin-top:-80px; page-break-after:always; page-break-inside:avoid; }
	.libelle_agenda		{ padding:5px; }
	.print_titre		{ font-size:18px; padding-bottom:20px; }
}
</style>


<table id="contenu_principal_table"><tr>
	<td id="menu_gauche_block_td" class="noprint">
		<div id="menu_gauche_block_flottant">
			<?php
			////	EVENEMENTS A CONFIRMER
			////
			$menu_proposition_evt = menu_proposition_evt();
			if($menu_proposition_evt!="")	echo "<div class='menu_gauche_block content' style='border:solid 2px #fff;'>".$menu_proposition_evt."</div>";

			////	CALENDRIER
			////
			echo "<div class='menu_gauche_block content' style='font-weight:normal;'>";
				$_REQUEST["date_selection_debut"] = $config["agenda_debut"];
				$_REQUEST["date_selection_fin"] = $config["agenda_fin"];
				$_REQUEST["date_affiche"] = strtotime(strftime("%Y-%m-15",$config["agenda_debut"]));
				require PATH_INC."calendrier.inc.php";
			echo "</div>";

			/////	AFFICHER LES CATEGORIES D'EVT  /  GERER LES CATEGORIES
			////
			echo "<div class='menu_gauche_block content'>";
				echo menu_evt_filtre_categorie();
				if(droit_gestion_categories()==true)	echo "<div class='menu_gauche_ligne lien' onClick=\"edit_iframe_popup('categories.php');\"><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/nuancier.png\" /></div><div class='menu_gauche_txt'>".$trad["AGENDA_gerer_categories"]."</div></div>";
			echo "</div>";

			////	AGENDAS DISPO
			////
			if(count($AGENDAS_AFFICHES)>0)
			{
				////	LISTE DES AGENDAS VISIBLES
				////
				echo "<form id='liste_agendas' action='index.php' method='get' class='menu_gauche_block content'>";
					////	MENU D'AFFICHAGE DES AGENDAS
					echo "<div class='menu_context' style='width:200px;line-height:15px;' id='menu_agendas'>";
						////	Cocher / Décocher : tous les agendas / les agendas d'users / les agendas de ressource
						echo "<div class='lien' onClick=\"CheckAgendas('all');\">".$trad["AGENDA_cocher_tous_agendas"]."</div>";
						echo "<div class='lien' onClick=\"CheckAgendas('utilisateur');\">".$trad["AGENDA_cocher_agendas_users"]."</div>";
						echo "<div class='lien' onClick=\"CheckAgendas('ressource');\">".$trad["AGENDA_cocher_agendas_ressources"]."</div>";
						////	"Afficher tous les agendas" ?
						if($_SESSION["user"]["admin_general"]==1){
							if(@$_SESSION["cfg"]["espace"]["afficher_tous_agendas"]==1)		{ $tous_get = 0;  $tous_libelle = $trad["AGENDA_masquer_tous_agendas"]; }
							else															{ $tous_get = 1;  $tous_libelle = $trad["AGENDA_afficher_tous_agendas"]; }
							echo "<hr style='width:200px;' /><div class='lien' onClick=\"redir('index.php?afficher_tous_agendas=".$tous_get."');\" ".infobulle($trad["admin_only"]).">".$tous_libelle."</div>";
						}
					echo "</div>";
					echo "<span style='float:right;' id='icone_menu_agendas'><img src=\"".PATH_TPL."divers/check_inverser.png\" /></span>";
					echo  "<script type='text/javascript'> menu_contextuel('menu_agendas'); </script>";
					////	LISTE DES AGENDAS
					$cpt_agenda = 0;
					foreach($AGENDAS_AFFICHES as $cle_tmp => $agenda_tmp)
					{
						////	Menu contextuel de l'element (General, Modif, Suppr, export)
						$cfg_menu_elem = array("objet"=>$objet["agenda"], "objet_infos"=>$agenda_tmp, "taille_icone"=>"small_inline");
						if($agenda_tmp["droit"]==3)
						{
							$cfg_menu_elem["modif"] = "agenda_edit.php?id_agenda=".$agenda_tmp["id_agenda"];
							if($agenda_tmp["type"]=="ressource")	$cfg_menu_elem["suppr"] = "index.php?action=suppr_agenda_ressource&id_agenda=".$agenda_tmp["id_agenda"];
							$libelle_export_mail = "<span ".infobulle($trad["AGENDA_exporter_ical_mail2"]."<br>".$trad["envoyer_a"]." ".$_SESSION["user"]["mail"]).">".$trad["AGENDA_exporter_ical_mail"]."</span>";
							$cfg_menu_elem["options_divers"][] = array("icone_src"=>PATH_TPL."divers/export.png", "text"=>$trad["AGENDA_exporter_ical"], "action_js"=>"redir('agenda_export.php?id_agenda=".$agenda_tmp["id_agenda"]."');");
							$cfg_menu_elem["options_divers"][] = array("icone_src"=>PATH_TPL."module_utilisateurs/user_telmobile.png", "text"=>$libelle_export_mail, "action_js"=>"redir('agenda_export.php?id_agenda=".$agenda_tmp["id_agenda"]."&envoi_mail=1');");
							if(version_compare(PHP_VERSION,'5.2','>=')==true)	$cfg_menu_elem["options_divers"][] = array("icone_src"=>PATH_TPL."divers/import.png", "text"=>$trad["AGENDA_importer_ical"], "action_js"=>"popup('agenda_import.php?id_agenda=".$agenda_tmp["id_agenda"]."');");
						}
						// Suppr anciens evt ?
						if($agenda_tmp["droit"]>=2)  $cfg_menu_elem["options_divers"][] = array("icone_src"=>PATH_TPL."module_agenda/suppr_anciens_evt.png", "text"=>$trad["AGENDA_suppr_anciens_evt"], "action_js"=>"confirmer('".addslashes($trad["AGENDA_confirm_suppr_anciens_evt"])."','index.php?action=suppr_anciens_evt&id_agenda=".$agenda_tmp["id_agenda"]."&time_unix_limit=".$config["agenda_debut"]."');");
						// Enregistre la configuration
						$AGENDAS_AFFICHES[$cle_tmp]["cfg_menu_elem"] = $cfg_menu_elem;
						////	Affichage de l'agenda
						$check_tmp		 = (@in_array($agenda_tmp["id_agenda"],$_SESSION["cfg"]["espace"]["agendas_affiches"]))  ?  "checked"  :  "";
						$lecture_tmp	 = ($agenda_tmp["droit"]==1)  ?  " (".$trad["lecture"].") "  :  "";
						$libelle_class = (!empty($check_tmp))  ?  "lien_select2"  :  "lien";
						$libelle_style = ($agenda_tmp["type"]=="ressource")  ?  "style='font-style:italic;'"  :  "";
						echo "<div class='ligne_survol' ".infobulle(nl2br($agenda_tmp["description"])).">";
							echo "<input type='checkbox' name='agendas_demandes[]' value='".$agenda_tmp["id_agenda"]."' id='box_agenda_demande".$cpt_agenda."' onClick=\"checkbox_text(this,'lien_select2');\" ".$check_tmp." class='type_".$agenda_tmp["type"]."' />";// Class "type agenda" pour cocher/decocher
							echo "<span class='".$libelle_class."' '".$libelle_style."' id='txt_agenda_demande".$cpt_agenda."' onClick=\"checkbox_text(this,'lien_select2');\"> ".$agenda_tmp["titre"]." ".$lecture_tmp." </span>";
							require PATH_INC."element_menu_contextuel.inc.php";
						echo "</div>";
						$cpt_agenda++;
					}
					////	Bouton de validation
					echo "<input type='submit' value=\"".$trad["afficher"]."\" class='button' style='margin-top:10px;width:80px;' />";
				echo "</form>";

				/////	IMPRIMER L'AGENDA  /  AGENDA QUE L'AUTEUR A CREE / AJOUTER UN AGENDA DE RESSOURCE
				////
				echo "<div class='menu_gauche_block content'>";
					echo "<div class='menu_gauche_ligne lien' onclick=\"redir('".php_self()."?printmode=1');\" title=\"".$trad["AGENDA_imprimer_agendas_infos"]."\"><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/imprimer.png\" /></div><div class='menu_gauche_txt'>".$trad["AGENDA_imprimer_agendas"]."</div></div>";
					if($_SESSION["user"]["id_utilisateur"]>0)	echo "<div class='menu_gauche_ligne lien' onClick=\"popup('evenements_proprietaires.php');\"><div class='menu_gauche_img'><img src=\"".PATH_TPL."module_agenda/evt_proprietaire.png\" /></div><div class='menu_gauche_txt'>".$trad["AGENDA_evt_proprio"]."</div></div>";
					if(droit_ajout_agenda_ressource()==true)	echo "<div class='menu_gauche_ligne lien' onClick=\"edit_iframe_popup('agenda_edit.php');\" ".infobulle($trad["AGENDA_ajouter_agenda_ressource_bis"])."><div class='menu_gauche_img'><img src=\"".PATH_TPL."module_agenda/ajouter_ressource.png\" /></div><div class='menu_gauche_txt'>".$trad["AGENDA_ajouter_agenda_ressource"]."</div></div>";
				echo "</div>";
			}
			?>
		</div>
	</td>
	<td>
		<?php
		////	INIT L'AFFICHAGE DES AGENDAS
		if($_SESSION["cfg"]["espace"]["agenda_affichage"]=="jour")				{ $url_pre = 86400;		$url_suiv = 86400; }
		elseif($_SESSION["cfg"]["espace"]["agenda_affichage"]=="semaine_w")		{ $url_pre = 86400*3;	$url_suiv = 86400*8; }
		elseif($_SESSION["cfg"]["espace"]["agenda_affichage"]=="semaine")		{ $url_pre = 86400*3;	$url_suiv = 86400*8; }
		elseif($_SESSION["cfg"]["espace"]["agenda_affichage"]=="mois")			{ $url_pre = 86400*15;	$url_suiv = 86400*40; }
		$tab_jours_feries = jours_feries(strftime("%Y",$_SESSION["cfg"]["espace"]["agenda_date"]));
		
		////	AUCUN AGENDA / TABLEAU DE SYNTHESE DES AGENDAS
		if(count($_SESSION["cfg"]["espace"]["agendas_affiches"])>1)			require "agendas.inc.php";
		elseif(count($_SESSION["cfg"]["espace"]["agendas_affiches"])==0)	echo "<div class='div_elem_aucun'>".$trad["AGENDA_aucun_agenda_visible"]."</div>";

		////	AFFICHAGE DE CHAQUE AGENDA
		////
		if(count($_SESSION["cfg"]["espace"]["agendas_affiches"])==1 || @$_REQUEST["agendas_details"]==1)
		{
			foreach($_SESSION["cfg"]["espace"]["agendas_affiches"] as $id_agenda)
			{
				echo "<a id='div_agenda_".$id_agenda."' style='position:absolute;margin-top:-60px;'></a>";
				echo "<div id='agenda".$id_agenda."_conteneur' class='agenda_conteneur'>";
				
				//// CALDAV
				if ((monagenda($id_agenda,$_SESSION['user']['id_utilisateur'])) == true)
				{
				    $statut_caldav_tmp = db_valeur("SELECT statut FROM `gt_caldav_preferences` WHERE id_utilisateur = '".$_SESSION['user']['id_utilisateur']."' AND id_agenda = '".$id_agenda."' ");
				    if ($statut_caldav_tmp == NULL)
				    {
				      db_query("INSERT INTO `gt_caldav_preferences` SET id_utilisateur = '".$_SESSION['user']['id_utilisateur']."', id_agenda = '".$id_agenda."', statut ='0' ");
				    }
				
				    if ($statut_caldav_tmp == 1) 
				    {
					$style_caldav ='lien_select';
					$statut_caldav_name = 'caldav_off';
					$submit_caldav_value = $trad["CALDAV_off"];
					$txt_caldav = $trad["CALDAV_active"];
					$info_agenda_tmp = db_ligne("SELECT * FROM `gt_agenda` WHERE `id_utilisateur` =  '".$_SESSION['user']['id_utilisateur']."' AND `id_agenda`= '".$id_agenda."' ");
					if ($info_agenda_tmp['type'] == 'utilisateur')
					{
					  $url_synchro ="".$url_dav."/".$_SESSION['user']['identifiant']."/perso";
					  $url_principals = "".str_replace('calendars','principals',$url_dav)."/".$_SESSION['user']['identifiant']."";
					
					}
					if ($info_agenda_tmp['type'] == 'ressource')
					{
					    $name_ressource_tmp = str_replace(' ','_',$info_agenda_tmp['titre']);
					    $url_synchro = "".$url_dav."/ressource".$id_agenda."/".$name_ressource_tmp."";
						$url_principals = "".str_replace('calendars','principals',$url_dav)."/ressource".$info_agenda_tmp['id_agenda']."";
					}
				    }
				    else
				    {
					$style_caldav = 'lien';
					$statut_caldav_name = 'caldav_on';
					$submit_caldav_value = $trad["CALDAV_on"];
					$txt_caldav = $trad["CALDAV_inactive"];
					$url_synchro ='';
				    }
				
				    echo "<div id='caldav".$id_agenda."' style='margin-left:10px;display:none;'>";
					echo "<hr style=\"clear:both;visibility:hidden;\">";
					echo "<form name='form_caldav".$id_agenda."' action='index.php' method='POST' onsubmit='".$onsubmit_caldav."'>";
				    echo "<img style='margin-right:5px;' src=\"".PATH_TPL."module_agenda/caldav.png\" />";
				    echo "<span class = '".$style_caldav."'";
					if ($url_synchro)
					{
						echo "".infobulle("".$trad["CALDAV_info_adresse"]."<br>".$trad["CALDAV_Android"].$url_dav."<br>".$trad["CALDAV_Lightning"].$url_synchro."<br>".$trad["CALDAV_Iphone"].$url_principals."")."";
					}
				    echo ">".$trad["CALDAV_synchro"].$txt_caldav."</span>";
				    echo "<input type='hidden' name='id_agenda_caldav' value='".$id_agenda."'>";				
				    echo "<input type='hidden' name= '".$statut_caldav_name."' value= '".$statut_caldav."' /> ";
					echo "<input class='button' style='margin-left:30px;width:40px;' type='submit' name='valider_caldav' value='".$submit_caldav_value."'/>";
				    echo "</form>";
				    // AFFICHAGE LIEN CONFIG
				    if ($statut_caldav_tmp == 1)
				    {
					echo "<table style='margin-left:25px;'>";
					echo "<tr class=\"lien\" onClick=\"edit_iframe_popup('caldav_config.php?id_agenda=".$id_agenda."');\"><td class=\"menu_gauche_txt\"><img style=\"margin-right:5px;\" src=\"".PATH_TPL."divers/fleche_droite.png\">".$trad["CALDAV_configurer"]."</td></tr>";
					echo "</table>";
				    }
				    echo "<hr/>";
				    echo "</div>";
				}
				else
				{
				    // AFFICHAGE IMAGE ET ADRESSE SI DROITS CALDAV
				    $info_agenda_tmp = db_ligne("SELECT * FROM `gt_agenda` WHERE `id_agenda`= '".$id_agenda."' ");
				    $identifiant_caldav_tmp = db_valeur("SELECT identifiant FROM gt_utilisateur WHERE id_utilisateur = '".$info_agenda_tmp['id_utilisateur']."' ");
					
	
				    if (($info_agenda_tmp['type']) == 'utilisateur')
				    {
					$principal_id_read = db_valeur("SELECT id from principals where uri='principals/".$identifiant_caldav_tmp."/calendar-proxy-read' ");
					$principal_id_write = db_valeur("SELECT id from principals where uri='principals/".$identifiant_caldav_tmp."/calendar-proxy-write' ");
					$url_synchro ="".$url_dav."/".$identifiant_caldav_tmp."/perso";
					$url_principals = "".str_replace('calendars','principals',$url_dav)."/".$identifiant_caldav_tmp."";
					}
	
				    if (($info_agenda_tmp['type']) == 'ressource')
				    {
					$principal_id_read = db_valeur("SELECT id from principals where uri='principals/ressource".$info_agenda_tmp['id_agenda']."/calendar-proxy-read' ");
					$principal_id_write = db_valeur("SELECT id from principals where uri='principals/principals/ressource".$info_agenda_tmp['id_agenda']."/calendar-proxy-write' ");
					$name_ressource_tmp = str_replace(' ','_',$info_agenda_tmp['titre']);
					$url_synchro = "".$url_dav."/ressource".$info_agenda_tmp['id_agenda']."/".$name_ressource_tmp."";
				    $url_principals = "".str_replace('calendars','principals',$url_dav)."/ressource".$info_agenda_tmp['id_agenda']."";
					}
				    
				    // TEST DROITS
				    $member_id = db_valeur("SELECT id from principals where uri='principals/".$_SESSION['user']['identifiant']."' ");
				    
				    $test_acces_lecture = db_valeur("SELECT count(*) from groupmembers where principal_id = '".$principal_id_read."' AND member_id = '".$member_id."' ");
				    $test_acces_ecriture = db_valeur("SELECT count(*) from groupmembers where principal_id = '".$principal_id_write."' AND member_id = '".$member_id."' ");
				    	
	    			}
	    			//// FIN CALDAV
			
	    				////	HEADER DE L'AGENDA
					////
					echo "<table style='width:100%;font-weight:bold;' cellpadding='2px'><tr>";
						////	MENU CONTEXTUEL + TITRE
						echo "<td class='print_titre'>";
							$agenda_tmp = $AGENDAS_AFFICHES[$id_agenda];
							$cfg_menu_elem = $AGENDAS_AFFICHES[$id_agenda]["cfg_menu_elem"];
							$cfg_menu_elem["taille_icone"] = "big";
							require PATH_INC."element_menu_contextuel.inc.php";
							echo majuscule($agenda_tmp["titre"])." &nbsp; <span style='font-size:10px;font-weight:normal;'>".text_reduit($agenda_tmp["description"],100)."</span>";
						echo "</td>";
						echo "<td class='print_titre libelle_agenda'>";
							////	PRECEDENT
							echo "<img src=\"".PATH_TPL."divers/precedent.png\" onClick=\"redir('index.php?date_affiche=".($config["agenda_debut"]-$url_pre)."');\" ".infobulle($trad["AGENDA_periode_precedante"])." class='menu_agenda noprint' style='margin-right:10px;' />&nbsp; ";
							////	AFFICHAGE JOUR / SEMAINE  (exple : "01 novembre - 07 novembre (semaine 4)")
							if(preg_match("/semaine|jour/i",$_SESSION["cfg"]["espace"]["agenda_affichage"]))
							{
								echo formatime("%d %B",$config["agenda_debut"]);
								if(preg_match("/semaine/i",$_SESSION["cfg"]["espace"]["agenda_affichage"]))		echo " - ".formatime("%d %B",$config["agenda_fin"]); 
								echo " &nbsp; (".$trad["AGENDA_num_semaine"]." ".date("W",$config["agenda_debut"]).")";//(ne pas utiliser strftime("%W"): car pas le même résultat)
							}
							////	AFFICHAGE MOIS  (exple : "novembre 2017")
							else
							{
								// Mois (avec menu)
								echo "<div class='menu_context' id='menu_mois_cal".$id_agenda."'><div style='float:left;'>";
								for($cpt_mois=1; $cpt_mois<=12; $cpt_mois++) {
									$mois_unix = strtotime($cal_annee."-".$cpt_mois."-01");
									$class = ($cpt_mois==$cal_mois)  ?  "class='lien_select'"  :  "";
									if($cpt_mois==7)	echo "</div><div style='float:left;margin-left:10px;'>"; // affiche 2ème colonne
									echo "<a href=\"javascript:redir('".php_self()."?date_affiche=".$mois_unix."');\" ".$class.">".formatime("%B",$mois_unix)."</a><br>";
								}
								echo "</div></div>";
								echo "<span id='icone_menu_mois_cal".$id_agenda."'>".ucfirst(formatime("%B",$_REQUEST["date_affiche"]))." <img src=\"".PATH_TPL."divers/derouler.png\" class='noprint' /></span>";
								echo "<script type='text/javascript'> menu_contextuel('menu_mois_cal".$id_agenda."'); </script> &nbsp;&nbsp;";
								// Année (avec menu)
								echo "<div class='menu_context' id='menu_year_cal".$id_agenda."'><div style='float:left;'>";
								for($cpt_annee=($cal_annee-6); $cpt_annee<=($cal_annee+5); $cpt_annee++) {
									$annee_unix = strtotime($cpt_annee."-".$cal_mois."-01");
									($cpt_annee==$cal_annee) ? $class="class='lien_select'" : $class="";
									if($cpt_annee==$cal_annee)	echo "</div><div style='float:left;margin-left:10px;'>"; // affiche 2ème colonne
									echo "<a href=\"javascript:redir('".php_self()."?date_affiche=".$annee_unix."');\" ".$class.">".strftime("%Y",$annee_unix)."</a><br>";
								}
								echo "</div></div>";
								echo "<span id='icone_menu_year_cal".$id_agenda."'>".strftime("%Y",$_REQUEST["date_affiche"])." <img src=\"".PATH_TPL."divers/derouler.png\" class='noprint' /></span>";
								echo "<script type='text/javascript'> menu_contextuel('menu_year_cal".$id_agenda."'); </script>";
							}
							////	SUIVANT
							echo "&nbsp; <img src=\"".PATH_TPL."divers/suivant.png\" onClick=\"redir('index.php?date_affiche=".($config["agenda_debut"]+$url_suiv)."');\" ".infobulle($trad["AGENDA_periode_suivante"])." class='menu_agenda noprint' style='margin-left:10px;margin-right:50px;' />";
						echo "</td>";
						////	AFFICHAGE : JOUR/SEMAINE/MOIS
						echo "<td style='text-align:right' class='noprint'>";
							echo "<img src=\"".PATH_TPL."module_agenda/aujourdhui.gif\" onClick=\"redir('index.php?date_affiche=".time()."');\" ".infobulle($trad["aff_aujourdhui"])." class='menu_agenda' />&nbsp; &nbsp;";
							echo "<img src=\"".PATH_TPL."module_agenda/jour.gif\" onClick=\"redir('index.php?affichage_demande=jour');\" ".infobulle($trad["AGENDA_evt_jour"])." class='menu_agenda' />&nbsp;";
							echo "<img src=\"".PATH_TPL."module_agenda/semaine_w.gif\" onClick=\"redir('index.php?affichage_demande=semaine_w');\" ".infobulle($trad["AGENDA_evt_semaine_w"])." class='menu_agenda' />&nbsp;";
							echo "<img src=\"".PATH_TPL."module_agenda/semaine.gif\" onClick=\"redir('index.php?affichage_demande=semaine');\" ".infobulle($trad["AGENDA_evt_semaine"])." class='menu_agenda' />&nbsp;";
							echo "<img src=\"".PATH_TPL."module_agenda/mois.gif\" onClick=\"redir('index.php?affichage_demande=mois');\" ".infobulle($trad["AGENDA_evt_mois"])." class='menu_agenda' />&nbsp;";
						
						 //CALDAV
						if ((monagenda($id_agenda,$_SESSION['user']['id_utilisateur'])) == true)
						{echo "&nbsp; &nbsp;<img style=\"width:18px;\" src=\"".PATH_TPL."module_agenda/caldav.png\" onClick=\"$('#caldav".$id_agenda."').toggle();\" ".infobulle($trad["CALDAV_aff_masq"])." class='menu_agenda' />";}
						if (($test_acces_ecriture) || ($test_acces_lecture))
						{echo "&nbsp; &nbsp;<img style=\"width:18px;\" src=\"".PATH_TPL."module_agenda/caldav.png\" ".infobulle("".$trad["CALDAV_info_adresse"]."<br>".$trad["CALDAV_Android"].$url_dav."<br>".$trad["CALDAV_Lightning"].$url_synchro."<br>".$trad["CALDAV_Iphone"].$url_principals."")." class='menu_agenda' />";}
						// fin CALDAV
						echo "</td>";
						echo "</tr></table>";
					////	AGENDA DE LA SEMAINE / DU MOIS
					////
					if(preg_match("/jour|semaine/i",$_SESSION["cfg"]["espace"]["agenda_affichage"]))	require "agenda_semaine.inc.php";
					else																				require "agenda_mois.inc.php";
				echo "</div>";
			
			}
		}


		////	PROPOSE D'AFFICHER LE DETAIL DE CHAQUE AGENDA
		////
		if(count($_SESSION["cfg"]["espace"]["agendas_affiches"])>1){
			if(@$_REQUEST["agendas_details"]==1)	{ $agendas_details = 0;  $libelle_agendas_details = $trad["AGENDA_agendas_details_masquer"]; }
			else									{ $agendas_details = 1;  $libelle_agendas_details = $trad["AGENDA_agendas_details"]; }
			echo "<div style='text-align:center;'><button class='button_big' style='width:230px;' onClick=\"redir('".php_self()."?agendas_details=".$agendas_details."');\">".$libelle_agendas_details."</button></div>";
		}
		?>
	</td>
</tr></table>


<?php
// Impression de la page ?
if(isset($_GET["printmode"]))	echo "<script type='text/javascript'>  $(window).load(function(){ print(); });  </script>";
// Footer
require PATH_INC."footer.inc.php";
?>