<?php 
/** 
AJOUTER 
$rcmail_config['plugins'] = array('agora_login');
dans : /roundcube/config/main.inc.php

* This performs an automatic login if accessed from Agora 
*/

//Class agora_login extends rcube_plugin 
class agora_login extends rcube_plugin 
{ 
  public $task = 'login'; 

  function init() 
  { 
    $this->add_hook('startup', array($this, 'startup')); 
    $this->add_hook('authenticate', array($this, 'authenticate')); 
  } 

  function startup($args) 
  { 
    $rcmail = rcmail::get_instance(); 

    // change action to login 
    if (empty($_SESSION['user_id']) && (isset($_POST['_user']))) 
    $args['action'] = 'login'; 
    return $args; 
  } 

  function authenticate($args) 
  { 
    if (isset($_POST["token_courriel"]))
    { 
	  // Calcul le token pr�dictible, sauf la clef secrete connue du serveur uniquement
      $token_clair = $_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_REFERER'].$_SERVER['HTTP_USER_AGENT'];
      //Crypte avec les informations transmises dans le form en clair
      include "../stock_fichiers/config.inc.php";
      $user_cookies = $_COOKIE["agora_project_".db_name.""];
      $informations = "".$user_cookies."-".$_POST['user_id']."@".$_POST['_user']."";
      include "../module_courriel/token/cle.php";
      $token = sha1($token_clair.$informations.$Clecourriel);
	  
		 // Compare les token : Post� et calcul�
		 if(strcmp($_POST["token_courriel"], $token) == 0)
		 {
		  //// CONNEXION DB AGORA 
		  $mysql_link_identifier = @mysql_connect(db_host, db_login, db_password, true);
		  $mysql_db_connect = @mysql_select_db(db_name);
		  // INFO SSO
		  $corpsql_courriel = "FROM `gt_sso` WHERE `id_utilisateur` = '".$_POST['user_id']."' and `user_courriel` = '".$_POST['_user']."'";
		  $args['user'] = $_POST['_user'];
		  $pass_crypte = mysql_query("SELECT `pass_courriel` ".$corpsql_courriel."",$mysql_link_identifier);
		  $pass_crypte = mysql_result($pass_crypte,0,0);
		  include "../commun/sso/crypt_decrypt.php";
		  $args['pass'] = Decrypte($pass_crypte,$Clecourriel); 
		  @mysql_close($mysql_link_identifier);
		  //$args['pass'] = $_POST['_pass']; 
		  $args['cookiecheck'] = false; 
		  $args['valid'] = true; 
		 }
	} 
    return $args; 
  } 
}
?>