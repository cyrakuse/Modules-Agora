<?php
////	INITIALISATION
////
$version = " V2.16.3-3.0";
$nom_module = "Courriel Rouncube";
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
require_once PATH_INC."header.inc.php";

//// Vérification admin
if ($_SESSION['user']['admin_general'] == 1)
{
  //// Test la présence du courriel
  $test = 0;
  $test_module = db_tableau("SELECT * FROM gt_module");
  foreach ($test_module as $module)
  {
	if ($module["nom"] == "courriel")
	{$test = 1;}
  }

  if ($test == 0)
  {
  	
?>
	<script type="text/javascript">
	/* Installation du module */
  	var answer1 = confirm("Installation du module <?php echo $nom_module.$version; ?>.\nY. VEILLET");
  	if (answer1)
  	{
	<?php
	
	//// Inscription du module
	mysql_query("INSERT INTO gt_module (nom, module_path) VALUES ('courriel', 'module_courriel')");
	mysql_query("INSERT INTO gt_module_sso (nom, module_dossier_fichier) VALUES ('courriel', 'module_courriel')");
	mysql_query("ALTER TABLE `gt_sso` ADD `user_courriel` VARCHAR( 255 ) NULL , ADD `pass_courriel` VARCHAR( 255 ) NULL");

	?>
	alert("Module <?php echo $nom_module.$version; ?> installé.\n\nRenommer ou supprimer le fichier Install.php !\nAttendre la redirection pour configurer le module.");
  	window.location.replace('../module_espaces/index.php');
  	}
	else 
	{window.location.replace('index.php');}
</script>
<?php 
}
  else
  {
	//// MAJ VERSION < 3.0
	// CREATION DOSSIER TOKEN
	if (is_dir("token") == false)
	{
		@mkdir("token");
	}
	// DEPLACEMENET CLE.PHP
	if(file_exists("cle.php"))
	{
		copy("cle.php", "token/cle.php");
		unlink("cle.php");	
	}
	// CREATION .HTACCESS DANS TOKEN
	if(!file_exists("token/.htaccess"))
	{
		copy("../commun/sso/.htaccess", "token/.htaccess");		
	}
	?>
	<script type="text/javascript">
  	/* Mise à jour depuis la version précédente */
	alert("Modification pour le module <?php echo $nom_module.$version; ?> faites.\n\nYov");
	window.location.replace('index.php');
  	</script>
	<?php
  }
}
else 
{redir('index.php');}
?>