<?php
////	INITIALISATION
////
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";

$corpsql_courriel = "FROM `gt_sso` WHERE `id_utilisateur` = '".$_SESSION['user']['id_utilisateur']."'";
$user_courriel = db_valeur("SELECT `user_courriel` ".$corpsql_courriel."");

if ($user_courriel)
{
////  Bloc Principal (Iframe GRR)
////
?>
<table id="bloc_principal" width="100%"cellspacing="10px" cellspacing="10px">
<tr>
<td>
<div id="agoraDiv" style="height:768px;width:100%;margin-top:-25px;" class="div_elem_deselect">
<iframe src="form_courriel.php" id="agoraFrame" name="agoraFrame" style="height:100%;width:100%;border:0px;"></iframe>
</div>
</td>
</tr>
</table>

<?php
}
else
{
?>
<script language="JavaScript">
alert("Echec de la connexion automatique !\n\nCliquez sur Valider pour configurer l'authentification externe.\n");
window.location.href ="../module_sso/index.php";
</script>
<?php
}
require_once PATH_INC."footer.inc.php"; 
?>