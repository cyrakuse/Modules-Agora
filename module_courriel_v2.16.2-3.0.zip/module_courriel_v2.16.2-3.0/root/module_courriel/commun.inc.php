<?php
////	INITIALISATION
////
@define("MODULE_NOM","courriel");
@define("MODULE_PATH","module_courriel");
require_once "../includes/global.inc.php";
//add_logs("connexion");
?>
