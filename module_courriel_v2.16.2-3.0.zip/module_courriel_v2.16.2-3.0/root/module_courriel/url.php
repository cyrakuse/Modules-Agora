<?php
/*
CHEMIN RELATIF DE ROUNDCUBE (SANS HTTP) :   
ROUNDCUBE DOIT ETRE A LA RACINE D'AGORA
"../roundcube/" 
*/
$url = "../roundcube/";

// PROTOCOLE DE CONNEXION HTTP / HTTPS (CALCUL DU JETON)
$protocole = "http://";

//// FICHIERS POUR LOGIN ET LOGOUT
$login = "index.php";
$logout = "index.php?_task=logout";
?>
