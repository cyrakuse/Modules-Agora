<?php
///  Menu principal
$trad["COURRIEL_nom_module"] = "Courriel";
$trad["COURRIEL_nom_module_header"] = "Courriel";
$trad["COURRIEL_description_module"] = "Courriel";

///  Int�gration SSO
$trad["COURRIEL_user"]="Nom d'utilisateur";
$trad["COURRIEL_password"]="Mot de passe";
$trad["COURRIEL_specifier_user"] = "Entrer un nom d'utilisateur !";
$trad["COURRIEL_specifier_pass"] = "Entrer un mot de passe !";
$trad["COURRIEL_user_ok"] = "Enregistrement fait !";
$trad["COURRIEL_titrePopUpAdmin"] = "Identifiants de connexion dans la boite de courriel pour :";
$trad["COURRIEL_valider"] = "Enregistrer";

?>
