<?php
///  Menu principal
$trad["GRR_nom_module"] = "GRR";
$trad["GRR_nom_module_header"] = "GRR";
$trad["GRR_description_module"] = "GRR";

///  Int�gration SSO
$trad["GRR_user"]="Nom d'utilisateur";
$trad["GRR_password"]="Mot de passe";
$trad["GRR_specifier_user"] = "Entrer un nom d'utilisateur !";
$trad["GRR_specifier_pass"] = "Entrer un mot de passe !";
$trad["GRR_user_ok"] = "Enregistrement fait !";
$trad["GRR_titrePopUpAdmin"] = "Identifiants de connexion dans GRR pour :";
$trad["GRR_valider"] = "Enregistrer";

?>
