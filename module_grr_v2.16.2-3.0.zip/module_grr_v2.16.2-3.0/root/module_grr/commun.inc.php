<?php
////	INITIALISATION
////
@define("MODULE_NOM","grr");
@define("MODULE_PATH","module_grr");
require_once "../includes/global.inc.php";
//add_logs("connexion");
?>
