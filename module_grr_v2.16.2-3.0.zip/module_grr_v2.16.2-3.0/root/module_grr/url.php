<?php
/*
CHEMIN RELATIF DE GRR (SANS HTTP) :   
GRR EST A LA RACINE D'AGORA
"../grr/" 
*/

$url = "../grr/";

//// FICHIERS POUR LOGIN ET LOGOUT
$login = "login.php";
$logout = "logout.php";
?>