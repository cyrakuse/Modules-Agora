<?php
////	INITIALISATION
@define("MODULE_NOM","emploi");
@define("MODULE_PATH","module_emploi");
require_once "../includes/global.inc.php";
$config["module_espace_options"]["emploi"] = array("ajout_emploi_admin");
$config["tri_emploi"] = modif_tri_defaut_personnes(array("titre@@asc","titre@@desc","date_crea@@asc","date_crea@@desc"));
$objet["emploi_dossier"]	= array("type_objet"=>"emploi_dossier", "cle_id_objet"=>"id_dossier", "type_contenu"=>"emploi", "cle_id_contenu"=>"id_emploi", "table_objet"=>"gt_emploi_dossier");
$objet["emploi"]			= array("type_objet"=>"emploi", "cle_id_objet"=>"id_emploi", "type_conteneur"=>"emploi_dossier", "cle_id_conteneur"=>"id_dossier", "table_objet"=>"gt_emploi");
patch_dossier_racine($objet["emploi_dossier"]);


////	DROIT AJOUT ACTUALITE
////
function droit_ajout_emploi()
{
	if($_SESSION["user"]["id_utilisateur"]>0  and  (option_module("ajout_emploi_admin")!=true or $_SESSION["espace"]["droit_acces"]==2))  return true;
}


////	SUPPRESSION D'UN emploi
////
function suppr_emploi($id_emploi)
{
	global $objet;

	
	// On supprime l'objet en question
	if(droit_acces($objet["emploi"],$id_emploi) >= 2)	suppr_objet($objet["emploi"],$id_emploi);

}


////	SUPPRESSION D'UN DOSSIER
////
function suppr_emploi_dossier($id_dossier)
{
	global $objet;
	if(droit_acces($objet["emploi_dossier"],$id_dossier)==3 and $id_dossier > 1)
	{
		// on créé la liste des dossiers & on supprime chaque dossier
		$liste_dossiers_suppr = arborescence($objet["emploi_dossier"],$id_dossier,"tous");
		foreach($liste_dossiers_suppr as $infos_dossier)
		{
			// On supprime chaque emploi du dossier puis le dossier en question
			$liste_emplois = db_tableau("SELECT * FROM gt_emploi WHERE id_dossier='".$infos_dossier["id_dossier"]."' ");
			foreach($liste_emplois as $infos_emploi)	{ suppr_emploi($infos_emploi["id_emploi"]); }
			suppr_objet($objet["emploi_dossier"], $infos_dossier["id_dossier"]);
		}
	}
}


////	DEPLACEMENT D'UN emploi
////
function deplacer_emploi($id_emploi, $id_dossier_destination)
{
	global $objet;
	////	Accès en écriture au emploi et au dossier de destination
	if(droit_acces($objet["emploi"],$id_emploi)>=2  &&  droit_acces($objet["emploi_dossier"],$id_dossier_destination)>=2)
	{
		////	Deplace à la racine : donne les droits d'accès de l'ancien dossier
		racine_copie_droits_acces($objet["emploi"], $id_emploi, $objet["emploi_dossier"], $id_dossier_destination);
		////	On déplace le emploi
		db_query("UPDATE gt_emploi SET id_dossier=".db_format($id_dossier_destination)." WHERE id_emploi=".db_format($id_emploi));
	}
	////	Logs
	add_logs("modif", $objet["emploi"], $id_emploi);
}

////	DEPLACEMENT D'UN DOSSIER
////
function deplacer_emploi_dossier($id_dossier, $id_dossier_destination)
{
	global $objet;
	////	Accès total au dossier en question  &  accès en écriture au dossier destination  &  controle du déplacement du dossier
	if(droit_acces($objet["emploi_dossier"],$id_dossier)==3  and  droit_acces($objet["emploi_dossier"],$id_dossier_destination)>=2  and  controle_deplacement_dossier($objet["emploi_dossier"],$id_dossier,$id_dossier_destination)==1) {
		db_query("UPDATE gt_emploi_dossier SET id_dossier_parent='".db_format($id_dossier_destination)."' WHERE id_dossier=".db_format($id_dossier)." ");
	}
	add_logs("modif", $objet["emploi_dossier"], $id_dossier);
}


// transforme une date fr (jj/mm/aaaa) en date us (aaaa-mm-jj)
function versDateUS($madate)
{
	if ($madate!="")
	{
		$annee    = substr($madate, 6, 4);
		$mois    = substr($madate, 3, 2);
		$jour        = substr($madate, 0, 2);
		$nouv_date=$annee."-".$mois."-".$jour;
		return $nouv_date;
	}
	else
	{
		return "";
	}
}

// transforme une date us (aaaa-mm-jj) en date fr (jj/mm/aaaa)
function versDateFR($madate)
{
	if ($madate!="")
	{
		$annee    = substr($madate, 0, 4);
		$mois    = substr($madate, 5, 2);
		$jour        = substr($madate, 8, 2);
		$nouv_date=$jour."/".$mois."/".$annee;
		return $nouv_date;
	}
	else
	{
		return "";
	}
}



?>
