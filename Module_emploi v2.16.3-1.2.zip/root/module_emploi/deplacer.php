<?php
////	INITIALISATION
require "commun.inc.php";

////	ON DEPLACE PLUSIEURS ELEMENTS
foreach(request_elements($_POST["elements"],$objet["emploi"]) as $id_emploi)			{ deplacer_emploi($id_emploi, $_POST["id_dossier"]); }
foreach(request_elements($_POST["elements"],$objet["emploi_dossier"]) as $id_dossier)	{ deplacer_emploi_dossier($id_dossier, $_POST["id_dossier"]); }

////	DECONNEXION À LA BDD & FERMETURE DU POPUP
reload_close();
?>