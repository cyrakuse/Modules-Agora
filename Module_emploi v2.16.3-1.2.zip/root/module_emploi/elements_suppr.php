<?php
////	INITIALISATION
include "commun.inc.php";


////	SUPPRESSION DE DOSSIER / emploi / ELEMENTS
if(isset($_GET["id_dossier"]))		{ suppr_emploi_dossier($_GET["id_dossier"]); }
elseif(isset($_GET["id_emploi"]))	{ suppr_emploi($_GET["id_emploi"]); }
elseif(isset($_GET["elements"]))
{
	$liste_elements = explode("@@",$_GET["elements"]);
	foreach(request_elements($liste_elements,$objet["emploi"]) as $id_emploi)				{ suppr_emploi($id_emploi); }
	foreach(request_elements($liste_elements,$objet["emploi_dossier"]) as $id_dossier)		{ suppr_emploi_dossier($id_dossier); }
}

////	Redirection
redir("index.php?id_dossier=".$_GET["id_dossier_retour"]);
?>
