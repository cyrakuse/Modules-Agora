<?php
////	emploiS
$cfg_plugin["champs_recherche"] = array("titre","description");
$liste_emplois = db_tableau("SELECT DISTINCT * FROM gt_emploi WHERE ".sql_affichage_objets_arbo($objet["emploi"])." ".sql_selection_plugins($cfg_plugin)."  ORDER BY date_crea desc ");
foreach($liste_emplois as $emploi_tmp)
{
	$opener = ($cfg_plugin["mode"]=="recherche") ? ".opener" : "";
	$resultat_tmp = array("type"=>"elem", "module_dossier"=>$cfg_plugin["module_dossier"]);
	$resultat_tmp["lien_js_icone"] = "window".$opener.".location.replace('".ROOT_PATH.$cfg_plugin["module_dossier"]."/index.php?id_dossier=".$emploi_tmp["id_dossier"]."');";
	$resultat_tmp["lien_js_libelle"] = "popup('".ROOT_PATH.$cfg_plugin["module_dossier"]."/emploi.php?id_emploi=".$emploi_tmp["id_emploi"]."','emploi".$emploi_tmp["id_emploi"]."');";
	$resultat_tmp["libelle"] = "<span ".infobulle(chemin($objet["emploi_dossier"],$emploi_tmp["id_dossier"],"url_virtuelle")."<br />".$trad["divers"]["auteur"]." ".auteur($emploi_tmp["id_utilisateur"],$emploi_tmp["invite"])).">".$emploi_tmp["titre"]." "."</span>";
	$cfg_plugin["resultats"][] = $resultat_tmp;
}
////	DOSSIERS
$cfg_plugin["champs_recherche"] = array("nom","description");
$liste_dossiers	= db_tableau("SELECT * FROM gt_emploi_dossier WHERE 1 ".sql_affichage($objet["emploi_dossier"])." ".sql_selection_plugins($cfg_plugin)."  ORDER BY date_crea desc ");
foreach($liste_dossiers as $dossier_tmp)
{
	$resultat_tmp = array("type"=>"dossier", "module_dossier"=>$cfg_plugin["module_dossier"]);
	$resultat_tmp["lien_js_icone"] = "window.location.replace('".ROOT_PATH.$cfg_plugin["module_dossier"]."/index.php?id_dossier=".$dossier_tmp["id_dossier"]."');";
	$resultat_tmp["lien_js_libelle"] = $resultat_tmp["lien_js_icone"];
	$resultat_tmp["libelle"] = $dossier_tmp["nom"];
	$cfg_plugin["resultats"][] = $resultat_tmp;
}
?>
