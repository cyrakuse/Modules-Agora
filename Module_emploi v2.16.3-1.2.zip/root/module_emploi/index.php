<?php
////	INITIALISATION
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
$cpt_element = 0;
init_id_dossier();
$droit_acces_dossier = droit_acces_controler($objet["emploi_dossier"],$_GET["id_dossier"],1);
elements_width_height_type_affichage("medium","100px","bloc");
$version="2.16.3-1.2";
?>


<table id="contenu_principal_table"><tr>
	<td id="menu_gauche_block_td">
	<div id="menu_gauche_block_flottant">
		<div class="menu_gauche_block content">
			<?php
			////	MENU D'ARBORESCENCE
			$cfg_menu_arbo = array("objet"=>$objet["emploi_dossier"], "id_objet"=>$_GET["id_dossier"], "ajouter_dossier"=>"oui", "droit_acces_dossier"=>$droit_acces_dossier);
			include_once PATH_INC."menu_arborescence.inc.php";
			?>
		</div>
		<div class="menu_gauche_block content">
			<table width="100%">
			<?php
			
			////	AJOUTER emploi
			//if(droit_ajout_emploi()==true)
			//{
			//	echo "<tr class=\"lien\" onclick=\"edit_iframe_popup('emploi_edit.php?id_dossier=".$_GET["id_dossier"]."');\"><td class=\"left_menu_block_ico\"><img src=\"".PATH_TPL."divers/ajouter.png\" /></td><td class=\"left_menu_block_txt\">".$trad["EMPLOI_ajouter_emploi"]."</td></tr>";
			//	echo "<tr><td colspan='2'><hr /></td></tr>";
			//}
			if($droit_acces_dossier>=1.5)
			{
				echo "<div class='menu_gauche_ligne lien' onclick=\"edit_iframe_popup('emploi_edit.php?id_dossier=".$_GET["id_dossier"]."');\"><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/ajouter.png\" /></div><div class='menu_gauche_txt'>".$trad["EMPLOI_ajouter_emploi"]."</div></div>";
			}
			if ($_SESSION['user']['admin_general'] == 1)
			{
				echo "<tr class=\"menu_gauche_ligne lien\" ".infobulle($trad["EMPLOI_version"].$version)."><td class=\"menu_gauche_img\"><img src=\"".PATH_TPL."divers/info.png\" height=\"20px\" /></td><td class=\"menu_gauche_txt\">".$trad["EMPLOI_version"].$version."</a></td></tr>";
			}
			////	MENU ELEMENTS
			$cfg_menu_elements = array("objet"=>$objet["emploi"], "objet_dossier"=>$objet["emploi_dossier"], "id_objet_dossier"=>$_GET["id_dossier"], "droit_acces_dossier"=>$droit_acces_dossier);
			include PATH_INC."elements_menu_selection.inc.php";
			
			////	MENU D'AFFICHAGE  &  DE TRI  &  CONTENU DU DOSSIER
			echo menu_type_affichage();
			echo menu_tri($config["tri_emploi"]);
			echo contenu_dossier($objet["emploi_dossier"],$_GET["id_dossier"]);
			?>
			</table>
		</div>
	</div>
	</td>
	<td>
		<?php
		////	MENU CHEMIN + OBJETS_DOSSIERS
		////
		echo menu_chemin($objet["emploi_dossier"], $_GET["id_dossier"]);
		$cfg_dossiers = array("objet"=>$objet["emploi_dossier"], "id_objet"=>$_GET["id_dossier"]);
		include_once PATH_INC."dossiers.inc.php";

		////	LISTE DES emploiS
		////
		$liste_emplois = db_tableau("SELECT * FROM gt_emploi WHERE id_dossier='".$_GET["id_dossier"]."' ".sql_affichage($objet["emploi"],$_GET["id_dossier"])." ".tri_sql($config["tri_emploi"])." ");
		
		foreach($liste_emplois as $emploi_tmp)
		{
			////	INIT + LIEN POPUP
			$cpt_element++;
			$lien_popup = "onclick=\"popup('emploi.php?id_emploi=".$emploi_tmp["id_emploi"]."','aff_emploi".$emploi_tmp["id_emploi"]."');\" ";
			$src_photo  = PATH_TPL."module_emploi/inconnu.png";
			////	MODIF / SUPPR / INFOS / CREATION USER (admin général)
			$cfg_menu_elem = array("objet"=>$objet["emploi"], "objet_infos"=>$emploi_tmp, "fichiers_joint"=>"oui");
			$emploi_tmp["droit_acces"] = ($_GET["id_dossier"]>1) ? $droit_acces_dossier : droit_acces($objet["emploi"],$emploi_tmp);
			
			
			if($emploi_tmp["droit_acces"]>=2)	{
				$cfg_menu_elem["modif"] = "emploi_edit.php?id_emploi=".$emploi_tmp["id_emploi"];
				$cfg_menu_elem["deplacer"] = PATH_DIVERS."deplacer.php?module_dossier=".MODULE_DOSSIER."&type_objet_dossier=emploi_dossier&id_dossier_parent=".$_GET["id_dossier"]."&elements=emploi-".$emploi_tmp["id_emploi"];
				$cfg_menu_elem["suppr"] = "elements_suppr.php?id_emploi=".$emploi_tmp["id_emploi"]."&id_dossier_retour=".$_GET["id_dossier"];
			}
			
			
			

			$cfg_menu_elem["id_div_element"] = div_element($objet["emploi"], $emploi_tmp["id_emploi"]);
			////	AFFICHAGE BLOCK
			////
			if($_REQUEST["type_affichage"]=="bloc")
			{
				//echo div_element($objet["emploi"], $emploi_tmp["id_emploi"]);
					////	OPTIONS + DETAILS
					echo "<div class=\"div_element_options\">";  include PATH_INC."element_menu_contextuel.inc.php";  echo "</div>";
					echo "<div class=\"div_element_contenu\">";
						echo "<table class=\"div_element_table\"><tr>";
							echo "<td class=\"div_element_image lien\" ".$lien_popup." ><img src=\"".$src_photo."\" style=\"max-width:80px;max-height:80px;\" /></td>";
							echo "<td style=\"vertical-align:middle\">";
								echo "<div style=\"font-size:12px;\" class=\"lien\" ".$lien_popup.">".$emploi_tmp["titre"]."</div>";
								//echo "<span style=\"margin-bottom:5px;font-size:11px;line-height:15px;\" >";
								////	AUTEUR / DATE
							//$auteur_tmp = user_infos($emploi_tmp["id_utilisateur"]);
							//echo "<div style=\"margin-top:7px;\">".$trad["EMPLOI_date_creation"].temps($emploi_tmp["date_crea"]).", <br />".$trad["EMPLOI_par"].auteur($auteur_tmp,$emploi_tmp["invite"])."</div>";
							
								//echo "</span>";
							echo "</td>";
						echo "</tr></table>";
					echo "</div>";
				echo "</div>";
				
			}
			////	AFFICHAGE LISTE
			////
			else
			{
				//echo div_element($objet["emploi"], $emploi_tmp["id_emploi"]);
					echo "<div class=\"div_element_options\">";	include PATH_INC."element_menu_contextuel.inc.php"; echo "</div>";
					echo "<div class=\"div_element_contenu\" >";
						echo "<table class=\"div_element_table\"><tr>";
							echo "<td class=\"div_element_td lien\" style=\"width:70px;text-align:center;\" ".$lien_popup." ><img src=\"".$src_photo."\" style=\"max-width:70px;max-height:35px;\" /></td>";
							echo "<td class=\"div_element_td\"><span class=\"lien\" ".$lien_popup.">".$emploi_tmp["titre"]."</span></td>";
							//echo "<td class=\"div_element_td\" style=\"text-align:right;\">";
							////	AUTEUR / DATE
							//$auteur_tmp = user_infos($emploi_tmp["id_utilisateur"]);
							//echo "<div style=\"margin-top:7px;\">".$trad["EMPLOI_date_creation"].temps($emploi_tmp["date_crea"]).", <br />".$trad["EMPLOI_par"].auteur($auteur_tmp,$emploi_tmp["invite"])."</div>";
							
							//echo "</td>";
						echo "</tr></table>";
					echo "</div>";
				echo "</div>";
				echo "<br />";
			}
		}
		////	AUCUN emploi
		if(@$cpt_div_element<1)  echo "<div class='div_elem_aucun'>".$trad["EMPLOI_aucun_emploi"]."</div>";
		?>
	</td>
</tr></table>


<?php include_once PATH_INC."footer.inc.php"; ?>
