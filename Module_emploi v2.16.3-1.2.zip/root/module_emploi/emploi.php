<?php
////	INITIALISATION
////
define("is_main_page",false);
include "commun.inc.php";
include_once PATH_INC."header.inc.php";
$emploi_tmp = objet_infos($objet["emploi"], $_GET["id_emploi"]);
$droit_acces = droit_acces($objet["emploi"], $emploi_tmp, "lecture");


////	MODIFIER ?
if($droit_acces>=2)		echo "<span class=\"lien_select\" style=\"float:right;margin:10px;\" onClick=\"redir('emploi_edit.php?id_emploi=".$_GET["id_emploi"]."');\">".$trad["modifier"]." <img src=\"".PATH_TPL."divers/crayon.png\" /></span>";
?>


<script type="text/javascript">resize_iframe_popup(770,750);</script>
<style type="text/css">
body		{ background-image:url(<?php echo PATH_TPL; ?>module_emploi/fond_popup.png); }
.tab_user	{ width:100%; border-spacing:3px; font-weight:normal; }
.lib_user	{ width:200px; font-weight:bold; }
</style>


<table style="width:100%;height:300px;border-spacing:8px;"><tr>
	
	<td style="text-align:left;vertical-align:middle;">
		<table class="tab_user">
<?php
		////	INFOS SUR L'OFFRE
		////
		echo "<div style=\"font-size:14px;margin-bottom:10px;font-weight:bold;\">".$emploi_tmp["titre"]."</div>";
		echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."divers/carte.png\" /> ".$trad["EMPLOI_lieu"]." </td><td>".$emploi_tmp["lieu"]."</td></tr>";
		echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."module_emploi/contrat.png\" /> ".$trad["EMPLOI_contrat2"]." </td><td>".$emploi_tmp["contrat"]."</td></tr>";
		echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."module_emploi/date.png\" /> ".$trad["EMPLOI_date_debut2"]." </td><td>".versDateFR($emploi_tmp["date_debut"])."</td></tr>";
		echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."module_emploi/date.png\" /> ".$trad["EMPLOI_date_candidature2"]." </td><td>".versDateFR($emploi_tmp["date_candidature"])."</td></tr>";
		echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."divers/utilisateurs_small.png\" /> ".$trad["EMPLOI_contact"]." </td><td>".$emploi_tmp["contact"]."</td></tr>";
		echo "</table>";
		echo "<table class=\"tab_user\">";
		echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."divers/description.png\" /> ".$trad["EMPLOI_description"]." </td></tr>";
		echo "<tr><td>".$emploi_tmp["description"]."</td></tr>";
		echo "<tr><td></td></tr>";
		echo "<tr><td class=\"lib_user\"><img src=\"".PATH_TPL."module_utilisateurs/user_competences.png\" /> ".$trad["competences"]." </td></tr>";
		echo "<tr><td>".$emploi_tmp["competences"]."</td></tr>";
		
		
		
?>
		</table>
	</td>
</tr></table>


<?php
////	Fichiers joints + footer
affiche_fichiers_joints($objet["emploi"], $_GET["id_emploi"], "popup");
include_once PATH_INC."footer.inc.php";
?>
