<?php
////	INITIALISATION
require "commun.inc.php";
require_once PATH_INC."header.inc.php";
init_editeur_tinymce();
if(@$_REQUEST["id_emploi"]>0)	{ $emploi_tmp = objet_infos($objet["emploi"],$_REQUEST["id_emploi"]);   droit_acces($objet["emploi"],$emploi_tmp,1.5); }
else							{ $emploi_tmp["id_dossier"] = $_REQUEST["id_dossier"]; }









////	VALIDATION DU FORMULAIRE
////
if(isset($_POST["id_emploi"]))
{
	////	MODIF / AJOUT
	$corps_sql = " titre=".db_format($_POST["titre"]).", lieu=".db_format($_POST["lieu"]).", contrat=".db_format($_POST["contrat"]).", heure_hebdo=".db_format($_POST["heure_hebdo"]).", date_debut=".db_format(versDateUS($_POST["date_debut"])).", date_candidature=".db_format(versDateUS($_POST["date_candidature"])).", contact=".db_format($_POST["contact"]).", competences=".db_format($_POST["competences"],"editeur").",description=".db_format($_POST["description"],"editeur").", raccourci=".db_format(@$_POST["raccourci"],"bool")." ";
	if($_POST["id_emploi"] > 0)	
	{ 
		db_query("UPDATE gt_emploi SET ".$corps_sql." WHERE id_emploi=".$_POST["id_emploi"]." ");
		add_logs("modif", $objet["emploi"], $_POST["id_emploi"]);
	}
	else							
	{ 
		db_query("INSERT INTO gt_emploi SET id_dossier=".db_format($_POST["id_dossier"]).", id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."', invite=".db_format(@$_POST["invite"]).", date_crea='".db_insert_date()."', ".$corps_sql." ");   $_POST["id_emploi"] = db_last_id(); 
		add_logs("ajout", $objet["emploi"], $_POST["id_emploi"]);
	}

	////	AFFECTATION DES DROITS D'ACCÈS
	affecter_droits_acces($objet["emploi"],$_POST["id_emploi"]);

	////	AJOUTER FICHIERS JOINTS
	ajouter_fichiers_joint($objet["emploi"],$_POST["id_emploi"]);

	

	////	ENVOI DE NOTIFICATION PAR MAIL
	if(isset($_POST["notification"])) {
		$liste_id_destinataires = users_affectes($objet["emploi"], $_POST["id_emploi"]);
		$objet_mail = $trad["EMPLOI_mail_nouveau_emploi_cree"]." ".$_SESSION["user"]["nom"]." ".$_SESSION["user"]["prenom"];
		$contenu_mail = $_POST["code_asso"]." ".$_POST["nom"]." ".$_POST["prenom"];
		envoi_mail($liste_id_destinataires, $objet_mail, magicquotes_strip($contenu_mail));
	}

	////	FERMETURE DU POPUP
	reload_close();
}


////	EDITEUR TINYMCE
////
$cfg_inc["value_textarea"] = @$emploi_tmp["reponse"];
$cfg_inc["nom_textarea"] = "reponse";




?>


<script type="text/javascript">
////	Redimensionne
resize_iframe_popup(770,750);


</script>


<?php
////	FORMULAIRE PRINCIPAL
////
echo "<form action=\"".php_self()."\" method=\"post\" enctype=\"multipart/form-data\" style=\"padding:10px\" >";

	////	INFOS PRINCIPALES
	////
	echo "<fieldset style=\"margin-top:10px\">";
	echo "<table style=\"width:100%;\" cellpadding=\"3px\" cellspacing=\"0px\">";
	
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">".$trad["EMPLOI_titre"]."</td>";
		echo "<td><input type=\"text\" name=\"titre\" value=\"".@$emploi_tmp["titre"]."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">".$trad["EMPLOI_lieu"]."</td>";
		echo "<td><input type=\"text\" name=\"lieu\" value=\"".@$emploi_tmp["lieu"]."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">".$trad["EMPLOI_contrat"]."</td>";
		echo "<td><input type=\"text\" name=\"contrat\" value=\"".@$emploi_tmp["contrat"]."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">".$trad["EMPLOI_heure_hebdo"]."</td>";
		echo "<td><input type=\"text\" name=\"heure_hebdo\" value=\"".@$emploi_tmp["heure_hebdo"]."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">".$trad["EMPLOI_date_debut"]."</td>";
		echo "<td><input type=\"text\" name=\"date_debut\" value=\"".versDateFR(@$emploi_tmp["date_debut"])."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">".$trad["EMPLOI_date_candidature"]."</td>";
		echo "<td><input type=\"text\" name=\"date_candidature\" value=\"".versDateFR(@$emploi_tmp["date_candidature"])."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	
	
	
	echo "</table>";
	echo "<table style=\"width:100%;\" cellpadding=\"3px\" cellspacing=\"0px\">";
		echo "<tr><td>&nbsp;</td></tr>";
		echo "<tr><td class=\"form_libelle\">".$trad["EMPLOI_description"]."</td></tr>";
		echo"<tr><td>";
		echo "<textarea name=\"description\" id=\"description\" style=\"width:100%;height:250px;\">".@$emploi_tmp["description"]."</textarea>";
		echo "</td></tr>";
		echo "<tr><td>&nbsp;</td></tr>";
		echo "<tr><td class=\"form_libelle\">".$trad["EMPLOI_competences"]."</td></tr>";
		
		echo"<tr><td>";
		echo "<textarea name=\"competences\" id=\"competences\" style=\"width:100%;height:250px;\">".@$emploi_tmp["competences"]."</textarea>";
		echo "</td></tr>";
	echo "</table>";
	
	
	
	echo "<table style=\"width:100%;\" cellpadding=\"3px\" cellspacing=\"0px\">";
	echo "<tr><td>&nbsp;</td></tr>";
	echo "<tr>";
		echo "<td class=\"form_libelle\" style=\"width:40%;\">".$trad["EMPLOI_contact"]."</td>";
		echo "<td><input type=\"text\" name=\"contact\" value=\"".@$emploi_tmp["contact"]."\" style=\"width:100%;\" /></td>";
	echo "</tr>";
	echo "<tr><td>&nbsp;</td></tr>";
	echo "</table>";
	echo "</fieldset>";

	
	////	DROITS D'ACCES ET OPTIONS
	////
	$cfg_menu_edit = array("objet"=>$objet["emploi"], "id_objet"=>@$emploi_tmp["id_emploi"]);
	include_once PATH_INC."element_menu_edit.inc.php";
	?>

	<div style="text-align:right;margin-top:20px;">
		<input type="hidden" name="id_emploi" value="<?php echo @$emploi_tmp["id_emploi"]; ?>" />
		<input type="hidden" name="id_dossier" value="<?php echo $emploi_tmp["id_dossier"]; ?>" />
		<input type="submit" value="<?php echo $trad["valider"]; ?>" />
	</div>
</form>


<?php include_once PATH_INC."footer.inc.php"; ?>