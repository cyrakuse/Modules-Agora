<?php
////	Menu principal
$trad["EMPLOI_nom_module"] = "Offres d'emploi";
$trad["EMPLOI_nom_module_header"] = "Emploi";
$trad["EMPLOI_description_module"] = "Offres d'emploi";
$trad["EMPLOI_ajout_emploi_admin"] = "Seul l'administrateur peut ajouter des offres d'emploi";

////	Index.php
$trad["EMPLOI_ajouter_emploi"] = "Ajouter une offre d'emploi";
$trad["EMPLOI_aucun_emploi"] = "Aucune offre d'emploi pour le moment";
$trad["EMPLOI_creer_user"] = "Creer un utilisateur sur cet espace";
$trad["EMPLOI_creer_user_infos"] = "Créer un utilisateur sur cet espace à partir de cette association ?";
$trad["EMPLOI_creer_user_confirm"] = "L'utilisateur a été créé";
$trad["EMPLOI_emploi_importer"] = "Importer des associations";
$trad["EMPLOI_emploi_exporter"] = "Exporter les associations";
$trad["EMPLOI_droit_emploi"] = "Editer les droits d'accès";
$trad["EMPLOI_date_creation"] = "Créé le ";
$trad["EMPLOI_par"] = " Par ";


////	emploi_edit.php
$trad["EMPLOI_mail_nouveau_emploi_cree"] = "Nouvelle offre d'emploi créé par ";
$trad["EMPLOI_titre"]="Titre";
$trad["EMPLOI_lieu"]="Lieu de travail";
$trad["EMPLOI_contrat"]="Type de contrat (CDI, CDD...)";
$trad["EMPLOI_date_debut"]="Date d'embauche (jj/mm/aaaa)";
$trad["EMPLOI_date_candidature"]="Date limite pour postuler (jj/mm/aaaa)";
$trad["EMPLOI_description"]="Description du poste";
$trad["EMPLOI_competences"]="Compétences requises";
$trad["EMPLOI_contact"]="Personne à contacter";
$trad["EMPLOI_heure_hebdo"]="Nombre d'heures hebdomadaire";

//// champs
$trad["EMPLOI_question"] = "Question";
$trad["EMPLOI_reponse"] = "Réponse";

$trad["EMPLOI_horaire"] = "Horaires de permanence";


// Tri d'affichage. Tous les éléments (dossier, tâche, lien, etc...) ont par défaut une date, un auteur & une description
$trad["tri"]["question"] = "question";

////    module_edit.php
$trad["EMPLOI_gestion_acces"] = "Utilisateurs pouvant ajouter et modifer des questions";
$trad["EMPLOI_ecriture"] = "Ecriture";


// emploi.php
$trad["EMPLOI_contrat2"]="Type de contrat";
$trad["EMPLOI_date_debut2"]="Date d'embauche";
$trad["EMPLOI_date_candidature2"]="Date limite pour postuler";

$trad["EMPLOI_version"]="La version du module est : ";
?>
