<?php
////	INIT
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";



?>


<link href="datatables/page.css" rel="stylesheet" type="text/css" />
<link href="datatables/table.css" rel="stylesheet" type="text/css" />
<link href="datatables/theme.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="lib/js/jquery.min.js"></script>
<script src="lib/highcharts.js"></script>
<script type="text/javascript">
	var chart1; // globally available
	var chart2; // globally available
	var chart3; // globally available
	Highcharts.setOptions({
		lang: {
    		months: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'],
    		weekdays: ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
    		shortMonths: ['Jan', 'Fév', 'Mars', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sept', 'Oct', 'Nov', 'Déc']
		} 
	});
	$(document).ready(function() {
      	chart1 = new Highcharts.Chart({
         	chart: {
                renderTo: 'connexions',
                zoomType: 'x',
                spacingRight: 20
            },
         	title: {
            	text: 'Nombre de connexions'
         	},
         	subtitle: {
            	text: 'Si un utilisateur se connecte plusieurs fois, il est comptabilisé à chaque fois'
         	},
         	xAxis: {
            	type: 'datetime',
            	minRange: 2*24*3600000, // 2 jours
            	title: {
                	text: null
            	},
            	startOfWeek:1,
            	dateTimeLabelFormats: {
            		second: '%H:%M:%S',
					minute: '%H:%M',
					hour: '%H:%M',
					day: '%e. %b',
					week: '%e. %b',
					month: '%B %y',
					year: '%Y'
            	}
         	},
         	yAxis: {
            	title: {
                	text: 'Quantité'
            	},
            	showFirstLabel: false
         	},
         	legend: {
                enabled:false
            },
         	tooltip: {
            	xDateFormat: "le %d/%m/%Y à %H:00",
                shared: true
        	},
            series: [{
                type: 'line',
                name: 'Nombre de connexions',
                data: [
<?
	//extraction des données de connexion
	$connexions = db_tableau("SELECT DATE_FORMAT(date,'%Y,%c-1,%d,%H') as madate, count(date) as nbre FROM gt_logs WHERE action='connexion' group by madate");

	foreach($connexions as $connexion_tmp)
	{
		echo "[Date.UTC(".$connexion_tmp["madate"]."),".$connexion_tmp["nbre"]."],\n";
	}
?>
                ]
            }]
      	});
utilisateurs();

 	});


function utilisateurs()
{
	chart3 = new Highcharts.Chart({
         	chart: {
                renderTo: 'utilisateurs',
                zoomType: 'x',
                spacingRight: 20
            },
         	title: {
            	text: 'Nombre d\'utilisateurs utilisant réellement Agora'
         	},
         	subtitle: {
            	text: 'Chaque utilisateur n\'est comptabilisé qu\'une seule fois par heure même s\'il se connecte plusieurs fois durant cette heure'
         	},
         	xAxis: {
            	type: 'datetime',
            	minRange: 2*24*3600000, // 2 jours
            	title: {
                	text: null
            	},
            	startOfWeek:1,
            	dateTimeLabelFormats: {
            		second: '%H:%M:%S',
					minute: '%H:%M',
					hour: '%H:%M',
					day: '%e. %b',
					week: '%e. %b',
					month: '%b \'%y',
					year: '%Y'
            	}
         	},
         	yAxis: {
            	title: {
                	text: 'Quantité'
            	},
            	showFirstLabel: false
         	},
         	legend: {
                enabled:false
            },
         	tooltip: {
            	xDateFormat: "le %d/%m/%Y à %H:00",
                shared: true
        	},
            series: [{
            	type:'line',
            	name: 'Nombre d\'utilisateurs',
            	data: [
<?
	//extraction des données des utilisateurs
	$connexions = db_tableau("SELECT DATE_FORMAT(date,'%Y,%c-1,%d,%H') as madate, count(distinct id_utilisateur) as nbre FROM gt_logs group by madate");

	foreach($connexions as $connexion_tmp)
	{
		echo "[Date.UTC(".$connexion_tmp["madate"]."),".$connexion_tmp["nbre"]."],\n";
	}
?>
            	]
            }]
      	});
espaces();
}


function espaces()
{
	chart3 = new Highcharts.Chart({
         	chart: {
                renderTo: 'espaces',
                zoomType: 'x',
                spacingRight: 20
            },
         	title: {
            	text: 'Nombres de téléchargements et de consultations par espaces'
         	},
         	subtitle: {
            	text: 'Ce graphique comptabilise les consultations et les téléchargements pour chaque espace'
         	},
         	xAxis: {
            	type: 'datetime',
            	minRange: 2*24*3600000, // 2 jours
            	title: {
                	text: null
            	},
            	startOfWeek:1,
            	dateTimeLabelFormats: {
            		second: '%H:%M:%S',
					minute: '%H:%M',
					hour: '%H:%M',
					day: '%e. %b',
					week: '%e. %b',
					month: '%b \'%y',
					year: '%Y'
            	}
         	},
         	yAxis: {
            	title: {
                	text: 'Quantité'
            	},
            	showFirstLabel: false
         	},
         	legend: {
                enabled:true
            },
         	tooltip: {
            	xDateFormat: "le %d/%m/%Y à %H:00",
                shared: true
        	},
        	series: [
<?
	$espaces = db_tableau("SELECT * FROM gt_espace");
	foreach($espaces as $espace_tmp)
	{
		echo "{\ntype:'line',\nname: '".addslashes($espace_tmp["nom"])."',\ndata: [";

		//extraction des données des espaces
		$connexions = db_tableau("SELECT DATE_FORMAT(date,'%Y,%c-1,%d,%H') as madate, count(distinct date) as nbre FROM gt_logs where id_espace=".$espace_tmp["id_espace"]." and action='consult' or action='consult2' group by madate");

		foreach($connexions as $connexion_tmp)
		{
			echo "[Date.UTC(".$connexion_tmp["madate"]."),".$connexion_tmp["nbre"]."],\n";
		}
		echo "]\n},\n";
	}
?>
        
            ]
      	});
modifs();
}
function modifs()
{
    chart4 = new Highcharts.Chart({
            chart: {
                renderTo: 'modif',
                zoomType: 'x',
                spacingRight: 20
            },
            title: {
                text: 'Nombres de modifications et de créations par espaces'
            },
            subtitle: {
                text: 'Ce graphique comptabilise les créations et modifications de contenu pour chaque espace'
            },
            xAxis: {
                type: 'datetime',
                minRange: 2*24*3600000, // 2 jours
                title: {
                    text: null
                },
                startOfWeek:1,
                dateTimeLabelFormats: {
                    second: '%H:%M:%S',
                    minute: '%H:%M',
                    hour: '%H:%M',
                    day: '%e. %b',
                    week: '%e. %b',
                    month: '%b \'%y',
                    year: '%Y'
                }
            },
            yAxis: {
                title: {
                    text: 'Quantité'
                },
                showFirstLabel: false
            },
            legend: {
                enabled:true
            },
            tooltip: {
                xDateFormat: "le %d/%m/%Y à %H:00",
                shared: true
            },
            series: [
<?
    $espaces = db_tableau("SELECT * FROM gt_espace");
    foreach($espaces as $espace_tmp)
    {
        echo "{\ntype:'line',\nname: '".addslashes($espace_tmp["nom"])."',\ndata: [";

        //extraction des données des espaces
        $connexions = db_tableau("SELECT DATE_FORMAT(date,'%Y,%m-1,%d,%H') as madate, count(distinct date) as nbre FROM gt_logs where id_espace=".$espace_tmp["id_espace"]." and action='ajout' or action='modif' or action='suppr' group by madate");

        foreach($connexions as $connexion_tmp)
        {
            echo "[Date.UTC(".$connexion_tmp["madate"]."),".$connexion_tmp["nbre"]."],\n";
        }
        echo "]\n},\n";
    }
?>
        
            ]
        });
module();
}
function module()
{
    chart5 = new Highcharts.Chart({
            chart: {
                renderTo: 'module',
                zoomType: 'x',
                spacingRight: 20
            },
            title: {
                text: 'Nombres d\'actions par module'
            },
            subtitle: {
                text: 'Ce graphique comptabilise l\'ensemble des actions pour chacun des modules'
            },
            xAxis: {
                type: 'datetime',
                minRange: 2*24*3600000, // 2 jours
                title: {
                    text: null
                },
                startOfWeek:1,
                dateTimeLabelFormats: {
                    second: '%H:%M:%S',
                    minute: '%H:%M',
                    hour: '%H:%M',
                    day: '%e. %b',
                    week: '%e. %b',
                    month: '%b \'%y',
                    year: '%Y'
                }
            },
            yAxis: {
                title: {
                    text: 'Quantité'
                },
                showFirstLabel: false
            },
            legend: {
                enabled:true
            },
            tooltip: {
                xDateFormat: "le %d/%m/%Y à %H:00",
                shared: true
            },
            series: [
<?
    $espaces = db_tableau("SELECT * FROM gt_module");
    foreach($espaces as $espace_tmp)
    {
        echo "{\ntype:'line',\nname: '".$espace_tmp["nom"]."',\ndata: [";

        //extraction des données des espaces
        $connexions = db_tableau("SELECT DATE_FORMAT(date,'%Y,%m-1,%d,%H') as madate, count(distinct date) as nbre FROM gt_logs where module='".$espace_tmp["nom"]."' group by madate");

        foreach($connexions as $connexion_tmp)
        {
            echo "[Date.UTC(".$connexion_tmp["madate"]."),".$connexion_tmp["nbre"]."],\n";
        }
        echo "]\n},\n";
    }
?>
        
            ]
        });
}
</script>


<div class="contenu_principal_centre" style="<?php echo STYLE_SHADOW_FORT; ?>">
    <table class="div_elem_deselect" style="width:100%;margin-top:10px;margin-bottom:20px;font-weight:bold" cellpadding="5px">
        <tr>
            <td>
                <div style="width:100%;text-align:center;font-family:'Lucida Grande', 'Lucida Sans Unicode', Verdana, Arial, Helvetica, sans-serif;font-size:16px;color:#3E576F;fill:#3E576F;">Statistiques</div>
                <div style="width:100%;text-align:center;font-family:'Lucida Grande', 'Lucida Sans Unicode', Verdana, Arial, Helvetica, sans-serif;font-size:12px;color:#6D869F;fill:#6D869F;">Ces statistiques sont établies à partir des Logs</div>
            </td>
        </tr>
    </table>
</div>
<div class="contenu_principal_centre" style="<?php echo STYLE_SHADOW_FORT; ?>">
	<table class="div_elem_deselect" style="width:100%;margin-top:10px;margin-bottom:20px;font-weight:bold" cellpadding="5px">
		<tr>
			<td id="connexions">
				
			</td>
		</tr>
	</table>
</div>
<div class="contenu_principal_centre" style="<?php echo STYLE_SHADOW_FORT; ?>">
	<table class="div_elem_deselect" style="width:100%;margin-top:10px;margin-bottom:20px;font-weight:bold" cellpadding="5px">
		<tr>
			<td id="utilisateurs">
				
			</td>
		</tr>
	</table>
</div>
<div class="contenu_principal_centre" style="<?php echo STYLE_SHADOW_FORT; ?>">
	<table class="div_elem_deselect" style="width:100%;margin-top:10px;margin-bottom:20px;font-weight:bold" cellpadding="5px">
		<tr>
			<td id="espaces">
				
			</td>
		</tr>
	</table>
</div>
<div class="contenu_principal_centre" style="<?php echo STYLE_SHADOW_FORT; ?>">
    <table class="div_elem_deselect" style="width:100%;margin-top:10px;margin-bottom:20px;font-weight:bold" cellpadding="5px">
        <tr>
            <td id="modif">
                
            </td>
        </tr>
    </table>
</div>
<div class="contenu_principal_centre" style="<?php echo STYLE_SHADOW_FORT; ?>">
    <table class="div_elem_deselect" style="width:100%;margin-top:10px;margin-bottom:20px;font-weight:bold" cellpadding="5px">
        <tr>
            <td id="module">
                
            </td>
        </tr>
    </table>
</div>
<?php require PATH_INC."footer.inc.php"; ?>