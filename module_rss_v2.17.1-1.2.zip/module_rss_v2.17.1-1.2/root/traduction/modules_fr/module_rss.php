<?php
////	MODULE_RSS
////

// Menu principal
$trad["RSS_nom_module"] = "Flux RSS";
$trad["RSS_nom_module_header"] = "Flux RSS";
$trad["RSS_description_module"] = "Flux RSS";
//$trad["RSS_masquer_websnapr"] = "Ne pas afficher la prévisualisation des sites (vignettes)";
// Index.php
$trad["RSS_ajouter_rss"] = "Ajouter un flux RSS";
$trad["RSS_editer_rss"] = "Modifier le flux RSS";
$trad["RSS_erreur"] = "FLUX RSS NON VALIDE !";
$trad["RSS_xml_erreur"] = "Erreur de copie du fichier XML dans le dossier rss !";
$trad["RSS_aucun_rss"] = "Aucun flux RSS pour le moment";
$trad["RSS_voir_en ligne"] = "Voir en ligne";

// RSS_edit.php & dossier_edit.php
$trad["RSS_adresse"] = "Adresse du flux";
$trad["RSS_specifier_adresse"] = "Merci de spécifier une adresse";
$trad["RSS_description"] = "Merci de spécifier une description";
$trad["RSS_mail_nouveau_rss_cree"] = "Nouveau flux RSS créé par ";
$trad["RSS_non_valide1"] = "Ce flux RSS/ATOM ne semble pas valide ! (W3c).";
$trad["RSS_non_valide2"] = "Continuez quand même ?";
?>
