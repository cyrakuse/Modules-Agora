<?php
////	INIT
require "commun.inc.php";
require_once PATH_INC."header.inc.php";
if(@$_REQUEST["id_rss"]>0)		{ $rss_tmp = objet_infos($objet["rss"],$_REQUEST["id_rss"]);  droit_acces_controler($objet["rss"], $rss_tmp, 1.5); }
else							{ $rss_tmp = array("id_dossier"=> $_REQUEST["id_dossier"], "adresse"=>"http://"); }


////	VALIDATION DU FORMULAIRE
////
if(isset($_POST["id_rss"]))
{
	////	MODIF / AJOUT
	$corps_sql = " adresse=".db_format($_POST["adresse"]).", description=".db_format($_POST["description"]).", raccourci=".db_format(@$_POST["raccourci"],"bool")." "; 
	if($_POST["id_rss"] > 0){
		db_query("UPDATE gt_rss SET ".$corps_sql." WHERE id_rss=".db_format($_POST["id_rss"]));
		add_logs("modif", $objet["rss"], $_POST["id_rss"]);
	}
	else{
		db_query("INSERT INTO gt_rss SET id_dossier=".db_format($_POST["id_dossier"]).", date_crea= NOW(), id_utilisateur='".$_SESSION["user"]["id_utilisateur"]."', invite=".db_format(@$_POST["invite"]).", ".$corps_sql);
		$_POST["id_rss"] = db_last_id();
		add_logs("ajout", $objet["rss"], $_POST["id_rss"]);
	}

	////	AFFECTATION DES DROITS D'ACCÈS  +  AJOUT FICHIERS JOINTS
	affecter_droits_acces($objet["rss"],$_POST["id_rss"]);
	ajouter_fichiers_joint($objet["rss"],$_POST["id_rss"]);

	////	ENVOI DE NOTIFICATION PAR MAIL
	if(isset($_POST["notification"]))
	{
		$liste_id_destinataires = users_affectes($objet["rss"], $_POST["id_rss"]);
		$objet_mail = $trad["RSS_mail_nouveau_rss_cree"]." ".$_SESSION["user"]["nom"]." ".$_SESSION["user"]["prenom"];
		$contenu_mail = "<a href=\"".$_POST["adresse"]."\" target=\"_blank\">".$_POST["adresse"]."</a>";
		if($_POST["description"]!="")	{ $contenu_mail .= "<br /><br />".$_POST["description"]; }
		envoi_mail($liste_id_destinataires, $objet_mail, magicquotes_strip($contenu_mail), array("notif"=>true));
	}

	////	FERMETURE DU POPUP
	reload_close();
}
?>

<style type="text/css">  body {  background-image:url('<?php echo PATH_TPL; ?>module_rss/fond_popup.png');  }  </style>
<script type="text/javascript">
////	Redimensionne
resizePopup(650,<?php echo ($rss_tmp["id_dossier"]==1)?"500":"300"; ?>);

////	CONTROLE VALIDATION FINALE
function controle_formulaire()
{
	// Il doit y avoir une adresse & une description
	if(get_value("adresse").length==0){
		alert("<?php echo $trad["RSS_specifier_adresse"]; ?>");
		return false;
	}
	if(get_value("description").length==0){
		alert("<?php echo $trad["RSS_description"]; ?>");
		return false;
	}
	
	// Controle le nombre de groupes et d'utilisateurs
	if(Controle_Menu_Objet()==false)	return false;
	
	// Controle la validité du flux RSS
	var flux = get_value("adresse");
	requete_ajax("w3c_feed_validator.php?flux="+flux);
	var RSS_W3C = Http_Request_Result;
	if (RSS_W3C == 0)
	{
		var answer = confirm("<?php echo $trad["RSS_non_valide1"]; ?>\n<?php echo $trad["RSS_non_valide2"]; ?>");
		if (answer)
		{return true;}
		else
		{return false;}
	}
}
</script>


<form action="<?php echo php_self(); ?>" method="post" enctype="multipart/form-data" OnSubmit="return controle_formulaire();" style="padding:10px;font-weight:bold;">

	<?php
	////	URL & DESCRIPTION
	echo "<fieldset>";
		echo $trad["rss_adresse"]." <input type=\"text\" name=\"adresse\" id=\"adresse\" value=\"".$rss_tmp["adresse"]."\" style=\"width:400px\" /><br /><br />";
		echo $trad["description"]."<br /><textarea name=\"description\" id=\"description\" style=\"width:98%;height:40px;\">".@$rss_tmp["description"]."</textarea>";
	echo "</fieldset>";

	////	DROITS D'ACCES ET OPTIONS
	$cfg_menu_edit = array("objet"=>$objet["rss"], "id_objet"=>@$rss_tmp["id_rss"]);
	require_once PATH_INC."element_menu_edit.inc.php";
	?>

	<div style="text-align:right;margin-top:20px;">
		<input type="hidden" name="id_rss" value="<?php echo @$rss_tmp["id_rss"]; ?>" />
		<input type="hidden" name="id_dossier" value="<?php echo $rss_tmp["id_dossier"]; ?>" />
		<input type="submit" value="<?php echo $trad["valider"]; ?>" class="button_big" />
	</div>

</form>


<?php require PATH_INC."footer.inc.php"; ?>
