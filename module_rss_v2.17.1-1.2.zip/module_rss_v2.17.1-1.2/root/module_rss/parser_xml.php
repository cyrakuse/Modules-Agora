<?php
function parseRSS($xml)
{
	$cnt = count($xml->channel->item);
	for($i=0; $i<$cnt; $i++)
	{
		$site = $xml->channel->title;
		$url = $xml->channel->link;
		$link = $xml->channel->item[$i]->link;
		$title = $xml->channel->item[$i]->title;
		//$desc = $xml->channel->item[$i]->description;
		if ($i == 0)
		{
			echo '<a style=color:red; target=_blank href ='.$url.' onMouseMove=pas_propager_click(this); '.infobulle($trad["RSS_voir_en ligne"]).'>'.$site.'</a><br /><br />';
		}
		echo "<li style=\"text-align:left;margin-left:40px;list-style-image:url(".PATH_TPL."divers/fleche_droite.png);\" class=\"lien\"><a href =".$link." target=\"_blank\" onMouseMove=\"pas_propager_click(this);\" ".infobulle($trad["RSS_voir_en ligne"]).">".$title."</a></li><br />";
	}
}

function parseAtom($xml)
{
	$cnt = count($xml->entry);
	for($i=0; $i<$cnt; $i++)
	{
		$site = $xml->title;
		$url_site = $xml->link[1]->attributes();
		$url = $url_site['href'];
		$urlAtt = $xml->entry[$i]->link->attributes();
		$link = $urlAtt['href'];
		$title = $xml->entry[$i]->title;
		//$desc = strip_tags($xml->entry->content);
		if ($i == 0)
		{
			echo '<a style=color:red; target=_blank href ='.$url.' onMouseMove=pas_propager_click(this); '.infobulle($trad["RSS_voir_en ligne"]).'>'.$site.'</a><br /><br />';
		}
		echo "<li style=\"text-align:left;margin-left:40px;list-style-image:url(".PATH_TPL."divers/fleche_droite.png);\" class=\"lien\"><a href =".$link." target=\"_blank\" onMouseMove=\"pas_propager_click(this);\" ".infobulle($trad["RSS_voir_en ligne"]).">".$title."</a></li><br />";
	}
}