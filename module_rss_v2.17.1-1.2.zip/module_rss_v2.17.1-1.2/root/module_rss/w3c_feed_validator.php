<?php
//// TEST DE FLUX AVEC W3C
////

function validateFeed($sFeedURL)
{

    $sValidator = 'http://validator.w3.org/appc/check.cgi?url=';
    
    if( $sValidationResponse = @file_get_contents($sValidator . urlencode($sFeedURL)) )
    {
        if( stristr( $sValidationResponse , 'Congratulations!' ) !== false )
        {
        	echo "1";
        }
        else
        {
      	echo "0";
        }
    }
    else
    {
   		echo "0";
    }
}

validateFeed($_GET["flux"])
?>