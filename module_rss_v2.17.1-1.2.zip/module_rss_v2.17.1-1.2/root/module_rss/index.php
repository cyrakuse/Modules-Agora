<?php
////	INIT
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
	
init_id_dossier();
$droit_acces_dossier = droit_acces_controler($objet["rss_dossier"], $_GET["id_dossier"], 1);
?>


<table id="contenu_principal_table"><tr>
	<td id="menu_gauche_block_td">
		<div id="menu_gauche_block_flottant">
			<div class="menu_gauche_block content">
				<?php
				////	MENU D'ARBORESCENCE
				$cfg_menu_arbo = array("objet"=>$objet["rss_dossier"], "id_objet"=>$_GET["id_dossier"], "ajouter_dossier"=>true, "droit_acces_dossier"=>$droit_acces_dossier);
				require_once PATH_INC."menu_arborescence.inc.php";
				?>
			</div>
			<div class="menu_gauche_block content">
				<?php
				////	AJOUTER rss
				if($droit_acces_dossier>=1.5)	echo "<div class='menu_gauche_ligne lien' onclick=\"popupLightbox('rss_edit.php?id_dossier=".$_GET["id_dossier"]."');\"><div class='menu_gauche_img'><img src=\"".PATH_TPL."divers/ajouter.png\" /></div><div class='menu_gauche_txt'>".$trad["RSS_ajouter_rss"]."</div></div><hr />";
				////	MENU ELEMENTS
				$cfg_menu_elements = array("objet"=>$objet["rss"], "objet_dossier"=>$objet["rss_dossier"], "id_objet_dossier"=>$_GET["id_dossier"], "droit_acces_dossier"=>$droit_acces_dossier);
				require PATH_INC."elements_menu_selection.inc.php";
				////	MENU D'AFFICHAGE  &  DE TRI  &  CONTENU DU DOSSIER
				//echo menu_type_affichage();
				echo menu_tri($objet["rss"]["tri"]);
				echo contenu_dossier($objet["rss_dossier"],$_GET["id_dossier"]);
				?>
			</div>
		</div>
	</td>
	<td>
		<?php
		////	MENU CHEMIN + OBJETS_DOSSIERS
		////
		elements_width_height_type_affichage("large","63px","bloc");
		echo menu_chemin($objet["rss_dossier"], $_GET["id_dossier"]);
		$cfg_dossiers = array("objet"=>$objet["rss_dossier"], "id_objet"=>$_GET["id_dossier"]);
		require_once PATH_INC."dossiers.inc.php";
		
		elements_width_height_type_affichage("large","220px","bloc");
		///	LISTE DES RSS
		////
		$liste_rss = db_tableau("SELECT * FROM gt_rss WHERE id_dossier='".intval($_GET["id_dossier"])."' ".sql_affichage($objet["rss"],$_GET["id_dossier"])." ".tri_sql($objet["rss"]["tri"]));
		
		/// LECTEUR DE FLUX ATOM/RSS
		require "parser_xml.php";
		
		/// SELECTION ET AFFICHAGE
		foreach($liste_rss as $rss_tmp)
		{
			////	INFOS / MODIF / SUPPR
			$cfg_menu_elem = array("objet"=>$objet["rss"], "objet_infos"=>$rss_tmp);
			
			
			$rss_tmp["droit_acces"] = ($_GET["id_dossier"]>1)  ?  $droit_acces_dossier  :  droit_acces($objet["rss"],$rss_tmp);
			if($rss_tmp["droit_acces"]>=2)	{
				$cfg_menu_elem["modif"] = "rss_edit.php?id_rss=".$rss_tmp["id_rss"];
				$cfg_menu_elem["deplacer"] = PATH_DIVERS."deplacer.php?module_dossier=".MODULE_DOSSIER."&type_objet_dossier=rss_dossier&id_dossier_parent=".$_GET["id_dossier"]."&elements=rss-".$rss_tmp["id_rss"];
				$cfg_menu_elem["suppr"] = "elements_suppr.php?id_rss=".$rss_tmp["id_rss"]."&id_dossier_retour=".$_GET["id_dossier"];
			}
			//// LIBELLE
			if($rss_tmp["droit_acces"]>=2)	
			{
			$libelle = "<p style=\"cursor:pointer;text-align:center;\" onclick=\"popupLightbox('rss_edit.php?id_rss=".$rss_tmp["id_rss"]."');\" onMouseMove='pas_propager_click(this);' ".infobulle($trad["RSS_editer_rss"]).">".text_reduit(($rss_tmp["description"]!=""?$rss_tmp["description"]:$rss_tmp["adresse"]),60)."</p>";
			}
			else 
			{
			$libelle = "<p style=\"text-align:center;\">".text_reduit(($rss_tmp["description"]!=""?$rss_tmp["description"]:$rss_tmp["adresse"]),60)."</u>";
			}				
			
			//// COPIE DU FLUX RSS DANS LE DOSSIER RSS
			$name_xml = "".$rss_tmp["id_rss"].".xml";
			$xml_tmp = @file_get_contents(''.$rss_tmp["adresse"].''); // your file is in the string "$xml" now.
			$file_xml = @file_put_contents("rss/".$name_xml."", $xml_tmp); // now your xml file is saved.
			
		   	//// CHARGEMENT DU FICHIER
			if ($file_xml)
			{
			  $simplexml = @simplexml_load_file('rss/'.$name_xml.'');
			}
			else
			{
			  alert($trad["RSS_xml_erreur"]);
			}
					
			
			////	DIV SELECTIONNABLE + OPTIONS
			$cfg_menu_elem["id_div_element"] = div_element($objet["rss"], $rss_tmp["id_rss"]);
			require PATH_INC."element_menu_contextuel.inc.php";
				////	AFFICHAGE BLOCK
				echo "<div class='div_elem_contenu' style='overflow:auto;background-image:url(".PATH_TPL."module_rss/fond_element.png);'>";
				echo "<table class='table_nospace' cellpadding='0' cellspacing='0' style='width:100%;height:".$height_element.";'><tr>";
				echo "<td class='div_elem_td' style='vertical-align:top'><br />".$libelle."";
				echo '<hr>';
			
			echo '<ul>';

			if($simplexml) 
			{			
			  if(isset($simplexml->channel)) {parseRSS($simplexml);};
			  if(isset($simplexml->entry)) {parseAtom($simplexml);}
			}
			else 
			{
			echo '<b style=color:red>'.$trad["RSS_erreur"].'</b>';
			}
				
			echo '</ul></td>';
			echo "</tr></table>";
			echo "</div>";
			echo "</div>";
			
		}
		////	AUCUN rss
		if(@$cpt_div_element<1)  echo "<div class='div_elem_aucun'>".$trad["RSS_aucun_rss"]."</div>";
		?>
	</td>
</tr></table>


<?php require PATH_INC."footer.inc.php"; ?>