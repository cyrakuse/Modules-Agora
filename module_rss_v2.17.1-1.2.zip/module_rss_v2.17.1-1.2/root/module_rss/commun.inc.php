<?php
////	INIT
@define("MODULE_NOM","rss");
@define("MODULE_PATH","module_rss");
require_once "../includes/global.inc.php";

$objet["rss_dossier"]	= array("type_objet"=>"rss_dossier", "cle_id_objet"=>"id_dossier", "type_contenu"=>"rss", "cle_id_contenu"=>"id_rss", "table_objet"=>"gt_rss_dossier");
$objet["rss"]			= array("type_objet"=>"rss", "cle_id_objet"=>"id_rss", "type_conteneur"=>"rss_dossier", "cle_id_conteneur"=>"id_dossier", "table_objet"=>"gt_rss");
$objet["rss_dossier"]["champs_recherche"]	= array("nom","description");
$objet["rss"]["champs_recherche"]			= array("adresse","description");
$objet["rss"]["tri"]		= array("date_crea@@desc","date_crea@@asc","date_modif@@desc","date_modif@@asc","id_utilisateur@@asc","id_utilisateur@@desc","description@@asc","description@@desc","adresse@@asc","adresse@@desc");
patch_dossier_racine($objet["rss_dossier"]);


////	SUPPRESSION D'UN rss
////
function suppr_rss($id_rss)
{
	global $objet;
	if(droit_acces($objet["rss"],$id_rss) >= 2)
	{
	  suppr_objet($objet["rss"], $id_rss);
	  unlink("rss/".$id_rss.".xml");
	}
}


////	SUPPRESSION D'UN DOSSIER
////
function suppr_rss_dossier($id_dossier)
{
	global $objet;
	if(droit_acces($objet["rss_dossier"],$id_dossier)==3 && $id_dossier>1)
	{
		// on créé la liste des dossiers & on supprime chaque dossier
		$liste_dossiers_suppr = arborescence($objet["rss_dossier"], $id_dossier, "tous");
		foreach($liste_dossiers_suppr as $dossier_tmp)
		{
			// On supprime chaque rss du dossier puis le dossier en question
			$liste_rss = db_tableau("SELECT * FROM gt_rss WHERE id_dossier='".$dossier_tmp["id_dossier"]."'");
			foreach($liste_rss as $infos_rss)	{ suppr_rss($infos_rss["id_rss"]); }
			suppr_objet($objet["rss_dossier"], $dossier_tmp["id_dossier"]);
		}
	}
}


////	DEPLACEMENT D'UN rss
////
function deplacer_rss($id_rss, $id_dossier_destination)
{
	global $objet;
	////	Accès en écriture au rss et au dossier de destination
	if(droit_acces($objet["rss"],$id_rss)>=2  &&  droit_acces($objet["rss_dossier"],$id_dossier_destination)>=2)
	{
		////	Si on deplace à la racine, on donne les droits d'accès de l'ancien dossier
		racine_copie_droits_acces($objet["rss"], $id_rss, $objet["rss_dossier"], $id_dossier_destination);
		////	On déplace le rss
		db_query("UPDATE gt_rss SET id_dossier=".db_format($id_dossier_destination)." WHERE id_rss=".db_format($id_rss));
	}
	////	Logs
	add_logs("modif", $objet["rss"], $id_rss);
}


////	DEPLACEMENT D'UN DOSSIER
////
function deplacer_rss_dossier($id_dossier, $id_dossier_destination)
{
	global $objet;
	////	Accès total au dossier en question  &  accès en écriture au dossier destination  &  controle du déplacement du dossier
	if(droit_acces($objet["rss_dossier"],$id_dossier)==3  &&  droit_acces($objet["rss_dossier"],$id_dossier_destination)>=2  &&  controle_deplacement_dossier($objet["rss_dossier"],$id_dossier,$id_dossier_destination)==1) {
		db_query("UPDATE gt_rss_dossier SET id_dossier_parent=".db_format($id_dossier_destination)." WHERE id_dossier=".db_format($id_dossier));
	}
	////	Logs
	add_logs("modif", $objet["rss_dossier"], $id_dossier);
}
?>