<?php
////	INITIALISATION
////
$version = "2.17.1-1.2";
$nom_module ="rss";
define("IS_MAIN_PAGE",true);
require "commun.inc.php";
require PATH_INC."header_menu.inc.php";
require_once PATH_INC."header.inc.php";

//// Vérification admin
if ($_SESSION['user']['admin_general'] == 1)
{
  //// Test la présence du module 
  $test = 0;
  $test_module = db_tableau("SELECT * FROM gt_module");
  foreach ($test_module as $module)
  {
	if ($module["nom"] == "rss")
	{$test = 1;}
  }

  if ($test == 0)
  {
  	
  alert("Installation du module ".$nom_module." en version ".$version.".");
  	
  ////  Structure de la table `gt_rss`
  db_query("CREATE TABLE `gt_rss` (
  `id_rss` int(10) unsigned NOT NULL auto_increment,
  `id_dossier` int(10) unsigned NOT NULL default '0',
  `adresse` text,
  `description` text,
  `raccourci` tinyint(4) default NULL,
  `date_crea` datetime default NULL,
  `id_utilisateur` int(10) unsigned default NULL,
  `invite` tinytext,
  `date_modif` datetime default NULL,
  `id_utilisateur_modif` int(10) unsigned default NULL,
  PRIMARY KEY  (`id_rss`,`id_dossier`)
	) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 AUTO_INCREMENT=72");
	
  //// Structure de la table `gt_rss_dossier`
  db_query("CREATE TABLE `gt_rss_dossier` (
  `id_dossier` int(10) unsigned NOT NULL auto_increment,
  `id_dossier_parent` int(10) unsigned NOT NULL default '0',
  `nom` tinytext,
  `description` text,
  `raccourci` tinyint(4) default NULL,
  `date_crea` datetime default NULL,
  `id_utilisateur` int(10) unsigned default NULL,
  `invite` tinytext,
  `date_modif` datetime default NULL,
  `id_utilisateur_modif` int(10) unsigned default NULL,
  PRIMARY KEY  (`id_dossier`,`id_dossier_parent`)
	) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 AUTO_INCREMENT=33");
	
  //// Activation du module dans agora
  db_query ("INSERT INTO `gt_module` (`nom`, `module_path`) VALUES ('rss', 'module_rss')");
	
  alert("Installation du module $nom_module.$version ok.");
  redir('../module_espaces/index.php');
	}
	else
	{
  	// Mise à jour depuis la version précédente
	alert("Module ".$nom_module." en version ".$version." fonctionnel");
	redir('index.php');
}
}
else 
{redir('../module_espaces/index.php');}
?>
