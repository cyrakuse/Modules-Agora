<?php
////	AJOUTE LA CONSULTATION d'UN FAVORIS DANS LES LOGS (requete_ajax())
require "commun.inc.php";
$rss_tmp = objet_infos($objet["rss"],$_GET["id_rss"]);
add_logs("consult", $objet["rss"], $rss_tmp["id_rss"], $rss_tmp["adresse"]);
?>