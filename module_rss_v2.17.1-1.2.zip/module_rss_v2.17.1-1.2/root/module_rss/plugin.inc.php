<?php
////	rss
$liste_rss = db_tableau("SELECT DISTINCT * FROM gt_rss WHERE ".sql_affichage_objets_arbo($objet["rss"])." ".sql_selection_plugins($objet["rss"])."  ORDER BY date_crea desc");
foreach($liste_rss as $rss_tmp)
{
	$opener = ($cfg_plugin["mode"]=="recherche") ? ".opener" : "";
	$libelle_rss = ($rss_tmp["description"]!="") ? $rss_tmp["description"] : $rss_tmp["adresse"];
	$resultat_tmp = array("type"=>"elem", "module_dossier"=>$cfg_plugin["module_dossier"]);
	$resultat_tmp["lien_js_icone"] = "window".$opener.".location.replace('".ROOT_PATH.$cfg_plugin["module_dossier"]."/index.php?id_dossier=".$rss_tmp["id_dossier"]."');";
	//$resultat_tmp["lien_js_libelle"] = "window.open('".$rss_tmp["adresse"]."');";
	$resultat_tmp["lien_js_libelle"] = "window".$opener.".location.replace('".ROOT_PATH.$cfg_plugin["module_dossier"]."/index.php?id_dossier=".$rss_tmp["id_dossier"]."');";
	$resultat_tmp["libelle"] = "<span ".infobulle(chemin($objet["rss_dossier"],$rss_tmp["id_dossier"],"url_virtuelle")."<br />".$trad["auteur"]." ".auteur($rss_tmp["id_utilisateur"],$rss_tmp["invite"])).">".text_reduit($libelle_rss)."</span>";
	$cfg_plugin["resultats"][] = $resultat_tmp;
}
////	DOSSIERS
$liste_dossiers	= db_tableau("SELECT * FROM gt_rss_dossier WHERE 1 ".sql_affichage($objet["rss_dossier"])." ".sql_selection_plugins($objet["rss_dossier"])."  ORDER BY date_crea desc");
foreach($liste_dossiers as $dossier_tmp)
{
	$resultat_tmp = array("type"=>"dossier", "module_dossier"=>$cfg_plugin["module_dossier"]);
	$resultat_tmp["lien_js_icone"] = "window.location.replace('".ROOT_PATH.$cfg_plugin["module_dossier"]."/index.php?id_dossier=".$dossier_tmp["id_dossier"]."');";
	$resultat_tmp["lien_js_libelle"] = $resultat_tmp["lien_js_icone"];
	$resultat_tmp["libelle"] = $dossier_tmp["nom"];
	$cfg_plugin["resultats"][] = $resultat_tmp;
}
?>