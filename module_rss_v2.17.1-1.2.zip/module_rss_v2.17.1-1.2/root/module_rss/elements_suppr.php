<?php
////	INIT
require "commun.inc.php";

////	SUPPRESSION DE DOSSIER / rss / ELEMENTS
if(isset($_GET["id_dossier"]))		{ suppr_rss_dossier($_GET["id_dossier"]); }
elseif(isset($_GET["id_rss"]))		{ suppr_rss($_GET["id_rss"]); }
elseif(isset($_GET["SelectedElems"]))
{
	foreach(SelectedElemsArray("rss") as $id_rss)				{ suppr_rss($id_rss); }
	foreach(SelectedElemsArray("rss_dossier") as $id_dossier)	{ suppr_rss_dossier($id_dossier); }
}

////	Redirection
redir("index.php?id_dossier=".$_GET["id_dossier_retour"]);
?>