<?php
////	INIT
require "commun.inc.php";
require_once PATH_INC."header.inc.php";//pour charger la lib. javascript..

////	ON DEPLACE PLUSIEURS ELEMENTS
foreach(SelectedElemsArray("rss") as $id_rss)				{ deplacer_rss($id_rss, $_POST["id_dossier"]); }
foreach(SelectedElemsArray("rss_dossier") as $id_dossier)	{ deplacer_rss_dossier($id_dossier, $_POST["id_dossier"]); }

////		DECONNEXION À LA BDD & FERMETURE
reload_close();
?>